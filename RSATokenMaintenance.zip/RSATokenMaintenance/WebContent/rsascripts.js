


	function fnGetReportBySupervisorName(formname)
	{
		document.getElementsByName(formname)[0].action = "getReportBySupervisorName";
		document.getElementsByName(formname)[0].submit();
	}
	function fnGetReportByProjectToAdmin(formname)
	{
		document.getElementsByName(formname)[0].action = "getReportByProjectToAdmin";
		document.getElementsByName(formname)[0].submit();
	}

	function fnExportAssignedTokenDetails(formname)
	{
		document.getElementsByName(formname)[0].action = "exportAssignedTokenDetails";
		document.getElementsByName(formname)[0].submit();
	}

	function fnExportExpiredTokenDetails(formname)
	{
		document.getElementsByName(formname)[0].action = "exportExpiredTokenDetails";
		document.getElementsByName(formname)[0].submit();
	}
	
	function fnExportLostTokenDetails(formname)
	{
		document.getElementsByName(formname)[0].action = "exportLostTokenDetails";
		document.getElementsByName(formname)[0].submit();
	}

	function fnDeleteExpiredToken(formname)
	{
		document.getElementsByName(formname)[0].action = "deleteExpiredToken";
		document.getElementsByName(formname)[0].submit();
	}
	
	function fngetPendingWithAdminRequest(formname)
	{
		document.getElementsByName(formname)[0].action = "getPendingWithAdminRequest";
		document.getElementsByName(formname)[0].submit();
	}

	function fnGetTokenDetailsByProject(formname)
	{
		 
		document.getElementsByName(formname)[0].action = "getTokenDetailsByProject";
		document.getElementsByName(formname)[0].submit();
	
	}
  	function fnDispatchToken(formname)
  	{
  		
  		document.getElementsByName(formname)[0].action = "getNotDispatchedTokens";
  		document.getElementsByName(formname)[0].submit();
  	
  	}
  	function fnTokenRepository(formname)
  	{
  		
  		document.getElementsByName(formname)[0].action = "TokenRepository.jsp";
  		document.getElementsByName(formname)[0].submit();
  	}
  	
  	function fnCompleted_Request(formname)
  	{
  		
  		document.getElementsByName(formname)[0].action = "ViewRequest.jsp";
  		document.getElementsByName(formname)[0].submit();
  	}
  	function fnPending_Request(formname)
  	{
  		
  		document.getElementsByName(formname)[0].action = "getPendingRequests";
  		document.getElementsByName(formname)[0].submit();
  	

  	}
  	function fnGetSummaryReport(formname)
  	{
  		
  		document.getElementsByName(formname)[0].action = "getSummayReport";
  		document.getElementsByName(formname)[0].submit();
  	

  	}

  	
  	function fnGetSummaryMgrReport(formname)
  	{
  		
  		document.getElementsByName(formname)[0].action = "getSummaryReportForMgr";
  		document.getElementsByName(formname)[0].submit();
  	

  	}


  	function fnMultiple_Request(formname)
  	{
  		 	
  		document.getElementsByName(formname)[0].action = "MultipleRequestRaise";
  		document.getElementsByName(formname)[0].submit();
  	

  	}
  	function fnRaise_Request(formname)
  	{
  		
  		document.getElementsByName(formname)[0].action = "RequestRaise";
  		document.getElementsByName(formname)[0].submit();
  	}

   	function fngetApproved_Request(formname)
  	{
  		
  		document.getElementsByName(formname)[0].action = "getApprovedRequests";
  		document.getElementsByName(formname)[0].submit();
  	}
   	function fngetRejected_Request(formname)
  	{
  		
  		document.getElementsByName(formname)[0].action = "getRejectedRequests";
  		document.getElementsByName(formname)[0].submit();
  	}
  	
	function fnGetOpenRequeststatus(formname)
	{
		
		document.getElementsByName(formname)[0].action = "getOpenRequestStatus";
  		document.getElementsByName(formname)[0].submit();
  	
	}
	function fnGetClosedRequeststatus(formname)
	{
		
		document.getElementsByName(formname)[0].action = "getClosedRequestStatus";
  		document.getElementsByName(formname)[0].submit();
  	
	}
	function fnRaiseRequest(formname)
	{
		
		document.getElementsByName(formname)[0].action = "RequestRaise";
  		document.getElementsByName(formname)[0].submit();
  	
	}

	function fnSurrenderToken(formname)
	{
		
		document.getElementsByName(formname)[0].action = "getSurrenderTokenDetails";
  		document.getElementsByName(formname)[0].submit();
  	
	}

	function fnViewSurrenderRequest(formname)
	{
		
		document.getElementsByName(formname)[0].action = "getSurrenderRequest";
  		document.getElementsByName(formname)[0].submit();
  	
	}
	
	function fnReject(formname)
	{
		
		document.getElementsByName(formname)[0].action = "RejectRequest";
		document.getElementsByName(formname)[0].submit();
	}
		

	function fnCancel(formname)
		{
		
			document.getElementsByName(formname)[0].action = "home.jsp";
			document.getElementsByName(formname)[0].submit();
		  	
		}
	
	
	function fngetAssignedToken(formname)
	{
		
			document.getElementsByName(formname)[0].action = "getAssignedTokens";
			document.getElementsByName(formname)[0].submit();
		  	
	}

	function fngetLostToken(formname)
	{
		
			document.getElementsByName(formname)[0].action = "getLostTokens";
			document.getElementsByName(formname)[0].submit();
		  	
	}
	
	function fngetExpiredToken(formname)
	{
		
			document.getElementsByName(formname)[0].action = "getExpiredTokens";
			document.getElementsByName(formname)[0].submit();
			
		  	
	}
	
	function fngetUnAssignedToken(formname)
	{
		
			document.getElementsByName(formname)[0].action = "getUnAssignedTokens";
			document.getElementsByName(formname)[0].submit();
		  	
	}
	function fngetApprovedRequestsForToken(formname)
	{
		
			document.getElementsByName(formname)[0].action = "getApprovedRequestsForToken";
			document.getElementsByName(formname)[0].submit();
		  	
	}
	function fngetApprovedRequestsForSurrender(formname)
	{
		
			document.getElementsByName(formname)[0].action = "getApprovedRequestsForSurrender";
			document.getElementsByName(formname)[0].submit();
		  	
	}
	
	
	function fnLogOut(formname)
	{
		
			document.getElementsByName(formname)[0].action = "LogoutServlet";
			document.getElementsByName(formname)[0].submit();
		  	
	}
	function fnChangePassword(formname)
	{
		
			document.getElementsByName(formname)[0].action = "CredentialChangePage.jsp";
			document.getElementsByName(formname)[0].submit();
		  	
	}
	function fnGetNotDispatchedTokens(formname)
	{
		
			document.getElementsByName(formname)[0].action = "getNotDispatchedTokens";
			document.getElementsByName(formname)[0].submit();
		  	
	}
	
	function fnGetTokenDetails(formname)
	{
		document.getElementsByName(formname)[0].action = "getTokenDetails";
		document.getElementsByName(formname)[0].submit();

		
	}
	
	
	function fnBulk_Surrender(formname)
	{
		document.getElementsByName(formname)[0].action = "getMultipleTokensForSurrender";
		document.getElementsByName(formname)[0].submit();

		
	}
	
	
	
	
	
	
	function validateLogin()
	{
		var bStatus = true;
		var username, password;

		username = document.getElementsByName("txtUserId")[0].value;
		password = document.getElementsByName("txtPassword")[0].value;

		//* User Name validation
		if(username.length == 0 )
		{
			bStatus = false;
			document.getElementById("errUserName").innerText = "Please enter your username";	
		}
		else if (username.length != 6) 
		{
			bStatus = false;
			document.getElementById("errUserName").innerText = "Username should be your CTS employee ID";	
		}
		else if (validateNumeric(username)) 
		{
			bStatus = false;
			document.getElementById("errUserName").innerText = "Username is not numeric";	
		}
		else
		{
			document.getElementById("errUserName").innerText ="";
		}		
		
		
		//* Password Validation
		if(password.length == 0)
		{
			bStatus = false;
			password="";
			document.getElementById("errPassword").innerText = "Please enter your password";	
		}
		else if (password.length < 6) 
		{
			bStatus = false;
			password="";
			document.getElementById("errPassword").innerText = "password must be greater than 6 characters!";	
		}
		else
			document.getElementById("errPassword").innerText = "";
		return bStatus;
		
	}
	
	
	
	
	function clearLoginData()
	{
		document.getElementsByName("txtUserId")[0].value = "";
		document.getElementsByName("txtPassword")[0].value = "";
		document.getElementById("errUserName").innerText ="";
		document.getElementById("errPassword").innerText = "";
	}

	
	function validateInsert()
	{
		
		var bStatus = true;
		var Start, End,ExpDate;
		
		Start = document.getElementsByName("txtStartTokenId")[0].value;
		End = document.getElementsByName("txtEndTokenId")[0].value;
		ExpDate = document.getElementsByName("txtExpDate")[0].value;
		
		//*Validation of Starting token ID
		if(Start.length == 0 )
		{
			bStatus = false;
			document.getElementById("errStart").innerText = "Enter your starting Token ID";	
		}
		else if (Start.length < 8) 
		{
			bStatus = false;
			document.getElementById("errStart").innerText = "Start Token ID sould be 8 digit";	
		}
		else if (validateNumeric(Start)) 
		{
			bStatus = false;
			document.getElementById("errStart").innerText = "Starting Token ID is not numeric";	
		}
		else
		{
			document.getElementById("errStart").innerText ="";
		}
		
		//*Validation of Ending token ID
		if(End.length == 0)
		{
			bStatus = false;
			document.getElementById("errEnd").innerText = "Enter your ending Token ID";	
		}
		else if (End.length < 8 ) 
		{
			bStatus = false;
			document.getElementById("errEnd").innerText = "Ending Token ID sould be 8 digit";	
		}
		else if (validateNumeric(End)) 
		{
			bStatus = false;
			document.getElementById("errEnd").innerText = "Ending Token ID is not numeric";	
		}
		else
		{
			document.getElementById("errEnd").innerText ="";
		}
		
				
		if(Start > End && bStatus == true)
		{
			bStatus = false;
			document.getElementById("InsertMessage").innerText = "Ending Token ID should be greater or equal to staring Token ID";	
		}
		
		if(ExpDate.length == 0)
		{
			bStatus = false;
			document.getElementById("errExpDate").innerText = "Please select the expiry date";	
		}
		else
		{
			document.getElementById("errExpDate").innerText ="";
		}
		
	
		return bStatus;
		
	}
	
	
	function validateCredentialChange()
	{
		var bStatus = true;
		var OldPassword,Password,Confirm_Password;
		
		OldPassword = document.getElementsByName("Old_Password")[0].value;
		Password = document.getElementsByName("New_Password")[0].value;
		Confirm_Password = document.getElementsByName("Confirm_Password")[0].value;
		 
		//* OldPassword ID 
		if(OldPassword.length == 0 )
		{
			bStatus = false;
			document.getElementById("errOld_Password").innerText = "Please enter your old password!";	
		}
		else if (OldPassword.length <= 6) 
		{
				bStatus = false;
				document.getElementById("errOld_Password").innerText = "Old password sould be greater than 6 character";	
		}
		else
			document.getElementById("errOld_Password").innerText = "";
		
		if(Password.length == 0 )
		{
			bStatus = false;
			document.getElementById("errNew_Password").innerText = "Please enter your new password!";	
		}
		else if (Password.length <= 6) 
		{
				bStatus = false;
				document.getElementById("errNew_Password").innerText = "New password sould be greater than 6 character";	
		}
		else
			document.getElementById("errNew_Password").innerText = "";
		
		
		if(Confirm_Password.length == 0 )
		{
			bStatus = false;
			document.getElementById("errConfirm_Password").innerText = "Please enter your confirm password!";	
		}
		else if(Confirm_Password.length <= 6 )
		{
			bStatus = false;
			document.getElementById("errConfirm_Password").innerText = " Confirm password sould be greater than 6 character";	
		}
		else if( OldPassword == Password ) 
		{
			bStatus = false;
			document.getElementById("errConfirm_Password").innerText = "Old password and new password should not be same";	
			
		}
		else if (Confirm_Password != Password ) 
		{
				bStatus = false;
				document.getElementById("errConfirm_Password").innerText = "Confirm password and new password does not match";	
		}
		else
			document.getElementById("errConfirm_Password").innerText = "";
		
		return bStatus;
		
	}
	
	function clearPasswordsData()
	{
		document.getElementById("errNew_Password").innerText = "";
		document.getElementsByName("Old_Password")[0].value="";
		document.getElementsByName("New_Password")[0].value="";
		document.getElementsByName("Confirm_Password")[0].value="";
		document.getElementById("errOld_Password").innerText = "";
		document.getElementById("errConfirm_Password").innerText = "";
	}
	
	function validateTokenID()
	{
		
		var bStatus = true;
		var Start;
		
		
		Token_ID = document.getElementsByName("txtTokenId")[0].value;
		
		if(Token_ID.length == 0 )
		{
			bStatus = false;
			alert("Please enter your Token ID ");	
		}
		else if (Token_ID.length < 8) 
		{
			bStatus = false;
			alert("Token ID sould be greater than 8 digit");	
		}
		else
			if (validateNumeric(Token_ID)) 
			{
				bStatus = false;
				alert("Token ID is Not Numeric");	
			}
	
		return bStatus;
	}
	
	
	function clearInsertData()
	{
		document.getElementsByName("txtStartTokenId")[0].value = "";
		document.getElementsByName("txtEndTokenId")[0].value = "";
		document.getElementsByName("txtExpDate")[0].value = "";
		document.getElementById("errStart").innerText = "";
		document.getElementById("errEnd").innerText = "";
		document.getElementById("InsertMessage").innerText ="";
		document.getElementById("errExpDate").innerText ="";
	}
	
	function validateNewUser()
	{
	
		var bStatus = true;
		var Associate_ID,EMail_ID;
		
		Associate_ID = document.getElementsByName("Associate_id")[0].value;
		EMail_ID = document.getElementsByName("Email_ID")[0].value;
		
		//* associate ID 
		if(Associate_ID.length == 0 )
		{
			bStatus = false;
			document.getElementById("errAssociate_ID").innerText = "Please enter your Associate ID ";	
		}
		else if (Associate_ID.length != 6) 
		{
			bStatus = false;
			document.getElementById("errAssociate_ID").innerText = "Associate ID sould be 6 digit integer";	
		}
		else if (validateNumeric(Associate_ID)) 
		{
			bStatus = false;
			document.getElementById("errAssociate_ID").innerText = "Associate ID is not numeric";	
		}
		else
		{
			document.getElementById("errAssociate_ID").innerText ="";
		}
		
	 	//* Email ID
		if(EMail_ID.length == 0)
		{
			bStatus = false;
			document.getElementById("errEmailID").innerText = "Please enter your cognizant email ID";
		}
		else if( !validateEmail( EMail_ID ) )
		{
				bStatus = false;
				document.getElementById("errEmailID").innerText ="Please enter your valid cognizant email ID";
		}
		else 
			document.getElementById("errEmailID").innerText = "";
		
	 	return bStatus;
	}

	function clearNewUserData()
	{
		document.getElementsByName("Associate_id")[0].value="";
		document.getElementsByName("Email_ID")[0].value="";
		document.getElementById("errEmailID").innerText = "";
		document.getElementById("errAssociate_ID").innerText ="";
	}
	
	
	
	function validateForgotPassword()
	{
	
		var bStatus = true;
		var Associate_ID;
		
		Associate_ID = document.getElementsByName("Associate_id")[0].value;
		
		//* associate ID 
		if(Associate_ID.length == 0 )
		{
			bStatus = false;
			document.getElementById("errAssociate_ID").innerText = "Please enter your Associate ID ";	
		}
		else if (Associate_ID.length != 6) 
		{
			bStatus = false;
			document.getElementById("errAssociate_ID").innerText = "Associate ID sould be 6 digit integer";	
		}
		else if (validateNumeric(Associate_ID)) 
		{
			bStatus = false;
			document.getElementById("errAssociate_ID").innerText = "Associate ID is not numeric";	
		}
		else
		{
			document.getElementById("errAssociate_ID").innerText ="";
		}
		
	 	return bStatus;
	}

	function clearForgetPassswordPage()
	{
		document.getElementsByName("Associate_id")[0].value ="";
		document.getElementById("errAssociate_ID").innerText ="";
	}
	
	function fnNewCancel()
	{
		document.getElementsByName("NewUser")[0].action = "index.jsp";
		document.getElementsByName("NewUser")[0].submit();

	}

	
	//* regular expressions
	
	
	
	function  validateNumeric( strValue ) 
	{
		var anum=/(^\d+$)|(^\d+\.\d+$)/;	
		if (anum.test(strValue))	
			return false;		
		return true;
	}

	function validateEmail(strMailID)
	{
		//var reEmail = /^(?:\w+\.?)*\w+@(?:\w+\.)+\w+$/;
		var reEmail = /[a-z0-9-]{1,30}@cognizant.[a-z]{3}/ 
	    return reEmail.test(strMailID);
	}
	
	