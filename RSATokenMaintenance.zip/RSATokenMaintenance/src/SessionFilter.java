import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest; 
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;  

import bean.AssociateBean;

/**
 * Servlet Filter implementation class SessionFilter
 */
public class SessionFilter implements Filter 
{
	/**
	 * Default constructor. 
	 */
	public SessionFilter() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(final ServletRequest request, final ServletResponse response, final FilterChain chain) throws IOException, ServletException 
	{
		final HttpServletRequest req = (HttpServletRequest) request;      
		final HttpServletResponse res = (HttpServletResponse) response; 
		final HttpSession session = req.getSession(false);  
		AssociateBean a = null;
		if(session != null)
			a = (AssociateBean) session.getAttribute("Associate");
		if(a != null && session != null)
		{
			if (a.getAssociate_Name() == null) 
				res.sendRedirect("index.jsp");
			else
			{
				chain.doFilter(request, response);
			}
		}
		else
			res.sendRedirect("index.jsp");

	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(final FilterConfig fConfig) throws ServletException
	{
	}

}
