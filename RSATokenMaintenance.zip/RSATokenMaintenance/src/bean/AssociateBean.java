package bean;

import java.io.Serializable;
import java.util.Random;

public class AssociateBean implements Serializable  
{
	private static final long serialVersionUID = 1L;
	private int Associate_ID;
	private String Associate_Name;
	private String Associate_Type;
	private String Associate_Password;
	private int Project_ID[];
	private String Project_Name[];
	private int Supervisor_ID;
	private String Supervisor_Name;
	private String Email_ID;
	private String Grade;
	private String Designation;
	public String generatePassword() 
	{
		final char Pass[] = new char[6];  
		final Random rand = new Random();
	    
	    Pass[0] = (char) (65 + rand.nextInt(26));
	    
	    for(int i = 1; i < 6; i++)
	    {
	    	Pass[i] = (char) (97 + rand.nextInt(26));
	    }
	    
	    final StringBuffer buffer=new StringBuffer();   
	           
	    for(int i=0;i<Pass.length;i++)
	    {     
	    	buffer.append(Pass[i]);       
	    }
	    
	    return (buffer.toString()+ rand.nextInt(99));
	    
	}
	
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}

	public String getGrade() {
		return Grade;
	}

	public void setGrade(final String grade) {
		Grade = grade;
	}

	public String getDesignation() {
		return Designation;
	}

	public void setDesignation(final String designation) {
		Designation = designation;
	}

	public String getEmail_ID() {
		return Email_ID;
	}
	public void setEmail_ID(final String email_ID) {
		Email_ID = email_ID;
	}
	public void setSupervisor_ID(final int supervisorID) {
		Supervisor_ID = supervisorID;
	}
	public void setSupervisor_Name(final String supervisorName) {
		Supervisor_Name = supervisorName;
	}
	public int getSupervisor_ID() {
		return Supervisor_ID;
	}
	public String getSupervisor_Name() {
		return Supervisor_Name;
	}
	public void setAssociate_ID(final int associateID) {
		Associate_ID = associateID;
	}
	public void setAssociate_Name(final String associateName) {
		Associate_Name = associateName;
	}
	public void setAssociate_Type(final String associateType) {
		Associate_Type = associateType;
	}
	public void setAssociate_Password(final String associatePassword) {
		Associate_Password = associatePassword;
	}
	public void setProject_ID(final int projectID[]) {
		Project_ID = new int[projectID.length];
		for(int i=0;i< projectID.length; i++)
		Project_ID[i] = projectID[i];
	}
	public void setProject_Name(final String projectName[]) {
		Project_Name = new String[projectName.length];
		for(int i=0;i< projectName.length; i++)
			Project_Name[i] = projectName[i];
	}
	public int getAssociate_ID() {
		return Associate_ID;
	}
	public String getAssociate_Name() {
		return Associate_Name;
	}
	public String getAssociate_Type() {
		return Associate_Type;
	}
	public String getAssociate_Password() {
		return Associate_Password;
	}
	public int [] getProject_ID() {
		return Project_ID;
	}
	public String [] getProject_Name() {
		return Project_Name;
	}
	
	public int getUniqueProject_ID(final int i) {
		return Project_ID[i];
	}
	public String getUniqueProject_Name(final int i) {
		return Project_Name[i];
	}
	public void setUniqueProject_ID(final int projectid) {
		Project_ID = new int[1];
		Project_ID[0] = projectid;
	}
	public void setUniqueProject_Name(final String projectname) {
		Project_Name = new String[1];
		Project_Name[0] = projectname;
	}
}
