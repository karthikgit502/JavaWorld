package bean;

import java.sql.*;

public class ConnectionBean
{
	private Connection conn = null;
	private static final String username = "rsadb";
	private static final String password = "ctsesirsa";
	private Savepoint savePoint;
	
	public ConnectionBean() 
	{
		openConnection();
		setsavePoint();
		
	}
	public void setsavePoint()
	{
		try
		{
			this.savePoint = conn.setSavepoint("initial");
		}
		catch (final Exception e) 
		{
			// TODO: handle exception
		}
	}
	public Savepoint getSavePoint() {
		return savePoint;
	}
	public void openConnection() 
	{
		
		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			this.conn = DriverManager.getConnection("jdbc:odbc:CTS_RSA_DSN",username,password);
			this.conn.setAutoCommit(false);
		}
		catch (final Exception e) 
		{
			e.printStackTrace();
		}
	}

	public void closeConnection() 
	{
		try {
			this.conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public  void rollBackTransaction() 
	{
		try {
			this.conn.rollback(savePoint);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public  void commitTransaction() 
	{
		try {
			this.conn.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public Connection getConn()
	{
		return this.conn;
	}

}
