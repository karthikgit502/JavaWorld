package bean;

public class DispatchBean 
{
	private int Associate_ID;
	private int Old_Token_ID;
	private int New_Tokn_ID;
	private String Reason_For_Apply;
	
	public int getAssociate_ID() {
		return Associate_ID;
	}
	public void setAssociate_ID(final int associate_ID) {
		Associate_ID = associate_ID;
	}
	public int getOld_Token_ID() {
		return Old_Token_ID;
	}
	public void setOld_Token_ID(final int old_Token_ID) {
		Old_Token_ID = old_Token_ID;
	}
	public int getNew_Tokn_ID() {
		return New_Tokn_ID;
	}
	public void setNew_Tokn_ID(final int new_Tokn_ID) {
		New_Tokn_ID = new_Tokn_ID;
	}
	public String getReason_For_Apply() {
		return Reason_For_Apply;
	}
	public void setReason_For_Apply(final String reason_For_Apply) {
		Reason_For_Apply = reason_For_Apply;
	}
	
}
