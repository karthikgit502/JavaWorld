package bean;
import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Locale;
import jxl.CellView;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.write.Label;
import jxl.write.Number;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;


public class ExcelBean 
{
	private WritableCellFormat timesBoldUnderline;
	private WritableCellFormat times;
	private String inputFile;

	public WritableWorkbook createExcelFile()
	{
		File file = new File(inputFile);
		WorkbookSettings wbSettings = new WorkbookSettings();
		WritableWorkbook workbook = null;
		wbSettings.setLocale(new Locale("en", "EN"));
		try 
		{
			 workbook = Workbook.createWorkbook(file, wbSettings);
		}
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		return workbook;
	}
	public ExcelBean(String inputFile)
	{
		super();
		this.inputFile = inputFile;
	}
	public WritableSheet writeLabel(WritableWorkbook workbook ,String LabelArray[],String SheetName) 
	{
		workbook.createSheet(SheetName,0);
		WritableSheet excelSheet = workbook.getSheet(0);
		createLabel(excelSheet, LabelArray);
		//createContent(excelSheet);
		//workbook.write();
		//workbook.close();
		return excelSheet;
	}

	public void closeWorkBook(WritableWorkbook workbook) throws IOException, WriteException 
	{
		workbook.write();
		workbook.close();
	}
	
	private void createLabel(WritableSheet sheet, String LabelArray[])
	{
		WritableFont times10pt = new WritableFont(WritableFont.TIMES, 10);
		times = new WritableCellFormat(times10pt);
		try {
			times.setWrap(true);
			WritableFont times10ptBoldUnderline = new WritableFont(WritableFont.TIMES,10, WritableFont.BOLD, false);
			timesBoldUnderline = new WritableCellFormat(times10ptBoldUnderline);
			timesBoldUnderline.setWrap(true);
			CellView cv = new CellView();
			cv.setFormat(times);
			cv.setFormat(timesBoldUnderline);
			for (int i = 0; i < LabelArray.length; i++)
				addCaption(sheet, i, 0, LabelArray[i]);

		}
		catch (WriteException e) 
		{
			e.printStackTrace();
		}
	}

	private void addCaption(WritableSheet sheet, int column, int row, String s)	throws RowsExceededException, WriteException 
	{
		Label label;
		label = new Label(column, row, s, timesBoldUnderline);
		sheet.addCell(label);
	}

	public void addNumber(WritableSheet sheet, int column, int row,int value) throws WriteException, RowsExceededException 
	{
		Number number;
		number = new Number(column, row, value, times);
		sheet.addCell(number);
	}

	public void addLabel(WritableSheet sheet, int column, int row, String s)throws WriteException, RowsExceededException {
		Label label;
        label = new Label(column, row, s, times);
		sheet.addCell(label);
	}
	
	public void addLabel(WritableSheet sheet, int column, int row, Date date)throws WriteException, RowsExceededException {
		final DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");		 
		Label label = new Label(column, row,((String)dateFormat.format(date) ), times);
		sheet.addCell(label);
	}

}

