package bean;

import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
 

public class MailBean 
{
	private String To;
	private final String From = "RSAservices@cognizant.com";
	private final String host = "10.237.5.105";
	private String EmailMessage;
	private String Subject;
	private String CC[] = null;
	

	public void setCC(final String[] cc) 
	{
		CC = cc;
	}

	public String getSubject() 
	{
		return Subject;
	}

	public void setSubject(final String subject) 
	{
		Subject = subject;
	}

	public String getMessage() 
	{
		return EmailMessage;
	}

	public void setMessage(final String message) 
	{
		EmailMessage = message;
	}

	public void setTo(final String to) 
	{
		To = to;
	}
 
	public int sendMail() 
	{
		try 
		{
			final Properties properties = System.getProperties();
			properties.setProperty("mail.smtp.host", host);
			
			final Session session = Session.getDefaultInstance(properties);
			final Message msg = new MimeMessage(session);
			msg.setFrom(new InternetAddress(From));
			
			msg.addRecipient(Message.RecipientType.TO, new InternetAddress(To));
			if(CC != null)
			{
				for(int i=0; i < CC.length; i++ )
					msg.addRecipient(Message.RecipientType.CC, new InternetAddress(CC[i]));
			}
			
			msg.setSubject(Subject);
			msg.setContent(EmailMessage, "text/html");
			Transport.send(msg);

			return 1;
		} 
		catch (final Exception e) 
		{
			return 0;
		}
	}
	
	public int sendMailWithAttachement(String FilePath) 
	{
		try 
		{

	        Properties properties = System.getProperties();
	        properties.setProperty("mail.smtp.host", host);
	        Session session = Session.getDefaultInstance(properties);
	        Message message = new MimeMessage(session);
	        message.setFrom(new InternetAddress(From));
	        message.addRecipient(Message.RecipientType.TO,new InternetAddress(To));
	        message.setSubject(Subject);
	        BodyPart messageBodyPart = new MimeBodyPart();
			String EmailMessage="Dear Associate,\n"+
			"          Please find attached the requested report.\n"+
			"\n"+
			"With Regards \n"+
			"  ESI-PMO.\n"+
			"-----------------------------------------------------------------------------------------------"+
			"----------------------------------------------------------";
	        messageBodyPart.setText(EmailMessage);

	        Multipart multipart = new MimeMultipart();
	        multipart.addBodyPart(messageBodyPart);
	        messageBodyPart = new MimeBodyPart();
	        
	        FileDataSource source = new FileDataSource(FilePath);
	        messageBodyPart.setDataHandler(new DataHandler(source));
	        messageBodyPart.setFileName(FilePath);
	        multipart.addBodyPart(messageBodyPart);
	        message.setContent(multipart);
	        
			if(CC != null)
			{
				for(int i=0; i < CC.length; i++ )
					message.addRecipient(Message.RecipientType.CC, new InternetAddress(CC[i]));
			}
			
			message.setSubject(Subject);
			message.setContent(multipart);
			Transport.send(message);
			return 1;
		} 
		catch (final Exception e) 
		{
			return 0;
		}
	}

}


