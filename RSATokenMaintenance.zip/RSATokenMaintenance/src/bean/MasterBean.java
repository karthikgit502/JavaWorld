package bean;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
public class MasterBean 
{
	private int Project_id;
	private String Project_name;
	private int Associate_id;
	private String Aassociate_name;
	private int Token_id;
	private Timestamp Assigned_date;
	private Date Expiry_date;
	private String Status;
	private String Reason_For_Apply;
	private String Dispatch_status;
	private int Supervisor_ID;
	public int getProject_id() {
		return Project_id;
	}
	public int getSupervisor_ID() {
		return Supervisor_ID;
	}
	public void setSupervisor_ID(final int supervisor_ID) {
		Supervisor_ID = supervisor_ID;
	}
	public String getReason_For_Apply() {
		return Reason_For_Apply;
	}
	public void setReason_For_Apply(final String reason_For_Apply) {
		Reason_For_Apply = reason_For_Apply;
	}
	public String getProject_name() {
		return Project_name;
	}
	public int getAssociate_id() {
		return Associate_id;
	}
	public String getAassociate_name() {
		return Aassociate_name;
	}
	public int getToken_id() {
		return Token_id;
	}
	public Timestamp getAssigned_date() {
		return Assigned_date;
	}
	public Date getExpiry_date() {
		return Expiry_date;
	}
	public String getStatus() {
		return Status;
	}
	
	public String getDispatch_status() {
		return Dispatch_status;
	}
	public void setProject_id(final int projectId) {
		Project_id = projectId;
	}
	public void setProject_name(final String projectName) {
		Project_name = projectName;
	}
	public void setAssociate_id(final int associateId) {
		Associate_id = associateId;
	}
	public void setAassociate_name(final String aassociateName) {
		Aassociate_name = aassociateName;
	}
	public void setToken_id(final int tokenId) {
		Token_id = tokenId;
	}
	public void setAssigned_date(final Timestamp assignedDate) {
		Assigned_date = assignedDate;
	}
	public void setExpiry_date(final Date expiryDate) {
		Expiry_date = expiryDate;
	}
	public void setStatus(final String status) {
		Status = status;
	}
	public void setDispatch_status(final String dispatchStatus) {
		Dispatch_status = dispatchStatus;
	}
	
	public String getAssigned_dateInString() 
	{
		final DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		return ( (String)dateFormat.format(Assigned_date) );
	}
	
}
