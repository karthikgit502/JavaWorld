package bean;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class MasterHistoryBean extends MasterBean 
{
	private Timestamp Processed_date;

	public Timestamp getProcessed_date() {
		return Processed_date;
	}

	public void setProcessed_date(final Timestamp processed_date) {
		Processed_date = processed_date;
	}

	public String getProcessedDateInString() {
		final DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		return ( (String)dateFormat.format(Processed_date) );
	}

}
