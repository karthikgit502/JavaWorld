package bean;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
 
public class RequestBean {

	private int Request_ID;
	private int Request_Associate_ID;
	private String Request_Associate_Name;
	private Timestamp Request_Date;
	private String Request_Reason_For_Apply;
	private String Request_Status;
	private int Request_Project_ID;
	private String Request_Project_Name;
	private int Supervisor_ID;
	
	public int getSupervisor_ID() {
		return Supervisor_ID;
	}
	
	
	public void setSupervisor_ID(final int supervisor_ID) {
		Supervisor_ID = supervisor_ID;
	}
	public int getRequest_Project_ID() {
		return Request_Project_ID;
	}
	public void setRequest_Project_ID(final int request_Project_ID) {
		Request_Project_ID = request_Project_ID;
	}
	public String getRequest_Project_Name() {
		return Request_Project_Name;
	}
	public void setRequest_Project_Name(final String request_Project_Name) {
		Request_Project_Name = request_Project_Name;
	}
	public void setRequest_Associate_Name(final String request_Associate_Name) {
		Request_Associate_Name = request_Associate_Name;
	}
	public String getRequest_Associate_Name() {
		return Request_Associate_Name;
	}
	
	public void setRequest_ID(final int requestID) {
		Request_ID = requestID;
	}
	public void setRequest_Associate_ID(final int requestAssociateID) {
		Request_Associate_ID = requestAssociateID;
	}
	public void setRequest_Date(final Timestamp requestDate) {
		Request_Date = requestDate;
	}
	public void setRequest_Reason_For_Apply(final String requestReasonForApply) {
		Request_Reason_For_Apply = requestReasonForApply;
	}
	public void setRequest_Status(final String requestStatus) {
		Request_Status = requestStatus;
	}
	public int getRequest_ID() {
		return Request_ID;
	}
	public int getRequest_Associate_ID() {
		return Request_Associate_ID;
	}
	public Timestamp getRequest_Date() {
		return Request_Date;
	}
	public String getRequest_Reason_For_Apply() {
		return Request_Reason_For_Apply;
	}
	public String getRequest_Status() {
		return Request_Status;
	}
	public String getRequestDateInString() 
	{
		final DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		return ( (String)dateFormat.format(Request_Date) );
	}
	
}
