package bean;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class RequestHistoryBean extends RequestBean
{

	private Timestamp Token_Assigned_Date;
	private int Token_ID;
	private String Reject_Reason;
	public String getReject_Reason() {
		return Reject_Reason;
	}
	public void setReject_Reason(final String reject_Reason) {
		Reject_Reason = reject_Reason;
	}
	public void setToken_Assigned_Date(final Timestamp token_Assigned_Date) {
		Token_Assigned_Date = token_Assigned_Date;
	}
	public void setToken_ID(final int token_ID) {
		Token_ID = token_ID;
	}
	public Timestamp getToken_Assigned_Date() {
		return Token_Assigned_Date;
	}
	public int getToken_ID() {
		return Token_ID;
	}
	public String getToken_Assigned_DateInString() 
	{
		final DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		return ( (String)dateFormat.format(Token_Assigned_Date) );
	}

}
