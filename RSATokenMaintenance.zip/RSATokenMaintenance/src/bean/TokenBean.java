package bean;

import java.sql.Date;

public class TokenBean 
{
	private int Token_ID;
	private Date Expiry_Date;
	private String Token_Status;
	private String Token_Dispatch_Status;
	
	public String getToken_Dispatch_Status() {
		return Token_Dispatch_Status;
	}
	public void setToken_Dispatch_Status(final String token_Dispatch_Status) {
		Token_Dispatch_Status = token_Dispatch_Status;
	}
	public void setToken_Status(final String tokenStatus) {
		Token_Status = tokenStatus;
	}
	public String getToken_Status() {
		return Token_Status;
	}
	public void setToken_ID(final int tokenID) {
		Token_ID = tokenID;
	}
	public void setExpiry_Date(final Date expiryDate) {
		Expiry_Date = expiryDate;
	}
	public int getToken_ID() {
		return Token_ID;
	}
	public Date getExpiry_Date() {
		return Expiry_Date;
	}
	
}
