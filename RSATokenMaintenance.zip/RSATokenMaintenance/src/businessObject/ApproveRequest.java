package businessObject;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import bean.ConnectionBean;
import bean.RequestBean;
import dao.MailDAO;
import dao.RequestDAO;
import dao.RequestHistoryDAO;

/**
 * Servlet implementation class ApproveRequest
 */
public class ApproveRequest extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ApproveRequest() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub



	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException 
	{

		final String arr[] = request.getParameterValues("ckSelect");

		final String status="Approved";
		RequestDispatcher rd= null;
		int checked = 0;

		int ckAssociateID=0;
		RequestBean Request = null;
		final ConnectionBean conn = new ConnectionBean();
		if(conn != null)
		{
			if( arr != null)
			{
				try
				{
					for(int i=0; i < arr.length ; i++)
					{
						ckAssociateID = Integer.parseInt(arr[i].substring(0,6));
						checked++;
						Request  = RequestDAO.getOpenRequestStatus(ckAssociateID,conn.getConn());
						RequestDAO.updateRequest(Request.getRequest_ID(), status,conn.getConn());
						RequestHistoryDAO.insertApprovedRequest(Request.getRequest_ID(),conn.getConn());
						Request = RequestDAO.getRequestBean(Request.getRequest_ID(),conn.getConn());

						if( Request.getRequest_Reason_For_Apply().equals("Surrender") )
							MailDAO.sendMailaboutSurrenderRequestApprove(Request,conn.getConn());
						else
							MailDAO.sendMailaboutRequestApprove(Request,conn.getConn());

						request.setAttribute("RequestMessage" ,"You are approved "+ checked+" Requests!." );
						rd = request.getRequestDispatcher("getPendingRequests");
					}
				}
				catch(final Exception e)
				{
					conn.rollBackTransaction();
					conn.closeConnection();
				}
				finally
				{
					if(conn != null)
					{
						conn.commitTransaction();
						conn.closeConnection();
					}
				}
			}
			else
			{
				request.setAttribute("RequestMessage" ,"Please select request to approve!");
				rd = request.getRequestDispatcher("getPendingRequests");
			}
		}
		else
		{
			request.setAttribute("Message", "Database under maintenance. Please try later.");
			rd = request.getRequestDispatcher("Message.jsp");
		}
		rd.forward(request, response);

	}

}
