package businessObject;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import bean.AssociateBean;
import bean.ConnectionBean;
import bean.MasterBean;
import bean.RequestBean;
import bean.RequestHistoryBean;
import dao.*;

/**
 * Servlet implementation class AssignToken
 */
public class AssignToken extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AssignToken() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher rd = null;
		final String arr[] = request.getParameterValues("ckSelect");
		int new_token=0;
		int Surrendered_token=0;
		int ckReaquestid;
		int Request_id;
		int assigned_count = 0;
		String Request_Reason;
		RequestBean Request=new RequestBean();
		AssociateBean Associate= new AssociateBean();
		MasterBean MasterHistoryBean= new MasterBean();
		final RequestHistoryBean RequestHistory = new RequestHistoryBean();
		final ConnectionBean conn = new ConnectionBean();
		if(conn != null)
		{
			if( arr != null )
			{
				try{

					for(int i=0; i< arr.length; i++)
					{
						ckReaquestid = Integer.parseInt(arr[i]);
						Request = RequestDAO.getRequestBean(ckReaquestid,conn.getConn());
						Request_id = Request.getRequest_ID();
						Request_Reason = Request.getRequest_Reason_For_Apply();
						Associate = AssociateDAO.getAssociateBean(Request.getRequest_Associate_ID(),conn.getConn());
						new_token = TokenDAO.getToken_For_Assign("New Token",conn.getConn());
						Surrendered_token =  TokenDAO.getToken_For_Assign("Surrendered",conn.getConn());
						if( Request_Reason.equals("Token_Lost"))
						{
							if( Surrendered_token > 0)
							{
								MasterDAO.Set_Token_Status(Associate.getAssociate_ID(),"Lost",conn.getConn());
								MasterHistoryBean = MasterDAO.getMasterDetails(Associate.getAssociate_ID(),conn.getConn());
								MasterHistoryDAO.insertRequest(MasterHistoryBean,conn.getConn());
								MasterDAO.deleteMaster(MasterHistoryBean.getToken_id(),conn.getConn());
								MasterDAO.Assign_token(Surrendered_token,Associate,Request,"Re-Assigned",conn.getConn());
								RequestDAO.updateRequest(Request_id, "Assigned",conn.getConn());
								MasterHistoryBean = MasterDAO.getMasterDetails(Associate.getAssociate_ID(),conn.getConn());
								MasterHistoryDAO.insertRequest(MasterHistoryBean,conn.getConn());
								Request = RequestDAO.getRequestBean(Request_id,conn.getConn());
								RequestHistory.setRequest_Associate_ID(Request.getRequest_Associate_ID());
								RequestHistory.setRequest_Associate_Name(Request.getRequest_Associate_Name());
								RequestHistory.setRequest_Date(Request.getRequest_Date());
								RequestHistory.setRequest_ID(Request.getRequest_ID());
								RequestHistory.setRequest_Project_ID(Request.getRequest_Project_ID());
								RequestHistory.setRequest_Project_Name(Request.getRequest_Project_Name());
								RequestHistory.setRequest_Reason_For_Apply( Request.getRequest_Reason_For_Apply());	
								RequestHistory.setRequest_Status(Request.getRequest_Status());
								RequestHistory.setSupervisor_ID(Request.getSupervisor_ID());
								RequestHistoryDAO.insertRequest(RequestHistory,conn.getConn());
								MailDAO.sendMailaboutAssignedToken(Request,conn.getConn());
								assigned_count ++;
							}
							else if( new_token > 0 )
							{
								MasterDAO.Set_Token_Status(Associate.getAssociate_ID(),"Lost",conn.getConn());
								MasterHistoryBean = MasterDAO.getMasterDetails(Associate.getAssociate_ID(),conn.getConn());
								MasterHistoryDAO.insertRequest(MasterHistoryBean,conn.getConn());
								MasterDAO.deleteMaster(MasterHistoryBean.getToken_id(),conn.getConn());
								MasterDAO.Assign_token(new_token,Associate,Request,"Assigned",conn.getConn());
								RequestDAO.updateRequest(Request_id, "Assigned",conn.getConn());
								MasterHistoryBean = MasterDAO.getMasterDetails(Associate.getAssociate_ID(),conn.getConn());
								MasterHistoryDAO.insertRequest(MasterHistoryBean,conn.getConn());
								Request = RequestDAO.getRequestBean(Request_id,conn.getConn());
								RequestHistory.setRequest_Associate_ID(Request.getRequest_Associate_ID());
								RequestHistory.setRequest_Associate_Name(Request.getRequest_Associate_Name());
								RequestHistory.setRequest_Date(Request.getRequest_Date());
								RequestHistory.setRequest_ID(Request.getRequest_ID());
								RequestHistory.setRequest_Project_ID(Request.getRequest_Project_ID());
								RequestHistory.setRequest_Project_Name(Request.getRequest_Project_Name());
								RequestHistory.setRequest_Reason_For_Apply( Request.getRequest_Reason_For_Apply());	
								RequestHistory.setRequest_Status(Request.getRequest_Status());
								RequestHistory.setSupervisor_ID(Request.getSupervisor_ID());
								RequestHistoryDAO.insertRequest(RequestHistory,conn.getConn());
								MailDAO.sendMailaboutAssignedToken(Request,conn.getConn());
								assigned_count ++;
							}
							else 
							{
								request.setAttribute("AssignMessage","No Tokens for assign.");
								rd = request.getRequestDispatcher("getApprovedRequestsForToken");
							}

						}
						else if( Request_Reason.equals("Token_Expired"))
						{
							if( Surrendered_token > 0)
							{
								MasterDAO.Set_Token_Status(Associate.getAssociate_ID(),"Expired",conn.getConn());
								MasterHistoryBean = MasterDAO.getMasterDetails(Associate.getAssociate_ID(),conn.getConn());
								MasterHistoryDAO.insertRequest(MasterHistoryBean,conn.getConn());
								MasterDAO.deleteMaster(MasterHistoryBean.getToken_id(),conn.getConn());
								MasterDAO.Assign_token(Surrendered_token,Associate,Request,"Re-Assigned",conn.getConn());
								RequestDAO.updateRequest(Request_id, "Assigned",conn.getConn());
								MasterHistoryBean = MasterDAO.getMasterDetails(Associate.getAssociate_ID(),conn.getConn());
								MasterHistoryDAO.insertRequest(MasterHistoryBean,conn.getConn());
								Request = RequestDAO.getRequestBean(Request_id,conn.getConn());
								RequestHistory.setRequest_Associate_ID(Request.getRequest_Associate_ID());
								RequestHistory.setRequest_Associate_Name(Request.getRequest_Associate_Name());
								RequestHistory.setRequest_Date(Request.getRequest_Date());
								RequestHistory.setRequest_ID(Request.getRequest_ID());
								RequestHistory.setRequest_Project_ID(Request.getRequest_Project_ID());
								RequestHistory.setRequest_Project_Name(Request.getRequest_Project_Name());
								RequestHistory.setRequest_Reason_For_Apply( Request.getRequest_Reason_For_Apply());	
								RequestHistory.setRequest_Status(Request.getRequest_Status());
								RequestHistory.setSupervisor_ID(Request.getSupervisor_ID());
								RequestHistoryDAO.insertRequest(RequestHistory,conn.getConn());
								MailDAO.sendMailaboutAssignedTokenWithSurrenderDetails(Request,conn.getConn());
								assigned_count ++;
							}
							else if( new_token > 0 )
							{
								MasterDAO.Set_Token_Status(Associate.getAssociate_ID(),"Expired",conn.getConn());
								MasterHistoryBean = MasterDAO.getMasterDetails(Associate.getAssociate_ID(),conn.getConn());
								MasterHistoryDAO.insertRequest(MasterHistoryBean,conn.getConn());
								MasterDAO.deleteMaster(MasterHistoryBean.getToken_id(),conn.getConn());
								MasterDAO.Assign_token(new_token,Associate,Request,"Assigned",conn.getConn());
								RequestDAO.updateRequest(Request_id, "Assigned",conn.getConn());
								MasterHistoryBean = MasterDAO.getMasterDetails(Associate.getAssociate_ID(),conn.getConn());
								MasterHistoryDAO.insertRequest(MasterHistoryBean,conn.getConn());
								Request = RequestDAO.getRequestBean(Request_id,conn.getConn());
								RequestHistory.setRequest_Associate_ID(Request.getRequest_Associate_ID());
								RequestHistory.setRequest_Associate_Name(Request.getRequest_Associate_Name());
								RequestHistory.setRequest_Date(Request.getRequest_Date());
								RequestHistory.setRequest_ID(Request.getRequest_ID());
								RequestHistory.setRequest_Project_ID(Request.getRequest_Project_ID());
								RequestHistory.setRequest_Project_Name(Request.getRequest_Project_Name());
								RequestHistory.setRequest_Reason_For_Apply( Request.getRequest_Reason_For_Apply());	
								RequestHistory.setRequest_Status(Request.getRequest_Status());
								RequestHistory.setSupervisor_ID(Request.getSupervisor_ID());
								RequestHistoryDAO.insertRequest(RequestHistory,conn.getConn());
								MailDAO.sendMailaboutAssignedTokenWithSurrenderDetails(Request,conn.getConn());
								assigned_count ++;
							}
							else
							{
								request.setAttribute("AssignMessage","No Tokens for assign!.");
								rd = request.getRequestDispatcher("getApprovedRequestsForToken");
							}
						}
						else
						{
							if( Surrendered_token > 0)
							{
								if(MasterDAO.Assign_token(Surrendered_token,Associate,Request,"Re-Assigned",conn.getConn()) > 0 )
								{
									RequestDAO.updateRequest(Request_id, "Re-Assigned",conn.getConn());
									MasterHistoryBean = MasterDAO.getMasterDetails(Associate.getAssociate_ID(),conn.getConn());
									MasterHistoryDAO.insertRequest(MasterHistoryBean,conn.getConn());
									Request = RequestDAO.getRequestBean(Request_id,conn.getConn());
									RequestHistory.setRequest_Associate_ID(Request.getRequest_Associate_ID());
									RequestHistory.setRequest_Associate_Name(Request.getRequest_Associate_Name());
									RequestHistory.setRequest_Date(Request.getRequest_Date());
									RequestHistory.setRequest_ID(Request.getRequest_ID());
									RequestHistory.setRequest_Project_ID(Request.getRequest_Project_ID());
									RequestHistory.setRequest_Project_Name(Request.getRequest_Project_Name());
									RequestHistory.setRequest_Reason_For_Apply( Request.getRequest_Reason_For_Apply());	
									RequestHistory.setRequest_Status(Request.getRequest_Status());
									RequestHistory.setSupervisor_ID(Request.getSupervisor_ID());
									RequestHistoryDAO.insertRequest(RequestHistory,conn.getConn());
									MailDAO.sendMailaboutAssignedToken(Request,conn.getConn());
									assigned_count ++;
								}

							}
							else if( new_token > 0 )
							{
								if(MasterDAO.Assign_token(new_token,Associate,Request,"Assigned",conn.getConn()) > 0 )
								{
									RequestDAO.updateRequest(Request_id, "Assigned",conn.getConn());
									MasterHistoryBean = MasterDAO.getMasterDetails(Associate.getAssociate_ID(),conn.getConn());
									MasterHistoryDAO.insertRequest(MasterHistoryBean,conn.getConn());
									Request = RequestDAO.getRequestBean(Request_id,conn.getConn());
									RequestHistory.setRequest_Associate_ID(Request.getRequest_Associate_ID());
									RequestHistory.setRequest_Associate_Name(Request.getRequest_Associate_Name());
									RequestHistory.setRequest_Date(Request.getRequest_Date());
									RequestHistory.setRequest_ID(Request.getRequest_ID());
									RequestHistory.setRequest_Project_ID(Request.getRequest_Project_ID());
									RequestHistory.setRequest_Project_Name(Request.getRequest_Project_Name());
									RequestHistory.setRequest_Reason_For_Apply( Request.getRequest_Reason_For_Apply());	
									RequestHistory.setRequest_Status(Request.getRequest_Status());
									RequestHistory.setSupervisor_ID(Request.getSupervisor_ID());
									RequestHistoryDAO.insertRequest(RequestHistory,conn.getConn());
									MailDAO.sendMailaboutAssignedToken(Request,conn.getConn());
									assigned_count ++;
								}

							}
							else 
							{
								request.setAttribute("AssignMessage","No Tokens for assign.");
								rd = request.getRequestDispatcher("getApprovedRequestsForToken");
								break;
							}
						}
					}//for loop
					if(assigned_count > 0)
					{
						request.setAttribute("AssignMessage",""+assigned_count + " Token(s) assigned successfully.");
						rd = request.getRequestDispatcher("getApprovedRequestsForToken");
					}
				}//try
				catch(final Exception e)
				{
					conn.rollBackTransaction();
					conn.closeConnection();
				}
				finally
				{
					if(conn != null)
					{
						conn.commitTransaction();
						conn.closeConnection();
					}
				}
			}//arr check
			else
			{
				request.setAttribute("AssignMessage","Please select the request(s) to assign Token!.");
				rd = request.getRequestDispatcher("getApprovedRequestsForToken");
			}
		}// coon check
		else
		{
			request.setAttribute("Message", "Database under maintenance. Please try later.");
			rd = request.getRequestDispatcher("Message.jsp");
		}
		rd.forward(request, response);
	}
}