package businessObject;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import bean.AssociateBean;
import bean.ConnectionBean;
import bean.RequestBean;
import dao.AssociateDAO;
import dao.MailDAO;
import dao.RequestDAO;
import dao.RequestHistoryDAO;

/**
 * Servlet implementation class BulkSurrender
 */
public class BulkSurrender extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public BulkSurrender() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd = null;
		final String arr[] = request.getParameterValues("ckSelect");

		RequestBean Request= null;
		AssociateBean Associate = null;

		int a = 0;
		int total_request_raised =0;
		int ckAssociateID = 0;

		final ConnectionBean conn = new ConnectionBean();
		if(conn != null)
		{
			if( arr != null )
			{
				try
				{
					for(int i=0; i< arr.length; i++)
					{
						ckAssociateID = Integer.parseInt(arr[i]);

						Associate = AssociateDAO.getAssociateBean(ckAssociateID,conn.getConn());
						if( ckAssociateID != 0 )
						{
							Request = new RequestBean();
							Request.setRequest_Reason_For_Apply("Surrender");
							Request.setRequest_Associate_ID(ckAssociateID);
							Request.setRequest_Status("Approved");
							Request.setRequest_Associate_Name(Associate.getAssociate_Name());
							Request.setRequest_Project_ID(Associate.getUniqueProject_ID(0));
							Request.setRequest_Project_Name(Associate.getUniqueProject_Name(0));
							Request.setSupervisor_ID(Associate.getSupervisor_ID());
							a = RequestDAO.insertNew_Request(Request,conn.getConn());
							if(a > 0)
							{
								total_request_raised = total_request_raised + a;
								Request = RequestDAO.getOpenRequestStatus(ckAssociateID,conn.getConn());
								RequestHistoryDAO.insertNewRequestUsingID(Request.getRequest_ID(),conn.getConn());
								RequestHistoryDAO.insertApprovedRequest(Request.getRequest_ID(),conn.getConn());
								MailDAO.sendMailaboutRequestRaise(Request,conn.getConn());
								final AssociateBean Admin = AssociateDAO.getAdminDetails(conn.getConn());
								MailDAO.sendMailToAdmin(Admin,Request,conn.getConn());
							}
						}
					}// for loop
					if(  total_request_raised != 0)
					{
						request.setAttribute("RequestMessage" ,total_request_raised+" Request(s) raised successfully.");
						rd = request.getRequestDispatcher("getMultipleTokensForSurrender");
					}


				}
				catch(final Exception e)
				{
					conn.rollBackTransaction();
					conn.closeConnection();
				}
				finally
				{
					if(conn != null)
					{
						conn.commitTransaction();
						conn.closeConnection();
					}
				}
			}
			else
			{
				request.setAttribute("RequestMessage" ,"Please select Associate to raise request.");
				rd = request.getRequestDispatcher("getMultipleTokensForSurrender");
			}
		}
		else
		{
			request.setAttribute("Message", "Database under maintenance. Please try later.");
			rd = request.getRequestDispatcher("Message.jsp");
		}
		rd.forward(request, response);
	}

}
