package businessObject;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import dao.AssociateDAO;
import bean.AssociateBean;
import bean.ConnectionBean;
/**
 * Servlet implementation class ChangePasswordServlet
 */
public class ChangePasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ChangePasswordServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException 
	{
		RequestDispatcher  rd=null;

		final HttpSession Sr = request.getSession(false);
		final AssociateBean Associate=(AssociateBean) Sr.getAttribute("Associate");
		final String Old_Password = request.getParameter("Old_Password");
		final String New_password = request.getParameter("New_Password");
		final ConnectionBean conn = new ConnectionBean();
		if(conn != null)
		{
			try{
				final AssociateBean Old_Associate = AssociateDAO.selectUser(Associate.getAssociate_ID(), Old_Password,conn.getConn());	
				if ( Old_Associate != null)
				{
					AssociateDAO.updatePassword(Associate.getAssociate_ID(), New_password,conn.getConn());
					request.setAttribute("errMessage", "Password changed successfully");
					rd = request.getRequestDispatcher("CredentialChangePage.jsp");
				}
				else
				{
					request.setAttribute("Message", "Password you entered did not match");
					rd = request.getRequestDispatcher("passwordChangeMessage.jsp");
				}
			}	
			catch(final Exception e)
			{
				conn.rollBackTransaction();
				conn.closeConnection();
				request.setAttribute("Message", e);
				rd = request.getRequestDispatcher("Message.jsp");

			}
			finally
			{
				if(conn != null)
				{
					conn.commitTransaction();
					conn.closeConnection();
				}
			}
		}
		else
		{
			request.setAttribute("Message", "Database under maintenance. Please try later.");
			rd = request.getRequestDispatcher("passwordChangeMessage.jsp");
		}

		rd.forward(request, response);
	}

}
