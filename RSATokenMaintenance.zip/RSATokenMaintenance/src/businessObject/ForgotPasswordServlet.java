package businessObject;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import bean.AssociateBean;
import bean.ConnectionBean;

import dao.AssociateDAO;
import dao.MailDAO;

/**
 * Servlet implementation class ForgotPasswordServlet
 */
public class ForgotPasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ForgotPasswordServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException 
	{
		RequestDispatcher  rd=null;
		final int NewAssociate_ID = Integer.parseInt(request.getParameter("Associate_id"));
		AssociateBean Associate = null;
		boolean sendMail = true;
		final ConnectionBean conn = new ConnectionBean();
		if(conn != null)
		{
			try
			{
				if(AssociateDAO.isRegisteredAssociate(NewAssociate_ID ,conn.getConn()) )
				{
					Associate = AssociateDAO.getAssociateBean(NewAssociate_ID,conn.getConn());
					Associate.setAssociate_Password(AssociateDAO.getForgotPassword(NewAssociate_ID,conn.getConn())); 
					rd = request.getRequestDispatcher("NewUserMessage.jsp");
				}
				else if( AssociateDAO.isNewAssociate(NewAssociate_ID,conn.getConn()))
				{
					request.setAttribute("Error", "You are not a registered Associate");
					rd = request.getRequestDispatcher("Forgot_Password.jsp");
					sendMail = false;
				}
				else 
				{
					request.setAttribute("Error", "Your are not a autherised user");
					rd = request.getRequestDispatcher("Forgot_Password.jsp");
					sendMail = false;
				}

			}
			catch(final Exception e)
			{
				sendMail = false;
				conn.rollBackTransaction();
				conn.closeConnection();
			}
			finally
			{
				if(conn != null)
				{
					if(sendMail)
						MailDAO.sendNewUserMail(Associate, conn.getConn());
					conn.commitTransaction();
					conn.closeConnection();
				}
			}
		}
		else
		{
			request.setAttribute("Message", "Database under maintenance. Please try later.");
			rd = request.getRequestDispatcher("Message.jsp");
		}

		rd.forward(request, response);

	}

}
