package businessObject;

import bean.*;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import dao.AssociateDAO;


public class LoginServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

	public LoginServlet() 
	{
		super();
	}

	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException 
	{
	}

	protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException 
	{
		RequestDispatcher  rd = null;
		AssociateBean Associate = null;
		final ConnectionBean conn = new ConnectionBean();
		if(conn != null)
		{

			try
			{
				final int username = Integer.parseInt(request.getParameter("txtUserId"));
				final String password = request.getParameter("txtPassword");
				Associate = AssociateDAO.selectUser(username, password,conn.getConn());
				if (Associate != null) 
				{
					final HttpSession session = request.getSession(false);
					session.setAttribute("Associate", Associate);
					rd = request.getRequestDispatcher("home.jsp");
				}
				else
				{
					request.setAttribute("Message", "Invalid username or password!");
					rd = request.getRequestDispatcher("loginMessage.jsp");
				}
			}
			catch(final Exception e)
			{
				try
				{
					conn.rollBackTransaction();
					conn.closeConnection();
				}
				catch (final Throwable e1) 
				{
					e1.printStackTrace();
				}
			}
			finally
			{
				if(conn != null)
				{
					try{
						conn.commitTransaction();
						conn.closeConnection();
					}
					catch (final Throwable e) 
					{
						e.printStackTrace();
					}
				}
			}
		}
		else
		{
			request.setAttribute("Message", "Database under maintenance. Please try later.");
			rd = request.getRequestDispatcher("loginMessage.jsp");
		}
		rd.forward(request, response);
	}
}

