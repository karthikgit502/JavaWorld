package businessObject;

import java.io.IOException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.AssociateBean;
import bean.ConnectionBean;
import bean.MasterBean;
import bean.RequestBean;
import bean.RequestHistoryBean;
import dao.AssociateDAO;
import dao.MailDAO;
import dao.MasterDAO;
import dao.MasterHistoryDAO;
import dao.RequestDAO;
import dao.RequestHistoryDAO;
import dao.TokenDAO;

/**
 * Servlet implementation class MultiRequestRaise
 */
public class MultiRequestRaise extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MultiRequestRaise() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		int total_request_raised =0;
		int ckAssociateID=0,a=0;
		RequestDispatcher rd = null;
		boolean autoAssignFlag = false;
		final String arr[] = request.getParameterValues("ckSelect"); 
		final String AutoAssign[] = request.getParameterValues("ckAutoAssign");
		final String ProjectNames[] = request.getParameterValues("Project_Name");
		final String ProjectIDs[] = request.getParameterValues("Project_ID");
		int ckRowNo =0;
		int total_Token_assigned = 0;

		RequestBean Request= null;
		final ConnectionBean conn = new ConnectionBean();
		boolean sendMail = true;
		AssociateBean Associate=null;

		if(conn != null)
		{
			if(  arr != null )
			{
				try
				{

					for(int i=0; i< arr.length; i++)
					{
						ckAssociateID = Integer.parseInt(arr[i].substring(0,6));
						ckRowNo = Integer.parseInt(arr[i].substring(6));
						autoAssignFlag = false;
						if(AutoAssign != null)
							for(int j = 0;j < AutoAssign.length; j++)
								if(AutoAssign[j].equals(arr[i]))
									autoAssignFlag = true;

						if(ckAssociateID != 0 &&  ( ProjectIDs[ckRowNo] == "" || ProjectNames[ckRowNo]== ""))
						{
							request.setAttribute("RequestMessage" ," Please select Project ID/Project Name for the selected Associates");
							rd = request.getRequestDispatcher("MultipleRequestRaise");
						}
						else if( ckAssociateID != 0 &&  ( ProjectIDs[ckRowNo].equals(ProjectNames[ckRowNo]) ))
						{
							Associate = AssociateDAO.getAssociateBean(ckAssociateID,conn.getConn());
							Request = new RequestBean();
							Request.setRequest_Reason_For_Apply("New_Joinee");
							Request.setRequest_Associate_ID(ckAssociateID);
							Request.setRequest_Associate_Name(Associate.getAssociate_Name());
							Request.setRequest_Status("Approved");
							Request.setRequest_Project_ID(Associate.getUniqueProject_ID(Integer.parseInt(ProjectIDs[ckRowNo])));
							Request.setRequest_Project_Name(Associate.getUniqueProject_Name(Integer.parseInt(ProjectNames[ckRowNo])));
							Request.setSupervisor_ID(Associate.getSupervisor_ID());
							a = RequestDAO.insertNew_Request(Request,conn.getConn());
							if(a > 0)
								total_request_raised = total_request_raised + a;

							if(autoAssignFlag)
							{
								MasterBean MasterHistoryBean= new MasterBean();
								final RequestHistoryBean RequestHistory = new RequestHistoryBean();
								Request = RequestDAO.getOpenRequestStatus(ckAssociateID,conn.getConn());
								RequestHistoryDAO.insertNewRequestUsingID(Request.getRequest_ID(),conn.getConn());
								RequestHistoryDAO.insertApprovedRequest(Request.getRequest_ID(),conn.getConn());

								final int Request_id = Request.getRequest_ID();
								final int new_token = TokenDAO.getToken_For_Assign("New Token",conn.getConn());
								final int Surrendered_token =  TokenDAO.getToken_For_Assign("Surrendered",conn.getConn());

								if( Surrendered_token > 0)
								{
									MasterDAO.Assign_token(Surrendered_token,Associate,Request,"Re-Assigned",conn.getConn());
									RequestDAO.updateRequest(Request_id, "Re-Assigned",conn.getConn());
									MasterHistoryBean = MasterDAO.getMasterDetails(Associate.getAssociate_ID(),conn.getConn());
									MasterHistoryDAO.insertRequest(MasterHistoryBean,conn.getConn());
									Request = RequestDAO.getRequestBean(Request_id,conn.getConn());
									RequestHistory.setRequest_Associate_ID(Request.getRequest_Associate_ID());
									RequestHistory.setRequest_Associate_Name(Request.getRequest_Associate_Name());
									RequestHistory.setRequest_Date(Request.getRequest_Date());
									RequestHistory.setRequest_ID(Request.getRequest_ID());
									RequestHistory.setRequest_Project_ID(Request.getRequest_Project_ID());
									RequestHistory.setRequest_Project_Name(Request.getRequest_Project_Name());
									RequestHistory.setRequest_Reason_For_Apply( Request.getRequest_Reason_For_Apply());	
									RequestHistory.setRequest_Status(Request.getRequest_Status());
									RequestHistory.setSupervisor_ID(Request.getSupervisor_ID());
									RequestHistoryDAO.insertRequest(RequestHistory,conn.getConn());
									//MailDAO.sendMailaboutAutoAssignedToken(Request,conn.getConn());
									total_Token_assigned++;
									total_request_raised = total_request_raised - a;
								}
								else
								{
									if( new_token > 0 )
									{
										total_Token_assigned  = total_Token_assigned +	MasterDAO.Assign_token(new_token,Associate,Request,"Assigned",conn.getConn());
										RequestDAO.updateRequest(Request_id, "Assigned",conn.getConn()); 
										MasterHistoryBean = MasterDAO.getMasterDetails(Associate.getAssociate_ID(),conn.getConn());
										MasterHistoryDAO.insertRequest(MasterHistoryBean,conn.getConn());
										Request = RequestDAO.getRequestBean(Request_id,conn.getConn());
										RequestHistory.setRequest_Associate_ID(Request.getRequest_Associate_ID());
										RequestHistory.setRequest_Associate_Name(Request.getRequest_Associate_Name());
										RequestHistory.setRequest_Date(Request.getRequest_Date());
										RequestHistory.setRequest_ID(Request.getRequest_ID());
										RequestHistory.setRequest_Project_ID(Request.getRequest_Project_ID());
										RequestHistory.setRequest_Project_Name(Request.getRequest_Project_Name());
										RequestHistory.setRequest_Reason_For_Apply( Request.getRequest_Reason_For_Apply());	
										RequestHistory.setRequest_Status(Request.getRequest_Status());
										RequestHistory.setSupervisor_ID(Request.getSupervisor_ID());
										RequestHistoryDAO.insertRequest(RequestHistory,conn.getConn());
										//MailDAO.sendMailaboutAutoAssignedToken(Request,conn.getConn());
										total_request_raised = total_request_raised - a;
									}
								}
							}
							else
							{
								if( a > 0)
								{
									Request = RequestDAO.getOpenRequestStatus(ckAssociateID,conn.getConn());
									RequestHistoryDAO.insertNewRequestUsingID(Request.getRequest_ID(),conn.getConn());
									RequestHistoryDAO.insertApprovedRequest(Request.getRequest_ID(),conn.getConn());
								}
							}
						}
						else
						{
							request.setAttribute("RequestMessage" ," Please select correct Project ID and Project Name for the selectd Associates");
							rd = request.getRequestDispatcher("MultipleRequestRaise");
						}

					}// for 
				}//try
				catch(final Exception e)
				{
					sendMail = false;
					try
					{
						conn.rollBackTransaction();
						conn.closeConnection();
					}
					catch (final Throwable e1) 
					{
						e1.printStackTrace();
					}
				}
				finally
				{
					if(conn != null)
					{
						try
						{
							if(sendMail && autoAssignFlag )
								MailDAO.sendMailaboutAutoAssignedToken(Request,conn.getConn());
							else
								if(sendMail && !autoAssignFlag)
								{
									MailDAO.sendMailaboutRequestRaise(Request,conn.getConn());
									final AssociateBean Admin = AssociateDAO.getAdminDetails(conn.getConn());
									MailDAO.sendMailToAdmin(Admin,Request,conn.getConn());
								}

							conn.commitTransaction();
							conn.closeConnection();
						}
						catch (final Throwable e) 
						{
							e.printStackTrace();
						}
					}
				}
			}
			else
			{
				request.setAttribute("RequestMessage" ,"Please select Associate to raise request!!");
				rd = request.getRequestDispatcher("MultipleRequestRaise");
			}

			if(  total_request_raised == 0 && total_Token_assigned > 0)
			{
				request.setAttribute("RequestMessage" ,total_Token_assigned +" Tokens Assigned successfully.");
				rd = request.getRequestDispatcher("MultipleRequestRaise");
			}
			if(  total_request_raised > 0 && total_Token_assigned > 0)
			{
				request.setAttribute("RequestMessage" ,total_Token_assigned +" Tokens Assigned and "+total_request_raised+" request raised.");
				rd = request.getRequestDispatcher("MultipleRequestRaise");
			}
			if( total_request_raised > 0 && total_Token_assigned == 0)
			{
				if(autoAssignFlag)
				{
					request.setAttribute("RequestMessage",total_request_raised+" Request(s) raised successfully but, No Tokens assigned(No tokens available).");
					rd = request.getRequestDispatcher("MultipleRequestRaise");
				}
				else
				{
					request.setAttribute("RequestMessage",total_request_raised+" Request(s) raised successfully.");
					rd = request.getRequestDispatcher("MultipleRequestRaise");
				}
			}
		}
		else
		{
			request.setAttribute("RequestMessage", "Database under maintenance. Please try later.");
			rd = request.getRequestDispatcher("MultipleRequestRaise");
		}


		rd.forward(request, response);
	}

}
