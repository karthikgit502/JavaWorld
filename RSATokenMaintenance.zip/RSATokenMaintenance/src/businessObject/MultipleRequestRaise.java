package businessObject;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import bean.AssociateBean;
import bean.ConnectionBean;
import dao.AssociateDAO;
 
public class MultipleRequestRaise extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public MultipleRequestRaise() {
		super();
	}
	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}
	protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher rd = null;
		final ConnectionBean conn = new ConnectionBean();
		if(conn != null)
		{
			if(request.getAttribute("RequestMessage") != null)
				request.setAttribute("RequestMessage", request.getAttribute("RequestMessage"));
			try
			{
				final HttpSession Sr = request.getSession(false);
				final AssociateBean Associate=(AssociateBean) Sr.getAttribute("Associate");
				
				final List<bean.AssociateBean> Associates = AssociateDAO.getUnAssigned_Associate(Associate.getAssociate_ID(),conn.getConn());
				final Iterator<AssociateBean> iter = Associates.iterator();
				request.setAttribute("Associates", iter);
				rd = request.getRequestDispatcher("displayNewRequest.jsp");
			}
			catch(final Exception e)
			{
					conn.rollBackTransaction();
					conn.closeConnection();
			}
			finally
			{
				if(conn != null)
				{
						conn.commitTransaction();
						conn.closeConnection();
				}
			}
		}
		else
		{
			request.setAttribute("RequestMessage", "Database under maintenance. Please try later.");
			rd = request.getRequestDispatcher("displayNewRequest.jsp");
		}

		rd.forward(request, response);
	}


}
