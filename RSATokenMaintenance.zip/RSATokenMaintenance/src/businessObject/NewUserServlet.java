package businessObject;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dao.AssociateDAO;
import dao.MailDAO;
import bean.AssociateBean;
import bean.ConnectionBean;

/**
 * Servlet implementation class NewUserServlet
 */
public class NewUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public NewUserServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException 
	{

		RequestDispatcher  rd=null;

		final int NewAssociate_ID = Integer.parseInt(request.getParameter("Associate_id"));
		final String NewAssociates_Mail_ID = request.getParameter("Email_ID");
		AssociateBean NewAssociate = null;
		final ConnectionBean conn = new ConnectionBean();
		boolean sendMail = true;

		if(conn != null)
		{
			try
			{
				if(AssociateDAO.isRegisteredAssociate(NewAssociate_ID,conn.getConn()) )
				{
					request.setAttribute("Error", "You have already registered!");
					rd = request.getRequestDispatcher("NewUser.jsp");
					sendMail = false ;
				}
				else if( AssociateDAO.isNewAssociate(NewAssociate_ID,conn.getConn()))
				{
					NewAssociate = AssociateDAO.registerNewAssociate(NewAssociate_ID,NewAssociates_Mail_ID,conn.getConn());
					if( NewAssociate != null  )
						rd = request.getRequestDispatcher("NewUserMessage.jsp");
					else
						sendMail = false ;
				}
				else 
				{
					request.setAttribute("Error", "Your are not a autherised user");
					rd = request.getRequestDispatcher("NewUser.jsp");
					sendMail = false ;
				}

			}
			catch(final Exception e)
			{
				sendMail = false;
				try
				{
					conn.rollBackTransaction();
					conn.closeConnection();
				}
				catch (final Throwable e1) 
				{
					e1.printStackTrace();
				}
			}
			finally
			{
				if(conn != null)
				{
					try
					{
						if(sendMail)
							MailDAO.sendNewUserMail(NewAssociate, conn.getConn());
						conn.commitTransaction();
						conn.closeConnection();
					}
					catch (final Throwable e) 
					{
						e.printStackTrace();
					}
				}
			}
		}
		else
		{
			request.setAttribute("Error", "Database under maintenance. Please try later.");
			rd = request.getRequestDispatcher("NewUser.jsp");
		}

		rd.forward(request, response);
	}

}
