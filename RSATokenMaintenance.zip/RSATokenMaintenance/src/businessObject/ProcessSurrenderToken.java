package businessObject;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.AssociateBean;
import bean.ConnectionBean;
import bean.MasterBean;

import bean.RequestBean;
import bean.RequestHistoryBean;
import dao.AssociateDAO;
import dao.MailDAO;
import dao.MasterDAO;
import dao.MasterHistoryDAO;
import dao.RequestDAO;
import dao.RequestHistoryDAO;


/**
 * Servlet implementation class ProcessSurrenderToken
 */
public class ProcessSurrenderToken extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ProcessSurrenderToken() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {

		RequestDispatcher rd = null;
		final ConnectionBean conn = new ConnectionBean();
		final String arr[] = request.getParameterValues("ckSelect");
		int ckReaquestid;
		RequestBean Request=new RequestBean();
		AssociateBean Associate= new AssociateBean();
		MasterBean MasterHistoryBean= new MasterBean();
		final RequestHistoryBean RequestHistory = new RequestHistoryBean();
		int Surrendered = 0;
		if(conn != null)
		{
			if( arr != null )
			{
				try{
					for(int i=0; i< arr.length; i++)
					{
						ckReaquestid = Integer.parseInt(arr[i]);
						Surrendered ++;
						Request = RequestDAO.getRequestBean(ckReaquestid,conn.getConn());
						Associate = AssociateDAO.getAssociateBean(Request.getRequest_Associate_ID(),conn.getConn());
						RequestDAO.updateRequest(ckReaquestid, "Surrendered",conn.getConn());
						Request = RequestDAO.getRequestBean(ckReaquestid,conn.getConn());
						RequestDAO.deleteRequest(ckReaquestid,conn.getConn());
						RequestHistory.setRequest_Associate_ID(Request.getRequest_Associate_ID());
						RequestHistory.setRequest_Associate_Name(Request.getRequest_Associate_Name());
						RequestHistory.setRequest_Date(Request.getRequest_Date());
						RequestHistory.setRequest_ID(Request.getRequest_ID());
						RequestHistory.setRequest_Project_ID(Request.getRequest_Project_ID());
						RequestHistory.setRequest_Project_Name(Request.getRequest_Project_Name());
						RequestHistory.setRequest_Reason_For_Apply( Request.getRequest_Reason_For_Apply());	
						RequestHistory.setRequest_Status(Request.getRequest_Status());
						RequestHistory.setSupervisor_ID(Request.getSupervisor_ID());
						RequestHistoryDAO.insertRequest(RequestHistory,conn.getConn());
						MasterDAO.Set_Token_Status(Associate.getAssociate_ID(),"Surrendered",conn.getConn());
						MasterHistoryBean = MasterDAO.getMasterDetails(Associate.getAssociate_ID(),conn.getConn());
						MasterHistoryDAO.insertRequest(MasterHistoryBean,conn.getConn());
						MailDAO.sendMailaboutSurrenderToken(Request,conn.getConn());
						MasterDAO.deleteMasterDetails(MasterHistoryBean.getToken_id(),conn.getConn());
					}// for
					if(Surrendered > 0)
					{
						request.setAttribute("AssignMessage",Surrendered +" Tokens received successfully. ");
						rd = request.getRequestDispatcher("getApprovedRequestsForSurrender");
					}
					else
					{
						request.setAttribute("AssignMessage","No Tokens received");
						rd = request.getRequestDispatcher("getApprovedRequestsForSurrender");
					}
						
				}
				catch(final Exception e)
				{

					try
					{
						conn.rollBackTransaction();
						conn.closeConnection();
					}
					catch (final Throwable e1) 
					{
						e1.printStackTrace();
					}
				}
				finally
				{
					if(conn != null)
					{
						try
						{
							conn.commitTransaction();
							conn.closeConnection();
						}
						catch (final Throwable e) 
						{
							e.printStackTrace();
						}
					}
				}
			}
			else
			{
				request.setAttribute("AssignMessage","Please select the request to receive the Token.");
				rd = request.getRequestDispatcher("getApprovedRequestsForSurrender");
			}
		}
		else
		{
			request.setAttribute("AssignMessage", "Database under maintenance. Please try later.");
			rd = request.getRequestDispatcher("getApprovedRequestsForSurrender");
		}
		rd.forward(request, response);
	}

}
