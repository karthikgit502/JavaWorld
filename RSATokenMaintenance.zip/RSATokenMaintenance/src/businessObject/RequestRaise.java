package businessObject;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import dao.AssociateDAO;
import dao.DispatchDAO;
import dao.MailDAO;
import dao.RequestDAO;
import dao.RequestHistoryDAO;
import dao.TokenDAO;

import bean.AssociateBean;
import bean.ConnectionBean;
import bean.TokenBean;

import bean.RequestBean;

/**
 * Servlet implementation class RequestRaise
 */
public class RequestRaise extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RequestRaise() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int a=0;

		RequestDispatcher rd = null;
		final String Request_Reason = request.getParameter("Reason");
		final int Project_Name_index = Integer.parseInt(request.getParameter("Project_Name"));
		final int Project_ID_index = Integer.parseInt(request.getParameter("Project_ID"));

		ConnectionBean conn = new ConnectionBean();

		boolean Allow = false;
		boolean Expired;
		boolean Dispatch;
		boolean sendMail = true;
		RequestBean Request= null;
		final HttpSession Sr = request.getSession(false);
		final AssociateBean Associate=(AssociateBean) Sr.getAttribute("Associate");

		int Request_ID;
		if(conn != null)
		{
			try
			{
				final int Assigned_token = AssociateDAO.isTokenAssigned(Associate.getAssociate_ID(),conn.getConn());
				Request_ID = RequestDAO.isRequestRaised(Associate.getAssociate_ID(),conn.getConn());
				Expired = TokenDAO.isTokenExpired(Assigned_token,conn.getConn());
				Dispatch = DispatchDAO.Dispatch_Status(Associate.getAssociate_ID(),conn.getConn());
				if( Assigned_token == 0 && !(Request_Reason.equals("New_Joinee")) )
				{
					if(Request_ID > 0)
					{
						request.setAttribute("RequestMessage" ,"You have already raised a request!. Your request ID: "+ Request_ID);
						rd = request.getRequestDispatcher("RequestRaise.jsp");
					}
					else
					{
						request.setAttribute("RequestMessage" ,"No Token assigned for you.");
						rd = request.getRequestDispatcher("RequestRaise.jsp");
					}
				}
				else if( Assigned_token != 0 && Dispatch )
				{
					if( Request_Reason.equals("Token_Lost") )
					{
						if( Request_ID != 0 )
						{
							request.setAttribute("RequestMessage" ,"You have already raised a request!. Your request ID: "+ Request_ID);
							rd = request.getRequestDispatcher("RequestRaise.jsp");
						}
						else
						{				
							Allow = true;
						}
					}	
					else if( Request_Reason.equals("Token_Expired") )   
					{
						if(Expired )
						{	
							if( Request_ID != 0 )
							{
								request.setAttribute("RequestMessage" ,"You are already raised a request!.Your request ID: "+ Request_ID);
								rd = request.getRequestDispatcher("RequestRaise.jsp");
							}
							else
							{				
								Allow = true;
							}
						}
						else
						{
							final TokenBean token = TokenDAO.get_Token_Details(Associate.getAssociate_ID(),conn.getConn());
							request.setAttribute("RequestMessage" ,"Request rejected. Your RSA Token expires on :"+ token.getExpiry_Date());
							rd = request.getRequestDispatcher("RequestRaise.jsp");
						}
					}
					else if(Request_Reason.equals("New_Joinee") && Request_ID != 0)
					{
						request.setAttribute("RequestMessage" ,"You have already raised a request!. Your request ID: "+ Request_ID);
						rd = request.getRequestDispatcher("RequestRaise.jsp");
					}
					else
					{
						request.setAttribute("RequestMessage" ,"You already have a Token - "+ Assigned_token);
						rd = request.getRequestDispatcher("RequestRaise.jsp");
					}
				}
				else if( Assigned_token != 0 && !Dispatch )
				{
					request.setAttribute("RequestMessage" ,"Token assigned for you!, Please collect it!");
					rd = request.getRequestDispatcher("RequestRaise.jsp");
				}
				else
				{
					if( Request_ID != 0 )
					{
						request.setAttribute("RequestMessage" ,"You have already raised a request!. Your request ID: "+ Request_ID);
						rd = request.getRequestDispatcher("RequestRaise.jsp");
					}
					else
					{				
						Allow = true;
					}
				}
				if (Allow)
				{
					Request = new RequestBean();
					Request.setRequest_Reason_For_Apply(Request_Reason);
					Request.setRequest_Associate_ID( Associate.getAssociate_ID());
					Request.setRequest_Status("Pending for Approval");
					Request.setRequest_Associate_Name(Associate.getAssociate_Name());
					Request.setRequest_Project_ID(Associate.getUniqueProject_ID(Project_ID_index));
					Request.setRequest_Project_Name(Associate.getUniqueProject_Name(Project_Name_index));
					Request.setSupervisor_ID(Associate.getSupervisor_ID());

					if( (Associate.getAssociate_Type()).equals("SUPER_USER") )
						Request.setRequest_Status("Approved");
					a = RequestDAO.insertNew_Request(Request,conn.getConn());

					Request = RequestDAO.getOpenRequestStatus(Associate.getAssociate_ID(),conn.getConn());
					RequestHistoryDAO.insertNewRequestUsingID(Request.getRequest_ID(),conn.getConn());

					if(  a != 0 && (Associate.getAssociate_Type()).equals("SUPER_USER") )
					{
						RequestHistoryDAO.insertApprovedRequest(Request.getRequest_ID(),conn.getConn());
						request.setAttribute("RequestMessage" ,"Request(s) raised successfully!");
						rd = request.getRequestDispatcher("RequestRaise.jsp");
					}
					else
					{
						if(a != 0)
						{
							request.setAttribute("RequestMessage" ,"Request raised successfully!");
							rd = request.getRequestDispatcher("RequestRaise.jsp");

						}
					}
				}


			}
			catch(final Exception e)
			{ 
				sendMail = false;
				conn.rollBackTransaction();
				conn.closeConnection();
			}
			finally
			{
				if(conn != null)
				{

					if(sendMail && Allow)
					{
						if(  a != 0 && (Associate.getAssociate_Type()).equals("SUPER_USER") )
							MailDAO.sendMailToAdmin(Associate, Request,conn.getConn());
						else
							if(a != 0)
								MailDAO.sendMailaboutRequestRaise(Request,conn.getConn());
						conn.commitTransaction();
						conn.closeConnection();
					}
				}
			}

		}
		else
		{
			request.setAttribute("RequestMessage", "Database under maintenance. Please try later.");
			rd = request.getRequestDispatcher("RequestRaise.jsp");
		}

		rd.forward(request, response);
	}
}
