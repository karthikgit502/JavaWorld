package businessObject;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import bean.ConnectionBean;
import dao.TokenDAO;

/**
 * Servlet implementation class deleteExpiredToken
 */
public class deleteExpiredToken extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public deleteExpiredToken() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher rd = null;
		ConnectionBean conn = new ConnectionBean();
		int deleted = 0 ;
		try
		{
			deleted =  TokenDAO.processExpiredToken(conn.getConn());
			String msg;
			if(deleted > 0)
				msg = ""+deleted +" Expired Tokens removed successfully";
			else 
				msg = "No expired Token(s) in database.";
			request.setAttribute("Message",msg);
			rd=request.getRequestDispatcher("Message.jsp");
		}
		catch(final Exception e)
		{
			conn.rollBackTransaction();
			conn.closeConnection();
			request.setAttribute("Message",e);
			rd=request.getRequestDispatcher("Message.jsp");
		}
		finally
		{
			if(conn != null)
			{
				conn.commitTransaction();
				conn.closeConnection();
			}
		}
		rd.forward(request, response);
	}


}

