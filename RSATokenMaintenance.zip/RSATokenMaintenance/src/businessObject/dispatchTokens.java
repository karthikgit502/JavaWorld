package businessObject;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import bean.ConnectionBean;
import bean.MasterHistoryBean;
import bean.RequestBean;
import bean.RequestHistoryBean;
import dao.DispatchDAO;
import dao.MailDAO;
import dao.MasterHistoryDAO;
import dao.RequestDAO;
import dao.RequestHistoryDAO;
import dao.TokenDAO;



public class dispatchTokens extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public dispatchTokens() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub


		int ckAssociateID=0;
		int total_tokens_dispatched = 0;
		RequestDispatcher rd = null;
		final String arr[] = request.getParameterValues("ckSelect");
		final String Expired_TokenID[] = request.getParameterValues("expied_tokenID");
		final RequestHistoryBean RequestHistory = new RequestHistoryBean();
		RequestBean Request = null;
		int ckRowNo =0;
		int expiredToken =0;

		final ConnectionBean conn = new ConnectionBean();
		if( conn != null)
		{
			if( arr != null )
			{
				try
				{
					for(int i=0; i< arr.length; i++)
					{
						ckAssociateID = Integer.parseInt(arr[i].substring(0,6));
						ckRowNo = Integer.parseInt(arr[i].substring(6));
						Request = RequestDAO.getOpenRequestStatus(ckAssociateID,conn.getConn());
						expiredToken = TokenDAO.getRecentlyExpiredTokenFromAssociate(ckAssociateID,conn.getConn());
						final String RecentlyExpiredToken = ""+expiredToken;

						if( (Request.getRequest_Reason_For_Apply()).equals("Token_Expired"))
						{	
							if( Expired_TokenID[ckRowNo] == "" )
							{
								request.setAttribute("Message" ,"Please enter the expired token ID.");
								rd = request.getRequestDispatcher("getNotDispatchedTokens");
							}
							else if((Expired_TokenID[ckRowNo]).equals(RecentlyExpiredToken))
							{
								RequestDAO.updateRequest(Request.getRequest_ID(),"Dispatched",conn.getConn());
								Request = RequestDAO.getRequestBean(Request.getRequest_ID(), conn.getConn());
								RequestHistory.setRequest_Associate_ID(Request.getRequest_Associate_ID());
								RequestHistory.setRequest_Associate_Name(Request.getRequest_Associate_Name());
								RequestHistory.setRequest_Date(Request.getRequest_Date());
								RequestHistory.setRequest_ID(Request.getRequest_ID());
								RequestHistory.setRequest_Project_ID(Request.getRequest_Project_ID());
								RequestHistory.setRequest_Project_Name(Request.getRequest_Project_Name());
								RequestHistory.setRequest_Reason_For_Apply( Request.getRequest_Reason_For_Apply());	
								RequestHistory.setRequest_Status(Request.getRequest_Status());
								RequestHistory.setSupervisor_ID(Request.getSupervisor_ID());
								RequestHistoryDAO.insertRequest(RequestHistory,conn.getConn());
								total_tokens_dispatched = total_tokens_dispatched + DispatchDAO.dispatchToken(ckAssociateID,conn.getConn());
								request.setAttribute("Message" ,total_tokens_dispatched + " Tokens dispatched successfully!");
								final MasterHistoryBean ExpiredTokenMaster = MasterHistoryDAO.getRecentlyExpiredTokenDetails(Request.getRequest_Associate_ID(),conn.getConn());
								MailDAO.sendMailaboutSurrenderOfExpiredToken(ExpiredTokenMaster,conn.getConn());
								MailDAO.sendMailaboutDispatchToken(Request,conn.getConn());
								RequestDAO.deleteRequest(Request.getRequest_ID(),conn.getConn());
								rd = request.getRequestDispatcher("getNotDispatchedTokens");
							}
							else 
							{
								request.setAttribute("Message" ,"Please enter the correct expired token ID.");
								rd = request.getRequestDispatcher("getNotDispatchedTokens");
							}
						}
						else 
						{
							RequestDAO.updateRequest(Request.getRequest_ID(),"Dispatched",conn.getConn());
							Request = RequestDAO.getRequestBean(Request.getRequest_ID(), conn.getConn());
							RequestHistory.setRequest_Associate_ID(Request.getRequest_Associate_ID());
							RequestHistory.setRequest_Associate_Name(Request.getRequest_Associate_Name());
							RequestHistory.setRequest_Date(Request.getRequest_Date());
							RequestHistory.setRequest_ID(Request.getRequest_ID());
							RequestHistory.setRequest_Project_ID(Request.getRequest_Project_ID());
							RequestHistory.setRequest_Project_Name(Request.getRequest_Project_Name());
							RequestHistory.setRequest_Reason_For_Apply( Request.getRequest_Reason_For_Apply());	
							RequestHistory.setRequest_Status(Request.getRequest_Status());
							RequestHistory.setSupervisor_ID(Request.getSupervisor_ID());
							RequestHistoryDAO.insertRequest(RequestHistory,conn.getConn());
							total_tokens_dispatched = total_tokens_dispatched + DispatchDAO.dispatchToken(ckAssociateID,conn.getConn());
							request.setAttribute("Message" ,total_tokens_dispatched + " Tokens dispatched successfully!");
							MailDAO.sendMailaboutDispatchToken(Request,conn.getConn());
							RequestDAO.deleteRequest(Request.getRequest_ID(),conn.getConn());
							rd = request.getRequestDispatcher("getNotDispatchedTokens");
						}
					}// for loop
				}//try
				catch(final Exception e)
				{
					conn.rollBackTransaction();
					conn.closeConnection();
				}
				finally
				{
					if(conn != null)
					{
						conn.commitTransaction();
						conn.closeConnection();
					}
				}
			}
			else
			{
				request.setAttribute("Message","Please select the Token to dispatch!.");
				rd = request.getRequestDispatcher("getNotDispatchedTokens");
			}
		}
		else
		{
			request.setAttribute("Message", "Database under maintenance. Please try later.");
			rd = request.getRequestDispatcher("Message.jsp");
		}

		rd.forward(request, response);
	}
}
