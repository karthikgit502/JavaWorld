package businessObject;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import bean.AssociateBean;
import bean.ConnectionBean;
import bean.RequestHistoryBean;
import dao.RequestHistoryDAO;

/**
 * Servlet implementation class getApprovedDetails
 */
public class getApprovedRequests extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public getApprovedRequests() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException 
	{
		RequestDispatcher rd = null;
		final String Request_Status = "Approved";
		final ConnectionBean conn = new ConnectionBean();
		final HttpSession Sr = request.getSession(false);
		final AssociateBean SuperUser =(AssociateBean) Sr.getAttribute("Associate");
		if(conn != null)
		{
			if ( request.getAttribute("AssignMessage") != null)
				request.setAttribute("AssignMessage", request.getAttribute("AssignMessage") );
			try 
			{
				final List<RequestHistoryBean>  Requests=  RequestHistoryDAO.getApprovedRequests(SuperUser.getAssociate_ID(),Request_Status,conn.getConn());
				if(Requests != null)
				{
					final Iterator<RequestHistoryBean> iter = Requests.iterator();
					request.setAttribute("Requests", iter);
				}
				else
				{
					request.setAttribute("Requests", null);
				}
				rd = request.getRequestDispatcher("displayApprovedRequest.jsp");

			} 
			catch(final Exception e)
			{
				conn.rollBackTransaction();
				conn.closeConnection();
				request.setAttribute("Message", e);
				rd = request.getRequestDispatcher("Message.jsp");
			}
			finally
			{
				if(conn != null)
				{
					conn.commitTransaction();
					conn.closeConnection();
				}
			}
		}
		else
		{
			request.setAttribute("Message", "Database under maintenance. Please try later.");
			rd = request.getRequestDispatcher("Message.jsp");
		}

		rd.forward(request, response);

	}

}
