package businessObject;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import bean.AssociateBean;
import bean.ConnectionBean;
import bean.RequestHistoryBean;
import dao.RequestHistoryDAO;

/**
 * Servlet implementation class getClosedRequestStatus
 */
public class getClosedRequestStatus extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public getClosedRequestStatus() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher rd = null;
		final HttpSession Sr = request.getSession(true);
		final AssociateBean Associate=(AssociateBean) Sr.getAttribute("Associate");
		final ConnectionBean conn = new ConnectionBean();
		if(conn != null)
		{
			try
			{   	
				final List<bean.RequestHistoryBean>  Requests= RequestHistoryDAO.getClosedRequestStatus(Associate.getAssociate_ID(),conn.getConn());
				final Iterator<RequestHistoryBean> iter = Requests.iterator();
				request.setAttribute("Requests", iter);
				rd = request.getRequestDispatcher("ClosedRequest.jsp");
			}
			catch(final Exception e)
			{
				try
				{
					conn.rollBackTransaction();
					conn.closeConnection();
				}
				catch (final Throwable e1) 
				{
					e1.printStackTrace();
				}
			}
			finally
			{
				if(conn != null)
				{
					try
					{
						conn.commitTransaction();
						conn.closeConnection();
					}
					catch (final Throwable e) 
					{
						e.printStackTrace();
					}
				}
			}
		}
		else
		{
			request.setAttribute("Message", "Database under maintenance. Please try later.");
			rd = request.getRequestDispatcher("Message.jsp");
		}

		rd.forward(request, response);

	}

}
