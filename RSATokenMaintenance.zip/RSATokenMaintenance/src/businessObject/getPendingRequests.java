package businessObject;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dao.RequestDAO;
import bean.ConnectionBean;
import bean.RequestBean;;


public class getPendingRequests extends HttpServlet {
	private static final long serialVersionUID = 1L;


	public getPendingRequests() {
		super();

	}

	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
	}
	protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd = null;

		final String Request_Status="Pending for Approval";
		final ConnectionBean conn = new ConnectionBean();
		if(conn != null)
		{

			try 
			{
				final List<bean.RequestBean>  Requests=  RequestDAO.getRequest_Details(Request_Status,conn.getConn());
				final Iterator<RequestBean> iter = Requests.iterator();
				request.setAttribute("Requests", iter);

				if(request.getAttribute("RequestMessage") != null)
					request.setAttribute("RequestMessage", request.getAttribute("RequestMessage"));
				rd = request.getRequestDispatcher("displayPendingRequests.jsp");

			} 
			catch(final Exception e)
			{
				try
				{
					conn.rollBackTransaction();
					conn.closeConnection();
				}
				catch (final Throwable e1) 
				{
					e1.printStackTrace();
				}
			}
			finally
			{
				if(conn != null)
				{
					try
					{
						conn.commitTransaction();
						conn.closeConnection();
					}
					catch (final Throwable e) 
					{
						e.printStackTrace();
					}
				}
			}
		}
		else
		{
			request.setAttribute("RequestMessage", "Database under maintenance. Please try later.");
			rd = request.getRequestDispatcher("displayPendingRequests.jsp");
		}

		rd.forward(request, response);


	}

}
