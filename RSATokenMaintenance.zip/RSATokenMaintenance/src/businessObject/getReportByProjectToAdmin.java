package businessObject;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.AssociateBean;
import bean.ConnectionBean;
import bean.MasterBean;
import dao.AssociateDAO;
import dao.MasterDAO;

/**
 * Servlet implementation class getReportByProjectToAdmin
 */
public class getReportByProjectToAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getReportByProjectToAdmin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher rd = null;
		final ConnectionBean conn = new ConnectionBean();
		int isLoad = 1;
		final String selectedProjecID = request.getParameter("projectSelected");
		
		int Project_ID = 0;

		if(conn != null)
		{
			try
			{
				final List<?>  ProjectDetails=  MasterDAO.getProjectNames(conn.getConn());
				final Iterator<?> iter1 = ProjectDetails.iterator();
				request.setAttribute("ProjectDetails",iter1);
				
				if(selectedProjecID != null && selectedProjecID != "")
				{
					Project_ID = Integer.parseInt(selectedProjecID);
					isLoad = 0;
				}
				final List<?>  TokensDetails=  MasterDAO.getTokenDetailsByProjectToAdmin(Project_ID,conn.getConn());
				final Iterator<?> iter = TokensDetails.iterator();
				request.setAttribute("Tokens", iter);
				request.setAttribute("FirstTime",isLoad);
				rd = request.getRequestDispatcher("displayReportByProjectToAdmin.jsp");
			}
			catch(final Exception e)
			{
				try
				{
					conn.rollBackTransaction();
					conn.closeConnection();
				}
				catch (final Throwable e1) 
				{
					e1.printStackTrace();
				}
			}
			finally
			{
				if(conn != null)
				{
					try
					{
						conn.commitTransaction();
						conn.closeConnection();
					}
					catch (final Throwable e) 
					{
						e.printStackTrace();
					}
				}
			}
		}
		else
		{
			request.setAttribute("Message", "Database under maintenance. Please try later.");
			rd = request.getRequestDispatcher("Message.jsp");
		}

		rd.forward(request, response);


	}

}
