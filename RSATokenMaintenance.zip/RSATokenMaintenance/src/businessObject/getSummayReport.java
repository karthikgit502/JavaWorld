package businessObject;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import bean.ConnectionBean;
import dao.TokenDAO;

/**
 * Servlet implementation class getSummayReport
 */
public class getSummayReport extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public getSummayReport() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		RequestDispatcher rd = null;
		int Summary_Report [] = null;
		final ConnectionBean conn = new ConnectionBean();
		if(conn != null)
		{
			try
			{
				Summary_Report = TokenDAO.getSummaryReport(conn.getConn());
				request.setAttribute("Assigned_but_Not_Dispatched",Summary_Report[0]);
				request.setAttribute("Assigned_and_Dispatched",Summary_Report[1]);
				request.setAttribute("UnAssigned_count",Summary_Report[2]);
				request.setAttribute("Lost_count",Summary_Report[4]);
				request.setAttribute("Expired_count",Summary_Report[3]);
				request.setAttribute("Total_count",(Summary_Report[0]+Summary_Report[1]+Summary_Report[2]+Summary_Report[3]+Summary_Report[4]));
				rd = request.getRequestDispatcher("displaySummaryReport.jsp");
			}
			catch(final Exception e)
			{
				try
				{
					conn.rollBackTransaction();
					conn.closeConnection();
				}
				catch (final Throwable e1) 
				{
					e1.printStackTrace();
				}
			}
			finally
			{
				if(conn != null)
				{
					try
					{
						conn.commitTransaction();
						conn.closeConnection();
					}
					catch (final Throwable e) 
					{
						e.printStackTrace();
					}
				}
			}
		}
		else
		{
			request.setAttribute("Message", "Database under maintenance. Please try later.");
			rd = request.getRequestDispatcher("Message.jsp");
		}
		rd.forward(request, response);
	}

}
