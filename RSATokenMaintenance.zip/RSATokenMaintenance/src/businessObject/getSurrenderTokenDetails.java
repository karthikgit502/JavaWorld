package businessObject;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import bean.AssociateBean;
import bean.ConnectionBean;
import bean.MasterBean;
import dao.MasterDAO;
import dao.RequestDAO;
import dao.TokenDAO;

/**
 * Servlet implementation class getSurrenderTokenDetails
 */
public class getSurrenderTokenDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public getSurrenderTokenDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher rd = null;
		int TokenID = 0;
		final HttpSession Sr = request.getSession(false);
		final AssociateBean Associate=(AssociateBean) Sr.getAttribute("Associate");
		MasterBean Master = null;
		final ConnectionBean conn = new ConnectionBean();
		int Request_ID = 0;

		if(conn != null)
		{
			try 
			{
				TokenID = TokenDAO.get_TokenID(Associate.getAssociate_ID(),conn.getConn());
				Request_ID = RequestDAO.isRequestRaised(Associate.getAssociate_ID(),conn.getConn());
				if(TokenID > 0 && Request_ID == 0)
				{
					request.setAttribute("TokenID",TokenID);
					Master = MasterDAO.getMasterDetails(Associate.getAssociate_ID(),conn.getConn());
					final String ProjectName[]= new String[1];
					ProjectName[0]= Master.getProject_name();
					final int ProjectID[]= new int[1];
					ProjectID[0]= Master.getProject_id();
					Associate.setProject_ID(ProjectID);
					Associate.setProject_Name(ProjectName);
					request.setAttribute("Associate",Associate);
					rd = request.getRequestDispatcher("SurrenderTokenDetails.jsp");
				}
				else if(TokenID > 0 && Request_ID > 0)
				{
					request.setAttribute("Message", "You have already raised a request for surrender.");
					rd = request.getRequestDispatcher("Message.jsp");
				}
				else
				{
					request.setAttribute("TokenID",null);
					rd = request.getRequestDispatcher("SurrenderTokenDetails.jsp");
				}
				
			} 
			catch(final Exception e)
			{
				try
				{
					conn.rollBackTransaction();
					conn.closeConnection();
				}
				catch (final Throwable e1) 
				{
					e1.printStackTrace();
				}
			}
			finally
			{
				if(conn != null)
				{
					try
					{
						conn.commitTransaction();
						conn.closeConnection();
					}
					catch (final Throwable e) 
					{
						e.printStackTrace();
					}
				}
			}
		}
		else
		{
			request.setAttribute("Message", "Database under maintenance. Please try later.");
			rd = request.getRequestDispatcher("Message.jsp");
		}

		rd.forward(request, response);
	}

}
