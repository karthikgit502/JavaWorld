package businessObject;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import bean.ConnectionBean;
import bean.MasterBean;
import bean.MasterHistoryBean;
import dao.MasterDAO;
import dao.MasterHistoryDAO;

/**
 * Servlet implementation class getTokenDetailsByID
 */
public class getTokenDetailsByID extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public getTokenDetailsByID() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher rd = null;
		final String SToken_ID = request.getParameter("txtTokenId");
		final int Token_ID = Integer.parseInt(SToken_ID);
		final ConnectionBean conn = new ConnectionBean();
		if(conn != null)
		{
			try 
			{
				final List<bean.MasterBean>  Master =  MasterDAO.getToken_Details_By_ID(Token_ID,conn.getConn());
				final List<bean.MasterHistoryBean>  MasterHistory =  MasterHistoryDAO.getToken_Details_By_ID(Token_ID,conn.getConn());
				if( Master != null)
				{
					final Iterator<MasterBean> iter = Master.iterator();
					request.setAttribute("Master", iter);
					rd = request.getRequestDispatcher("displayTokenUserDetails.jsp");
				}
				else if( MasterHistory != null)
				{
					final Iterator<MasterHistoryBean> iter1 = MasterHistory.iterator();
					request.setAttribute("MasterHistory", iter1);
					rd = request.getRequestDispatcher("displayTokenUserDetails.jsp");					
				}
				else
				{
					request.setAttribute("Message", "Token does not Exists!");
					rd = request.getRequestDispatcher("passwordChangeMessage.jsp");
				}

			} 
			catch(final Exception e)
			{
				try
				{
					conn.rollBackTransaction();
					conn.closeConnection();
				}
				catch (final Throwable e1) 
				{
					e1.printStackTrace();
				}
			}
			finally
			{
				if(conn != null)
				{
					try
					{
						conn.commitTransaction();
						conn.closeConnection();
					}
					catch (final Throwable e) 
					{
						e.printStackTrace();
					}
				}
			}
		}
		else
		{
			request.setAttribute("Message", "Database under maintenance. Please try later.");
			rd = request.getRequestDispatcher("Message.jsp");
		}

		rd.forward(request, response);

	}

}
