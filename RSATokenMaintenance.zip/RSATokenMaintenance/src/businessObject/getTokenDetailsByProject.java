package businessObject;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import bean.AssociateBean;
import bean.ConnectionBean;
import bean.MasterBean;
import dao.AssociateDAO;
import dao.MasterDAO;

/**
 * Servlet implementation class getTokenDetailsByProject
 */
public class getTokenDetailsByProject extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public getTokenDetailsByProject() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher rd = null;
		final ConnectionBean conn = new ConnectionBean();
		int isLoad = 1;
		final String selectedProjecID = request.getParameter("projectSelected");
		final HttpSession Sr = request.getSession(false);
		int Project_ID = 0;
		AssociateBean Associate =(AssociateBean) Sr.getAttribute("Associate");

		if(conn != null)
		{
			try
			{
				Associate = (AssociateBean)AssociateDAO.getAssociateBean(Associate.getAssociate_ID(),conn.getConn());
				if(selectedProjecID != null && selectedProjecID != "")
				{
					Project_ID = Integer.parseInt(selectedProjecID);
					isLoad = 0;
				}
				final List<bean.MasterBean>  Tokens=  MasterDAO.getTokenDetailsByProject(Associate.getAssociate_ID(),Project_ID,conn.getConn());
				final Iterator<MasterBean> iter = Tokens.iterator();
				request.setAttribute("Tokens", iter);
				request.setAttribute("Associate", Associate);
				request.setAttribute("FirstTime",isLoad);
				rd = request.getRequestDispatcher("displayReportByProject.jsp");
			}
			catch(final Exception e)
			{
				try
				{
					conn.rollBackTransaction();
					conn.closeConnection();
				}
				catch (final Throwable e1) 
				{
					e1.printStackTrace();
				}
			}
			finally
			{
				if(conn != null)
				{
					try
					{
						conn.commitTransaction();
						conn.closeConnection();
					}
					catch (final Throwable e) 
					{
						e.printStackTrace();
					}
				}
			}
		}
		else
		{
			request.setAttribute("Message", "Database under maintenance. Please try later.");
			rd = request.getRequestDispatcher("Message.jsp");
		}

		rd.forward(request, response);

	}

}
