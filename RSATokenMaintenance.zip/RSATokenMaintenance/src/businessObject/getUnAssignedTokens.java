package businessObject;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import bean.ConnectionBean;
import bean.MasterBean;
import dao.MasterDAO;

public class getUnAssignedTokens extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public getUnAssignedTokens() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd = null;
		final ConnectionBean conn = new ConnectionBean();
		if(conn != null)
		{
			try 
			{
				final List<bean.MasterBean>  Tokens =  MasterDAO.getUnAssignedToken(conn.getConn());
				final Iterator<MasterBean> iter = Tokens.iterator();
				request.setAttribute("Tokens", iter);
				rd = request.getRequestDispatcher("displayUnAssignedTokens.jsp");
			}
			catch(final Exception e)
			{
				try
				{
					conn.rollBackTransaction();
					conn.closeConnection();
				}
				catch (final Throwable e1) 
				{
					e1.printStackTrace();
				}
			}
			finally
			{
				if(conn != null)
				{
					try
					{
						conn.commitTransaction();
						conn.closeConnection();
					}
					catch (final Throwable e) 
					{
						e.printStackTrace();
					}
				}
			}
		}
		else
		{
			request.setAttribute("Message", "Database under maintenance. Please try later.");
			rd = request.getRequestDispatcher("Message.jsp");
		}

		rd.forward(request, response);


	}

}
