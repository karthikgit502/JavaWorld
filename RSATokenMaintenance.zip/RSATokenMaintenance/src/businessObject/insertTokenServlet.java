package businessObject;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import bean.ConnectionBean;
import bean.TokenBean;
import dao.TokenDAO;

/**
 * Servlet implementation class insertTokenServlet
 */
public class insertTokenServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public insertTokenServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		RequestDispatcher rd = null;
		String status="New Token";
		int Start_Token_ID = Integer.parseInt(request.getParameter("txtStartTokenId"));
		int End_Token_ID = Integer.parseInt(request.getParameter("txtEndTokenId"));
		String exp_date = request.getParameter("txtExpDate");
		TokenBean Token = null;
		int New_Token =0;
		int Duplicate_Token=0;

	    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	    DateFormat dateFormat1 = new SimpleDateFormat("dd-MM-yyyyy");
	    
	    
	    Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE,10);
	    
		String today = dateFormat.format(cal.getTime());
		String Expiry_Str = ""+exp_date;
		ConnectionBean conn = new ConnectionBean();
		System.out.print("sdfsdf");
		try
		{
			
			Date Expiry_Date=dateFormat1.parse(Expiry_Str);
			Date Today = dateFormat.parse(today);
			
			if(Expiry_Date.before(Today) || Expiry_Date.equals(Today) )
			{	
				request.setAttribute("start",Start_Token_ID);
				request.setAttribute("end",End_Token_ID);
				
				request.setAttribute("InsertMessage","Expiry Date should be greater 10 Days from Today!!!");
				rd=request.getRequestDispatcher("insertNew_Token.jsp");	
			}
			else
			{
				 java.util.Date utilDate = Expiry_Date;
				 java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
				int i, a;  
				for( i = Start_Token_ID; i <= End_Token_ID; i++)
				{
					Token = new TokenBean();
					Token.setToken_ID(i);
					Token.setExpiry_Date(sqlDate);
					Token.setToken_Status(status);
					a = TokenDAO.insertNew_Token(Token, conn.getConn());
					if (a != 0)
						New_Token ++;
					else
						Duplicate_Token ++;
				}
				
				String msg;
				if(New_Token > 0 && Duplicate_Token == 0)
					msg = ""+New_Token +" Tokens inserted successfully";
				else if(New_Token > 0 && Duplicate_Token > 0)
					msg = ""+New_Token +" Tokens inserted successfully with "+ Duplicate_Token +" duplicates.";
				else 
					msg = "No Tokens inserted.All Tokens are already exists in database.";
				
				request.setAttribute("InsertMessage",msg);
				rd=request.getRequestDispatcher("insertNew_Token.jsp");
			}
			
		}	
		catch(final Exception e)
		{
			try
			{
				conn.rollBackTransaction();
				conn.closeConnection();
			}
			catch (final Throwable e1) 
			{
				e1.printStackTrace();
			}
		}
		finally
		{
			if(conn != null)
			{
				try
				{
					conn.commitTransaction();
					conn.closeConnection();
				}
				catch (final Throwable e) 
				{
					e.printStackTrace();
				}
			}
		}
		rd.forward(request, response);
	}



}


