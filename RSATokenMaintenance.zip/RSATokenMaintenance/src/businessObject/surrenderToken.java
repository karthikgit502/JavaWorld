package businessObject;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import bean.AssociateBean;
import bean.ConnectionBean;
import bean.RequestBean;
import dao.AssociateDAO;
import dao.DispatchDAO;
import dao.MailDAO;
import dao.RequestDAO;
import dao.RequestHistoryDAO;

public class surrenderToken extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public surrenderToken() {
		super();
	}
	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {

	}

	protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher rd = null;
		final ConnectionBean conn = new ConnectionBean();
		RequestBean Request= null;
		boolean Dispatch;
		boolean sendMail = true ;

		int Request_ID;
		int a = 0;

		final HttpSession Sr = request.getSession(false);
		final AssociateBean Associate=(AssociateBean) Sr.getAttribute("Associate");

		if(conn != null)
		{
			try
			{
				final int Assigned_token = AssociateDAO.isTokenAssigned(Associate.getAssociate_ID(),conn.getConn());
				Request_ID = RequestDAO.isRequestRaised(Associate.getAssociate_ID(), conn.getConn());
				Dispatch = DispatchDAO.Dispatch_Status(Associate.getAssociate_ID(),conn.getConn());
				if( Assigned_token != 0  &&  Dispatch )
				{
					if( Request_ID != 0 )
					{
						request.setAttribute("Message" ,"You have already raised a request!.Your request ID: "+ Request_ID);
						rd = request.getRequestDispatcher("Message.jsp");
					}
					else
					{				
						Request = new RequestBean();
						Request.setRequest_Reason_For_Apply("Surrender");
						Request.setRequest_Associate_ID( Associate.getAssociate_ID());
						Request.setRequest_Status("Pending for Approval");
						Request.setRequest_Associate_Name(Associate.getAssociate_Name());
						Request.setRequest_Project_ID(Associate.getUniqueProject_ID(0));
						Request.setRequest_Project_Name(Associate.getUniqueProject_Name(0));
						Request.setSupervisor_ID(Associate.getSupervisor_ID());

						if( (Associate.getAssociate_Type()).equals("SUPER_USER") )
							Request.setRequest_Status("Approved");

						a = RequestDAO.insertNew_Request(Request,conn.getConn());
						Request = RequestDAO.getOpenRequestStatus(Associate.getAssociate_ID(),conn.getConn());
						RequestHistoryDAO.insertNewRequestUsingID(Request.getRequest_ID(),conn.getConn());

						if(  a != 0 && Associate.getAssociate_Type().equals("SUPER_USER") )
						{
							RequestHistoryDAO.insertApprovedRequest(Request.getRequest_ID(),conn.getConn());
							request.setAttribute("Message" ,"Request Raised Successfully.");
							rd = request.getRequestDispatcher("Message.jsp");

						}
						else{
							if( a != 0)
							{
								request.setAttribute("Message" ,"Request Raised Successfully!");
								rd = request.getRequestDispatcher("Message.jsp");
							}
						}
					}
				}
				else
				{
					if( Request_ID != 0 )
					{
						request.setAttribute("Message" ,"You are already raised a request!.Your Request ID: "+ Request_ID);
						rd = request.getRequestDispatcher("Message.jsp");
					}
					else
					{
						request.setAttribute("Message" ,"Token Assigned for You!, Please Collect it and Then Try!");
						rd = request.getRequestDispatcher("Message.jsp");
					}
				}
			}
			catch(final Exception e)
			{
				sendMail = false;
				try
				{
					conn.rollBackTransaction();
					conn.closeConnection();
				}
				catch (final Throwable e1) 
				{
					e1.printStackTrace();
				}
			}
			finally
			{
				if(conn != null)
					try{
						if(sendMail)
						{
							if(  a != 0 && (Associate.getAssociate_Type()).equals("SUPER_USER") )
								MailDAO.sendMailToAdmin(Associate,Request,conn.getConn());
							else
								if(a != 0)
									MailDAO.sendMailaboutRequestRaise(Request,conn.getConn());
						}

						conn.commitTransaction();
						conn.closeConnection();
					}
				catch (final Throwable e) 
				{
					e.printStackTrace();
				}
			}
		}
		else
		{
			request.setAttribute("Message", "Database under maintenance. Please try later.");
			rd = request.getRequestDispatcher("loginMessage.jsp");
		}

		rd.forward(request, response);
	}

}
