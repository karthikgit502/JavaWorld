package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import bean.AssociateBean;
import bean.MasterBean;
import bean.RequestBean;

public class AssociateDAO  
{
	
	
	
	public static List<AssociateBean> getSupervisorNames(final Connection conn) 
	{
		List<AssociateBean> AssociateDetails = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		AssociateBean Supervisor;
		try {
			stmt = conn.prepareStatement(AssociateQueries.GET_SUPERVISORNAMES);
			rs = stmt.executeQuery();
			if(rs != null)
			{
				AssociateDetails = new ArrayList<AssociateBean>();
				while( rs.next())
				{
					Supervisor = new AssociateBean();
					Supervisor.setAssociate_Name(rs.getString(1));
					Supervisor.setAssociate_ID(rs.getInt(2));
					AssociateDetails.add(Supervisor);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}


		return AssociateDetails;
	}

	
	
	public static AssociateBean selectUser(final int Associate_ID, final String password,final Connection conn)
	{
		AssociateBean Associate = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.prepareStatement(AssociateQueries.ASSOCIATE_PASSWORD_SELECT);
			stmt.setInt(1, Associate_ID);
			stmt.setString(2, password);
			rs = stmt.executeQuery();
			if (rs.next())
			{
				final MasterBean Master = MasterDAO.getMasterDetails(Associate_ID,conn);
				final RequestBean Request = RequestDAO.getOpenRequestStatus(Associate_ID,conn);
				if( (rs.getString(2)).equals(password))
				{
					Associate = getAssociateBean(Associate_ID,conn);
					Associate.setAssociate_Password(password);
					final String Associate_Type = rs.getString(3);
					Associate.setAssociate_Type(Associate_Type);
					if(Request != null)
					{
						Associate.setUniqueProject_ID(Request.getRequest_Project_ID());
						Associate.setUniqueProject_Name(Request.getRequest_Project_Name());
					}
					else if(Master != null)
					{
						Associate.setUniqueProject_ID(Master.getProject_id());
						Associate.setUniqueProject_Name(Master.getProject_name());
					}
					else
					{
						Associate.setAssociate_Password(password);
						Associate.setAssociate_Type(Associate_Type);
					}
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}


		return Associate;
	}
	public static int updatePassword(final int Associate_ID, final String Newpassword,final Connection conn)
	{
		int updated = 0;
		PreparedStatement stmt = null;
		try {
			stmt = conn.prepareStatement(AssociateQueries.UPDATE_ASSOCIATE_PASSWORD);
			stmt.setString(1, Newpassword);
			stmt.setInt(2, Associate_ID);
			updated = stmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}


		return updated;
	}
	public static AssociateBean getAssociateBean(final int Associate_ID,final Connection conn)
	{
		AssociateBean Associate = null;
		int project_id[],i=0;
		String Project_name[];
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.prepareStatement(AssociateQueries.ASSOCIATE_DETAILS_SELECT);
			stmt.setInt(1, Associate_ID);
			rs = stmt.executeQuery();
			if(rs.next())
			{
				Associate = new AssociateBean();
				Associate.setAssociate_ID(Associate_ID);
				Associate.setAssociate_Name(rs.getString(1));
				Associate.setSupervisor_ID(rs.getInt(4));
				Associate.setSupervisor_Name(rs.getString(5));
				Associate.setDesignation(rs.getString(6));
				Associate.setEmail_ID(rs.getString(7));
				Associate.setGrade(rs.getString(8));
				while( rs.next())
					i++;
				project_id = new int[i+1];
				Project_name = new String[i+1];
				rs = stmt.executeQuery();
				i=0;

				while( rs.next())
				{
					project_id[i] = rs.getInt(2);
					Project_name[i] = rs.getString(3);
					i++;
				}
				Associate.setProject_ID(project_id);
				Associate.setProject_Name(Project_name);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}


		return Associate;
	}
	
	public static List<AssociateBean> getUnAssigned_Associate(final int Supervisor_ID,final Connection conn)
	
	{
		List<AssociateBean> AssociateDetails = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.prepareStatement(AssociateQueries.GET_UNASSIGNED_ASSOCIATES_ID);
			stmt.setInt(1,Supervisor_ID);
			rs = stmt.executeQuery();
			if(rs != null)
			{
				AssociateDetails = new ArrayList<AssociateBean>();
				while( rs.next())
					AssociateDetails.add(getAssociateBean(rs.getInt(1),conn));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return AssociateDetails;
	}
	
	public static String getForgotPassword( final int Associate_ID ,final Connection conn)
	{
		String Password= null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.prepareStatement(AssociateQueries.GET_PASSWORD);
			stmt.setInt(1, Associate_ID);
			rs = stmt.executeQuery();
			if (rs.next())
				Password = rs.getString(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}


		return Password;
	}
	public static int isTokenAssigned( final int Associate_ID,final Connection conn)
	{
		int Token_ID=0;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.prepareStatement(AssociateQueries.IS_TOKEN_ASSIGNED);
			stmt.setInt(1, Associate_ID);
			stmt.setString(2,"Assigned");
			stmt.setString(3,"Re-Assigned");
			rs = stmt.executeQuery();
			if ( rs.next() )
				Token_ID = rs.getInt(1);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}


		return Token_ID;
	}
	public static boolean isRegisteredAssociate( final int Associate_ID, final Connection conn ) 
	{
		PreparedStatement stmt = null;
		ResultSet rs = null;
		boolean result = false;
		try {
			stmt = conn.prepareStatement(AssociateQueries.IS_REGISTERED_ASSOCIATE);
			stmt.setInt(1, Associate_ID);
			rs = stmt.executeQuery();
			if ( rs.next() )
				result = true;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}


		return result;
	}
	public static boolean isNewAssociate( final int Associate_ID, final Connection conn ) 
	{
		PreparedStatement stmt = null;
		ResultSet rs = null;
		boolean result = false;
		try {
			stmt = conn.prepareStatement(AssociateQueries.IS_NEW_ASSOCIATE);
			stmt.setInt(1, Associate_ID);
			rs = stmt.executeQuery();
			if ( rs.next() )
				result = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}


		return result;
	}
	public static AssociateBean registerNewAssociate(final int Associate_ID,final String Email_ID,final Connection conn)
	{
		PreparedStatement stmt = null;
		AssociateBean NewAssociate = null;
		try {
			stmt = conn.prepareStatement(AssociateQueries.REGISTER_NEW_ASSOCIATE);
			NewAssociate = new AssociateBean();
			String Password = NewAssociate.generatePassword();
			stmt.setInt(1,Associate_ID);
			stmt.setString(2,Password);
			stmt.setString(4,Email_ID);

			if(getAssociateType(Associate_ID,conn))
				stmt.setString(3,"SUPER_USER");
			else
				stmt.setString(3,"NORMAL_USER");

			if( stmt.executeUpdate() == 0 )
				NewAssociate = null;
			else
			{
				NewAssociate = getAssociateBean( Associate_ID,conn);
				NewAssociate.setAssociate_Password(Password);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}



		return NewAssociate;
	}
	public static String getEmaiID( final int Associate_ID,final Connection conn ) 
	{
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String emailID = null;

		try {
			stmt =	conn.prepareStatement(AssociateQueries.ASSOCIATE_EMAIL);
			stmt.setInt(1, Associate_ID);
			rs = stmt.executeQuery();
			if (rs.next())
				emailID = rs.getString(1);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}


		return emailID;
	}
	public static AssociateBean getAdminDetails(final Connection conn)
	{
		PreparedStatement stmt = null;
		ResultSet rs = null;
		AssociateBean Adim = null;
		try {
			stmt = conn.prepareStatement(AssociateQueries.ADMIN_DETAILS);
			stmt.setString(1,"ADMIN_USER");
			rs = stmt.executeQuery();
			if (rs.next())
				Adim = getAssociateBean(rs.getInt(1),conn);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}


		return Adim;
	}
	public static boolean getAssociateType(final int Associate_ID,final Connection conn) 
	{
		PreparedStatement stmt = null;
		ResultSet rs = null;
		boolean result = false;
		try {
			stmt = conn.prepareStatement(AssociateQueries.GET_SUPER_USER);
			stmt.setInt(1,Associate_ID);
			rs = stmt.executeQuery();
			if(rs.next())
				result = true;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}



		return result;
	}
}
