package dao;

public class AssociateQueries
{
	//
	public static final String ASSOCIATE_PASSWORD_SELECT =
		"select	* from RSA_USER_PASSWORD where ASSOCIATE_ID = ? AND PASSWORD = ?";
	
	public static final String GET_SUPERVISORNAMES =
		"select distinct(RSA_USER.ASSOCIATE_NAME),RSA_USER.ASSOCIATE_ID from " +
		" RSA_USER inner join  RSA_TOKEN_MASTER on RSA_USER.ASSOCIATE_ID = RSA_TOKEN_MASTER.HCM_SUPERVISOR_ID";
	
	public static final String GET_PASSWORD =
		"select	PASSWORD from RSA_USER_PASSWORD where ASSOCIATE_ID = ? ";

	//
	public static final String UPDATE_ASSOCIATE_PASSWORD =
		"update RSA_USER_PASSWORD set PASSWORD = ? where ASSOCIATE_ID = ? ";

	//
	public static final String ASSOCIATE_DETAILS_SELECT =
		"select RSA_USER.ASSOCIATE_NAME,RSA_USER.PROJECT_ID,RSA_USER.PROJECT_NAME,RSA_USER.HCM_SUPERVISOR_ID,RSA_USER.HCM_SUPERVISOR_NAME,RSA_USER.DESIGNATION,RSA_USER_PASSWORD.EMAIL_ID,"+
		"RSA_USER.ASSOCIATE_GRADE from RSA_USER inner join  RSA_USER_PASSWORD on RSA_USER.ASSOCIATE_ID = RSA_USER_PASSWORD.ASSOCIATE_ID where RSA_USER_PASSWORD.ASSOCIATE_ID = ?";
	
	public static final String GET_ASSOCIATE_DETAILS =
		"select * from RSA_USER where ASSOCIATE_ID = ?";
	
	public static final String ADMIN_DETAILS =
		"select * from RSA_USER where ASSOCIATE_ID = " +
		"(select ASSOCIATE_ID from RSA_USER_PASSWORD where ASSOCIATE_TYPE = ? )";
	
	public static final String ASSOCIATE_NAME =
		"select	ASSOCIATE_NAME from RSA_USER where ASSOCIATE_ID = ?";
	
	public static final String ASSOCIATE_EMAIL =
		"select	EMAIL_ID from RSA_USER_PASSWORD where ASSOCIATE_ID = ?";
	
	public static final String ASSOCIATE =
		"select	* from RSA_USER where ASSOCIATE_ID = ?";
	
	public static final String IS_TOKEN_ASSIGNED =
		"select	TOKEN_ID from RSA_TOKEN_MASTER where ASSOCIATE_ID = ?" +
		" and ( STATUS = ?" +
		" or " +
		" STATUS = ? )";
	
	public static final String REGISTER_NEW_ASSOCIATE =
		"insert into RSA_USER_PASSWORD(" +
		"ASSOCIATE_ID," +
		"PASSWORD," +
		"ASSOCIATE_TYPE,"+
		"EMAIL_ID)" +
		"values (?,?,?,?)";

	/*public static final String GET_UNASSIGNED_ASSOCIATE =
		"SELECT * FROM  RSA_USER  user where HCM_SUPERVISOR_ID = ?" +
		" and ASSOCIATE_ID not in ( select ASSOCIATE_ID from RSA_TOKEN_MASTER" +
		" WHERE ASSOCIATE_ID = user.ASSOCIATE_ID and STATUS="+"'Assigned'" + " or" +
		" STATUS=" + "'Reassigned'" + ")" +
		
		" and ASSOCIATE_ID not in ( select ASSOCIATE_ID from RSA_TOKEN_REQUEST" +
		" WHERE ASSOCIATE_ID = user.ASSOCIATE_ID and STATUS="+"'Approved'" + " or" +
		" STATUS=" + "'Pending for Approval'" + " or " +
		" STATUS=" + "'Queued with Admin'" + ")";
	*/
	
	public static final String GET_ASSIGNED_ASSOCIATE =
	"select ASSOCIATE_ID from RSA_TOKEN_MASTER WHERE DISPATCH_STATUS = 'YES' and"+ 
	" ( ASSOCIATE_ID not in (select ASSOCIATE_ID from RSA_TOKEN_REQUEST ) and"+
	" ASSOCIATE_ID in (select ASSOCIATE_ID FROM  RSA_USER where HCM_SUPERVISOR_ID = ? ) )";
	
	public static final String GET_UNASSIGNED_ASSOCIATES_ID =
		"SELECT distinct ASSOCIATE_ID FROM  RSA_USER where HCM_SUPERVISOR_ID = ? " + 
		" and " +
		"( ASSOCIATE_ID not in ( select ASSOCIATE_ID from RSA_TOKEN_MASTER  WHERE STATUS = 'Assigned' or STATUS = 'Re-Assigned') and " +
		"ASSOCIATE_ID not in (select ASSOCIATE_ID from RSA_TOKEN_REQUEST 	WHERE STATUS = 'Approved' or STATUS = 'Pending for Approval'  ) and "+
	    "ASSOCIATE_ID not in (select distinct HCM_SUPERVISOR_ID from RSA_USER)"+
    	" and ASSOCIATE_ID in (select ASSOCIATE_ID from RSA_USER_PASSWORD) )";
			
	public static final String IS_REGISTERED_ASSOCIATE =
		"SELECT ASSOCIATE_ID FROM RSA_USER_PASSWORD WHERE ASSOCIATE_ID = ?";

	
	public static final String IS_NEW_ASSOCIATE =
		"SELECT ASSOCIATE_ID FROM RSA_USER WHERE ASSOCIATE_ID = ? " +
		" and ASSOCIATE_ID NOT IN(SELECT ASSOCIATE_ID FROM RSA_USER_PASSWORD) ";
 
	public static final String GET_SUPER_USER =
		"SELECT distinct ASSOCIATE_ID FROM  RSA_USER where ASSOCIATE_ID = ? " + 
		" and " +
		" ASSOCIATE_ID in ( select distinct HCM_SUPERVISOR_ID from RSA_USER )"; 
		
	
}
