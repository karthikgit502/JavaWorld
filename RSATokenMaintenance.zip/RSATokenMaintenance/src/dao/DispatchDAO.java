package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import bean.DispatchBean;
import bean.MasterBean;

public class DispatchDAO  
{
	public static DispatchBean getDispatchDetails(int Associate_ID,Connection conn) 
	{
		DispatchBean Dispatch= null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.prepareStatement(DispatchQueries.GET_DISPATCH_DETAILS);
			stmt.setInt(1,Associate_ID);
			stmt.setString(2,"NO");
			rs = stmt.executeQuery();
			if (rs.next())
			{
				Dispatch = new DispatchBean();
				Dispatch.setAssociate_ID(Associate_ID);
				Dispatch.setReason_For_Apply(rs.getString(2));
				Dispatch.setNew_Tokn_ID(rs.getInt(1));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}


		return Dispatch;
	}
	public static List<MasterBean>  getNotDispatched_Token_Details(Connection conn)
	{
		PreparedStatement stmt = null;
		ResultSet rs = null;
		List<MasterBean> TokenDetails = null;
		MasterBean Token = null;
		try {
			stmt = conn.prepareStatement(MasterQueries.GET_NOT_DISPATCHED_TOKEN_DETAILS);
			rs=stmt.executeQuery();
			if(rs != null)
			{
				TokenDetails = new ArrayList<MasterBean>();
				while( rs.next())
				{
					Token = new MasterBean();
					Token.setProject_id(rs.getInt(1));
					Token.setProject_name(rs.getString(2));
					Token.setAssociate_id(rs.getInt(3));
					Token.setAassociate_name(rs.getString(4));
					Token.setToken_id(rs.getInt(5));
					Token.setAssigned_date(rs.getTimestamp(6));
					Token.setReason_For_Apply(rs.getString(7));
					TokenDetails.add(Token);
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}


		return TokenDetails;
	}
	public static int dispatchToken(int Associate_ID,Connection conn)
	{
		PreparedStatement stmt = null;
		int result = 0;
		try {
			stmt = conn.prepareStatement(DispatchQueries.DISPATCH_TOKEN);
			stmt.setInt(1,Associate_ID);
			result = stmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}


		return result;
	}
	public static boolean Dispatch_Status(int Associate_ID,Connection conn) 
	{
		PreparedStatement stmt = null;
		ResultSet rs = null;
		boolean result = false;

		try {
			stmt = conn.prepareStatement(DispatchQueries.DISPATCH_STATUS);
			stmt.setInt(1,Associate_ID);
			rs = stmt.executeQuery();
			if (rs.next())
				if( rs.getString(1).equals("YES"))
					result = true;


		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return result;
	}
}