package dao;

public class DispatchQueries 
{
	public static final String GET_DISPATCH_DETAILS =
	    "select TOKEN_ID,REASON_FOR_APPLY from RSA_TOKEN_MASTER " +
		"where ASSOCIATE_ID = ? "+ 
		" and DISPATCH_STATUS = ? ";

	
	public static final String DISPATCH_TOKEN =
		"update RSA_TOKEN_MASTER set DISPATCH_STATUS ='YES'"+
		"where ASSOCIATE_ID = ? "+
		" and DISPATCH_STATUS = 'NO'";


	public static final String DISPATCH_STATUS =
		"select DISPATCH_STATUS from RSA_TOKEN_MASTER "+
		"where ASSOCIATE_ID = ? ";
		
}
