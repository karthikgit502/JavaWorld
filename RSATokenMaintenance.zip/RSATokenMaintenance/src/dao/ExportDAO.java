package dao;
import java.io.*;
import java.sql.Connection;
import java.util.*;
import bean.ExcelBean;
import bean.MailBean;
import bean.MasterBean;
import bean.MasterHistoryBean;
import jxl.write.*;
public class ExportDAO 
{
	public void exportExpiredTokenDetails( Iterator<?> iter,Connection conn,String EmailID)
	{
		String WorkBookName = "c:/Expired.xls";
		String WorkSheetName = "ExpiredTokenDetails";
		ExcelBean ExpiredTokenReport = new ExcelBean(WorkBookName);
		String LabelName [] = {"S.No","Associate ID","Associate Name","Project Name","Token ID","Surrendered Date","Expiry Date"};
		try 
		{
			WritableWorkbook WorkBook = ExpiredTokenReport.createExcelFile();
			WritableSheet WorkSheet = ExpiredTokenReport.writeLabel(WorkBook, LabelName,WorkSheetName);
			int column =0;
			int row = 1;
			int Sno = 1;
			MasterHistoryBean Report = new MasterHistoryBean();
			while (iter.hasNext()) 
			{
				Report = (MasterHistoryBean) iter.next();
				if(Report.getAassociate_name()== null)
				{
					ExpiredTokenReport.addLabel(WorkSheet,column, row,""+Sno);
					ExpiredTokenReport.addLabel(WorkSheet, ++column, row,"N/A");
					ExpiredTokenReport.addLabel(WorkSheet, ++column, row,"N/A");
					ExpiredTokenReport.addLabel(WorkSheet, ++column, row,"N/A");
					ExpiredTokenReport.addNumber(WorkSheet,++column, row,Report.getToken_id());
					ExpiredTokenReport.addLabel(WorkSheet, ++column, row,Report.getProcessedDateInString());
					ExpiredTokenReport.addLabel(WorkSheet, ++column, row,Report.getExpiry_date());
				}
				else
				{
					ExpiredTokenReport.addLabel(WorkSheet,column, row,""+Sno);
					ExpiredTokenReport.addLabel(WorkSheet,++column, row,""+Report.getAssociate_id());
					ExpiredTokenReport.addLabel(WorkSheet, ++column, row,Report.getAassociate_name());
					ExpiredTokenReport.addLabel(WorkSheet, ++column, row,Report.getProject_name());
					ExpiredTokenReport.addNumber(WorkSheet,++column, row,Report.getToken_id());
					ExpiredTokenReport.addLabel(WorkSheet, ++column, row,Report.getProcessedDateInString());
					ExpiredTokenReport.addLabel(WorkSheet, ++column, row,Report.getExpiry_date());
				}
				row++;
				column = 0;
				Sno++;
			}	
			
			ExpiredTokenReport.closeWorkBook(WorkBook);
			
			MailBean Mail = new MailBean();
			String CC[] = null;
			Mail.setCC(CC);
			Mail.setSubject("Expired Token Report");
			Mail.setTo(EmailID);
			Mail.sendMailWithAttachement(WorkBookName);
			
		}
		catch (WriteException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void exportLostTokenDetails( Iterator<?> iter,Connection conn,String EmailID)
	{
		String WorkBookName = "c:/Lost.xls";
		String WorkSheetName = "LostTokenDetails";
		ExcelBean ExpiredTokenReport = new ExcelBean(WorkBookName);
		String LabelName [] = {"S.No","Associate ID","Associate Name","Project Name","Token ID","Token Lost Date"};
		try 
		{
			WritableWorkbook WorkBook = ExpiredTokenReport.createExcelFile();
			WritableSheet WorkSheet = ExpiredTokenReport.writeLabel(WorkBook, LabelName,WorkSheetName);

			int column =0;
			int row = 1;
			int Sno = 1;

			MasterHistoryBean Report = new MasterHistoryBean();

			while (iter.hasNext()) 
			{
				Report = (MasterHistoryBean) iter.next();
				if(Report.getAassociate_name()== null)
				{
					ExpiredTokenReport.addLabel(WorkSheet,column, row,""+Sno);
					ExpiredTokenReport.addLabel(WorkSheet, ++column, row,"N/A");
					ExpiredTokenReport.addLabel(WorkSheet, ++column, row,"N/A");
					ExpiredTokenReport.addLabel(WorkSheet, ++column, row,"N/A");
					ExpiredTokenReport.addNumber(WorkSheet,++column, row,Report.getToken_id());
					ExpiredTokenReport.addLabel(WorkSheet, ++column, row,Report.getProcessedDateInString());
				}
				else
				{
					ExpiredTokenReport.addLabel(WorkSheet,column, row,""+Sno);
					ExpiredTokenReport.addLabel(WorkSheet,++column, row,""+Report.getAssociate_id());
					ExpiredTokenReport.addLabel(WorkSheet, ++column, row,Report.getAassociate_name());
					ExpiredTokenReport.addLabel(WorkSheet, ++column, row,Report.getProject_name());
					ExpiredTokenReport.addNumber(WorkSheet,++column, row,Report.getToken_id());
					ExpiredTokenReport.addLabel(WorkSheet, ++column, row,Report.getProcessedDateInString());
				}
				row++;
				column = 0;
				Sno++;
			}	
			ExpiredTokenReport.closeWorkBook(WorkBook);
			MailBean Mail = new MailBean();
			String CC[] = null;
			Mail.setCC(CC);
			Mail.setSubject("Lost Token Report");
			Mail.setTo(EmailID);
			Mail.sendMailWithAttachement(WorkBookName);

		}
		catch (WriteException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void exportAssignedTokenDetails( Iterator<?> iter,Connection conn,String EmailID)
	{
		String WorkBookName = "c:/Assigned.xls";
		String WorkSheetName = "AssingedTokenDetails";
		ExcelBean ExpiredTokenReport = new ExcelBean(WorkBookName);
		String LabelName [] = {"S.No","Associate ID","Associate Name","Project Name","Token ID","Assigned Date","Expiry Date","Reason For Apply"};
		try 
		{
			WritableWorkbook WorkBook = ExpiredTokenReport.createExcelFile();
			WritableSheet WorkSheet = ExpiredTokenReport.writeLabel(WorkBook, LabelName,WorkSheetName);

			int column =0;
			int row = 1;
			int Sno = 1;

			MasterBean Report = new MasterBean();

			while (iter.hasNext()) 
			{
				Report = (MasterBean) iter.next();
				ExpiredTokenReport.addLabel(WorkSheet,column, row,""+Sno);
				ExpiredTokenReport.addLabel(WorkSheet,++column, row,""+Report.getAssociate_id());
				ExpiredTokenReport.addLabel(WorkSheet, ++column, row,Report.getAassociate_name());
				ExpiredTokenReport.addLabel(WorkSheet, ++column, row,Report.getProject_name());
				ExpiredTokenReport.addNumber(WorkSheet,++column, row,Report.getToken_id());
				ExpiredTokenReport.addLabel(WorkSheet, ++column, row,Report.getAssigned_dateInString());
				ExpiredTokenReport.addLabel(WorkSheet, ++column, row,Report.getExpiry_date());
				ExpiredTokenReport.addLabel(WorkSheet, ++column, row,Report.getReason_For_Apply());
				row++;
				column = 0;
				Sno++;
			}	
			
			 
			ExpiredTokenReport.closeWorkBook(WorkBook);
			MailBean Mail = new MailBean();
			String CC[] = null;
			Mail.setCC(CC);
			Mail.setSubject("Assigned Token Report");
			Mail.setTo(EmailID);
			Mail.sendMailWithAttachement(WorkBookName);

		}
		catch (WriteException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e) {
			e.printStackTrace();
		}

	}

}

