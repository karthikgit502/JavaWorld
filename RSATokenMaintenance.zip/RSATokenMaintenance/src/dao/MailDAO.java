package dao;

import java.sql.Connection;

import bean.AssociateBean;
import bean.MasterBean;
import bean.MasterHistoryBean;
import bean.RequestBean;
import bean.MailBean;
import bean.RequestHistoryBean;
import bean.TokenBean;

public class MailDAO 
{


	public static void sendMailaboutAutoAssignedToken(RequestBean Request,Connection conn) throws Exception
	{
		MailBean Mail = new MailBean();
		AssociateBean Requested_Associate= AssociateDAO.getAssociateBean(Request.getRequest_Associate_ID(),conn);
		AssociateBean Supervisor = AssociateDAO.getAssociateBean(Requested_Associate.getSupervisor_ID(),conn);
		AssociateBean Admin = AssociateDAO.getAdminDetails(conn);
		Mail.setTo(Requested_Associate.getEmail_ID());
		String CC[] = {Supervisor.getEmail_ID()};
		Mail.setCC(CC);
		Mail.setSubject("RSA Token Assigned");

		TokenBean Token = TokenDAO.get_Token_Details_Before_Dispatch(Requested_Associate.getAssociate_ID(),conn);

		String EmailMessage="<h4>Hi,</h4>"+
		"    The below mentioned RSA token has been assigned by you Manager,  please collect your token from the RSA coordinator.(Associate ID: "+Admin.getAssociate_ID()+ ")"+				
		"<br>"+
		"<br>"+
		"<table border='1'>"+
		"  	<tr>"+
		"   	<td>Token ID</td>"+
		"		<td>"+Token.getToken_ID()+"</td>"+
		"	</tr>"+

		"  	<tr>"+
		"   	<td>Token Expiry Date</td>"+
		"		<td>"+Token.getExpiry_Date()+"</td>"+
		"	</tr>"+

		"  	<tr>"+
		"   	<td>Status</td>"+
		"		<td>"+Request.getRequest_Status()+"</td>"+
		"	</tr>"+
		"</table>"+
		"<br>"+
		"<pre>With Regards"+
		"<pre>  ESI-PMO."+
		"<hr />"+
		"<font size='2' color='red' face='Courier New'>   Note: This is a System Generated Mail. We request you not to reply to this message.</font>";

		Mail.setMessage(EmailMessage);
		Mail.sendMail();
	}	

	public static void sendMailaboutRequestReject(RequestHistoryBean Request,Connection conn) throws Exception
	{
		MailBean Mail = new MailBean();
		AssociateBean Requested_Associate= AssociateDAO.getAssociateBean(Request.getRequest_Associate_ID(),conn);
		AssociateBean Supervisor = AssociateDAO.getAssociateBean(Requested_Associate.getSupervisor_ID(),conn);
		Mail.setTo(Requested_Associate.getEmail_ID());
		String CC[] = {Supervisor.getEmail_ID()};
		Mail.setCC(CC);
		Mail.setSubject("RSA Token Request Rejected");

		String EmailMessage="<h4>Dear Associate,</h4>"+
		" 		Your RSA Token Request has been Rejected by your Manager.The details are as follows: "+				
		"<br>"+
		"<br>"+
		"<table border='1'>"+
		"  	<tr>"+
		"   	<td>Request ID</td>"+
		"		<td>"+Request.getRequest_ID()+"</td>"+
		"	</tr>"+

		"  	<tr>"+
		"   	<td>Associate Name</td>"+
		"		<td>"+Requested_Associate.getAssociate_Name()+"</td>"+
		"	</tr>"+

		"  	<tr>"+
		"   	<td>Project Name</td>"+
		"		<td>"+Requested_Associate.getUniqueProject_Name(0)+"</td>"+
		"	</tr>"+

		"  	<tr>"+
		"   	<td>Project ID</td>"+
		"		<td>"+Requested_Associate.getUniqueProject_ID(0)+"</td>"+
		"	</tr>"+

		"  	<tr>"+
		"   	<td>Reason for Request</td>"+
		"		<td>"+Request.getRequest_Reason_For_Apply()+"</td>"+
		"	</tr>"+
		"  	<tr>"+
		"   	<td>Reason for Reject</td>"+
		"		<td>"+Request.getReject_Reason()+"</td>"+
		"	</tr>"+

		"</table>"+


		"<br>"+
		"<pre>With Regards"+
		"<pre>  ESI-PMO."+
		"<hr />"+
		"<font size='2' color='red' face='Courier New'>   Note: This is a System Generated Mail. We request you not to reply to this message.</font>";

		Mail.setMessage(EmailMessage);

		Mail.sendMail();
	}	
	public static void sendMailaboutRequestRaise(RequestBean Request,Connection conn)
	{
		MailBean Mail = new MailBean();
		System.out.print("dfsd");
		AssociateBean Requested_Associate= AssociateDAO.getAssociateBean(Request.getRequest_Associate_ID(),conn);
		AssociateBean Supervisor = AssociateDAO.getAssociateBean(Requested_Associate.getSupervisor_ID(),conn);
		Mail.setTo(Supervisor.getEmail_ID());
		String CC[] = {Requested_Associate.getEmail_ID()};
		Mail.setCC(CC);
		Mail.setSubject("RSA Token Request Received");

		String EmailMessage="<h4>Dear Associate,</h4>"+
		"    This to confirm that we have received the below request "+				
		"<br>"+
		"<br>"+
		"<table border='1'>"+
		"  	<tr>"+
		"   	<td>Request ID</td>"+
		"		<td>"+Request.getRequest_ID()+"</td>"+
		"	</tr>"+
		"  	<tr>"+
		"   	<td>Associate Name</td>"+
		"		<td>"+Request.getRequest_Associate_Name()+"</td>"+
		"	</tr>"+
		"  	<tr>"+
		"   	<td>Project Name</td>"+
		"		<td>"+Request.getRequest_Project_Name()+"</td>"+
		"	</tr>"+
		"  	<tr>"+
		"   	<td>Project ID</td>"+
		"		<td>"+Request.getRequest_Project_ID()+"</td>"+
		"	</tr>"+
		"  	<tr>"+
		"   	<td>Reason for Request</td>"+
		"		<td>"+Request.getRequest_Reason_For_Apply()+"</td>"+
		"	</tr>"+
		"</table>"+
		"<br>"+
		"<pre>With Regards"+
		"<pre>  ESI-PMO."+
		"<hr />"+
		"<font size='2' color='red' face='Courier New'>   Note: This is a System Generated Mail. We request you not to reply to this message.</font>";

		Mail.setMessage(EmailMessage);

		Mail.sendMail();
	}	
	public static void sendMailaboutRequestApprove(RequestBean Request,Connection conn) throws Exception
	{
		MailBean Mail = new MailBean();
		AssociateBean Requested_Associate= AssociateDAO.getAssociateBean(Request.getRequest_Associate_ID(),conn);
		AssociateBean Admin = AssociateDAO.getAdminDetails(conn);
		Mail.setTo(Requested_Associate.getEmail_ID());
		String CC[] = {Admin.getEmail_ID()};
		Mail.setCC(CC);
		Mail.setSubject("RSA Token Request Approved");

		String EmailMessage="<h4>Dear Associate,</h4>"+
		"    Your RSA Token Request has been Approved by your Manager. You will receive your token details Shortly. "+				
		"<br>"+
		"<br>"+
		"<table border='1'>"+
		"  	<tr>"+
		"   	<td>Request ID</td>"+
		"		<td>"+Request.getRequest_ID()+"</td>"+
		"	</tr>"+

		"  	<tr>"+
		"   	<td>Associate Name</td>"+
		"		<td>"+Requested_Associate.getAssociate_Name()+"</td>"+
		"	</tr>"+

		"  	<tr>"+
		"   	<td>Project Name</td>"+
		"		<td>"+Requested_Associate.getUniqueProject_Name(0)+"</td>"+
		"	</tr>"+

		"  	<tr>"+
		"   	<td>Project ID</td>"+
		"		<td>"+Requested_Associate.getUniqueProject_ID(0)+"</td>"+
		"	</tr>"+

		"  	<tr>"+
		"   	<td>Status</td>"+
		"		<td>"+Request.getRequest_Status()+"</td>"+
		"	</tr>"+
		"</table>"+
		"<br>"+
		"<pre>With Regards"+
		"<pre>  ESI-PMO."+
		"<hr />"+
		"<font size='2' color='red' face='Courier New'>   Note: This is a System Generated Mail. We request you not to reply to this message.</font>";
		Mail.setMessage(EmailMessage);

		Mail.sendMail();
	}	


	public static void sendMailaboutSurrenderRequestApprove(RequestBean Request,Connection conn) throws Exception
	{
		MailBean Mail = new MailBean();
		AssociateBean Requested_Associate= AssociateDAO.getAssociateBean(Request.getRequest_Associate_ID(),conn);
		AssociateBean Admin = AssociateDAO.getAdminDetails(conn);
		Mail.setTo(Requested_Associate.getEmail_ID());
		String CC[] = {Admin.getEmail_ID()};
		Mail.setCC(CC);
		Mail.setSubject("RSA Token Surrender Approved");
		MasterBean Token = MasterDAO.getMasterDetails(Requested_Associate.getAssociate_ID(),conn);
		String EmailMessage="<h4>Dear Associate,</h4>"+
		"    Your Request has been Approved by your Manager.Please handover the below mentioned RSA token to the RSA coordinator.(Associate ID: "+Admin.getAssociate_ID()+ ")" +				
		"<br>"+
		"<br>"+
		"<table border='1'>"+
		"  	<tr>"+
		"   	<td>Request ID</td>"+
		"		<td>"+Request.getRequest_ID()+"</td>"+
		"	</tr>"+

		"  	<tr>"+
		"   	<td>Associate Name</td>"+
		"		<td>"+Requested_Associate.getAssociate_Name()+"</td>"+
		"	</tr>"+
		"  	<tr>"+
		"   	<td>Token ID</td>"+
		"		<td>"+Token.getToken_id()+"</td>"+
		"	</tr>"+

		"  	<tr>"+
		"   	<td>Token Expiry Date</td>"+
		"		<td>"+Token.getExpiry_date()+"</td>"+
		"	</tr>"+

		"  	<tr>"+
		"   	<td>Project Name</td>"+
		"		<td>"+Requested_Associate.getUniqueProject_Name(0)+"</td>"+
		"	</tr>"+
		"  	<tr>"+
		"   	<td>Project ID</td>"+
		"		<td>"+Requested_Associate.getUniqueProject_ID(0)+"</td>"+
		"	</tr>"+
		"  	<tr>"+
		"   	<td>Status</td>"+
		"		<td>"+Request.getRequest_Status()+"</td>"+
		"	</tr>"+
		"</table>"+
		"<br>"+
		"<pre>With Regards"+
		"<pre>  ESI-PMO."+
		"<hr />"+
		"<font size='2' color='red' face='Courier New'>   Note: This is a System Generated Mail. We request you not to reply to this message.</font>";
		Mail.setMessage(EmailMessage);

		Mail.sendMail();
	}	


	public static void sendMailToAdmin(AssociateBean Associate,RequestBean Request,Connection conn) 
	{
		MailBean Mail = new MailBean();

		Mail.setSubject("RSA Token Request Assigned");
		AssociateBean Admin = AssociateDAO.getAdminDetails(conn);
		Mail.setTo(Admin.getEmail_ID());
		String CC[] = {Associate.getEmail_ID()};
		Mail.setCC(CC);

		AssociateBean Requested_Associate= AssociateDAO.getAssociateBean(Request.getRequest_Associate_ID(),conn);

		String EmailMessage="<h4>Dear "+Admin.getAssociate_Name()+",</h4>"+
		"      RSA Token Request has been assinged to you.The details are as follows: "+				
		"<br>"+
		"<br>"+
		"<table border='1'>"+
		"  	<tr>"+
		"   	<td>Request ID</td>"+
		"		<td>"+Request.getRequest_ID()+"</td>"+
		"	</tr>"+

		"  	<tr>"+
		"   	<td>Associate Name</td>"+
		"		<td>"+Requested_Associate.getAssociate_Name()+"</td>"+
		"	</tr>"+
		"  	<tr>"+
		"   	<td>Project Name</td>"+
		"		<td>"+Requested_Associate.getUniqueProject_Name(0)+"</td>"+
		"	</tr>"+

		"  	<tr>"+
		"   	<td>Project ID</td>"+
		"		<td>"+Requested_Associate.getUniqueProject_ID(0)+"</td>"+
		"	</tr>"+
		"  	<tr>"+
		"   	<td>Reason for Request</td>"+
		"		<td>"+Request.getRequest_Reason_For_Apply()+"</td>"+
		"	</tr>"+
		"  	<tr>"+
		"   	<td>Status</td>"+
		"		<td>"+Request.getRequest_Status()+"</td>"+
		"	</tr>"+
		"</table>"+

		"<br>"+
		"<pre>With Regards"+
		"<pre>  ESI-PMO."+
		"<hr />"+
		"<font size='2' color='red' face='Courier New'>   Note: This is a System Generated Mail. We request you not to reply to this message.</font>";

		Mail.setMessage(EmailMessage);
		Mail.sendMail();
	}

	public static void sendNewUserMail(AssociateBean Associate ,Connection conn)
	{

		MailBean Mail = new MailBean();
		Mail.setTo(Associate.getEmail_ID());
		Mail.setSubject("Registeration details from RSA Token Services");

		String EmailMessage="<h4>Hi "+Associate.getAssociate_Name()+",</h4>"+
		"    Below are the details to login into RSA Token Management System, "+				
		"<br>"+
		"<br>"+
		"<table border='1'>"+
		"  	<tr>"+
		"   	<td>User Name</td>"+
		"		<td>"+Associate.getAssociate_ID()+"</td>"+
		"	</tr>"+

		"  	<tr>"+
		"   	<td>Password </td>"+
		"		<td>"+Associate.getAssociate_Password()+"</td>"+
		"	</tr>"+
		"</table>"+
		"<br>"+
		"<pre>With Regards"+
		"<pre>  ESI-PMO."+
		"<hr />"+
		"<font size='2' color='red' face='Courier New'>   Note: This is a System Generated Mail. We request you not to reply to this message.</font>";
		//Mail.setCC(null);
		Mail.setMessage(EmailMessage);
		Mail.sendMail();
	}	
	public static void sendMailaboutAssignedToken(RequestBean Request,Connection conn) throws Exception
	{
		MailBean Mail = new MailBean();
		AssociateBean Requested_Associate= AssociateDAO.getAssociateBean(Request.getRequest_Associate_ID(),conn);
		AssociateBean Supervisor = AssociateDAO.getAssociateBean(Requested_Associate.getSupervisor_ID(),conn);
		AssociateBean Admin = AssociateDAO.getAdminDetails(conn);
		Mail.setTo(Requested_Associate.getEmail_ID());
		String CC[] = {Supervisor.getEmail_ID()};
		Mail.setCC(CC);
		Mail.setSubject("RSA Token Assigned");

		TokenBean Token = TokenDAO.get_Token_Details_Before_Dispatch(Requested_Associate.getAssociate_ID(),conn);

		String EmailMessage="<h4>Hi,</h4>"+
		"    The below mentioned RSA token has been assigned to you,  please collect your token from the RSA coordinator.(Associate ID: "+Admin.getAssociate_ID()+ ")"+				
		"<br>"+
		"<br>"+
		"<table border='1'>"+
		"  	<tr>"+
		"   	<td>Token ID</td>"+
		"		<td>"+Token.getToken_ID()+"</td>"+
		"	</tr>"+

		"  	<tr>"+
		"   	<td>Token Expiry Date</td>"+
		"		<td>"+Token.getExpiry_Date()+"</td>"+
		"	</tr>"+

		"  	<tr>"+
		"   	<td>Status</td>"+
		"		<td>"+Request.getRequest_Status()+"</td>"+
		"	</tr>"+
		"</table>"+

		"<br>"+
		"<pre>With Regards"+
		"<pre>  ESI-PMO."+
		"<hr />"+
		"<font size='2' color='red' face='Courier New'>   Note: This is a System Generated Mail. We request you not to reply to this message.</font>";

		Mail.setMessage(EmailMessage);

		Mail.sendMail();
	}	


	public static void sendMailaboutAssignedTokenWithSurrenderDetails(RequestBean Request ,Connection conn) throws Exception
	{
		MailBean Mail = new MailBean();
		AssociateBean Requested_Associate= AssociateDAO.getAssociateBean(Request.getRequest_Associate_ID(),conn);
		AssociateBean Supervisor = AssociateDAO.getAssociateBean(Requested_Associate.getSupervisor_ID(),conn);
		AssociateBean Admin = AssociateDAO.getAdminDetails(conn);
		Mail.setTo(Requested_Associate.getEmail_ID());
		String CC[] = {Supervisor.getEmail_ID()};
		Mail.setCC(CC);
		Mail.setSubject("RSA Token Assigned");

		TokenBean NewToken = TokenDAO.get_Token_Details_Before_Dispatch(Requested_Associate.getAssociate_ID(),conn);

		MasterHistoryBean ExpiredTokenMaster = MasterHistoryDAO.getRecentlyExpiredTokenDetails(Request.getRequest_Associate_ID(),conn);

		String EmailMessage="<h4>Hi, " +Requested_Associate.getAssociate_Name()+"</h4>"+
		"    The below mentioned RSA token has been assigned to you,  please collect your token from the RSA coordinator.(Associate ID: "+Admin.getAssociate_ID()+ ")"+
		"    and surrender the Expired RSA token to RSA coordinator."+			
		"<br>"+
		"<br>"+

		"<table border='1'>"+
		"	<tr> "+
		"		<th> Assigned Token Details </th>"+
		"   </tr> "+
		"	<tr> "+
		"		<td> "+
		"			<table  border='1'>"+
		"  				<tr>"+
		"   				<td>Token ID</td>"+
		"					<td>"+NewToken.getToken_ID()+"</td>"+
		"				</tr>"+
		"  				<tr>"+
		"  					<td>Token Expiry Date</td>"+
		"					<td>"+NewToken.getExpiry_Date()+"</td>"+
		"				</tr>"+
		"  				<tr>"+
		"  					<td>Status</td>"+
		"					<td>"+Request.getRequest_Status()+"</td>"+
		"				</tr>"+
		"			</table>"+
		"		</td>"+
		"	</tr>"+
		"</table>"+

		"<br>"+
		"<br>"+			
		"<br>"+		

		"<table border='1'>"+
		"	<tr> "+
		"		<th> Expired Token Details </th>"+
		"   </tr> "+
		"	<tr> "+
		"		<td> "+
		"			<table  border='1'>"+
		"  				<tr>"+
		"   				<td>Token ID</td>"+
		"					<td>"+ExpiredTokenMaster.getToken_id()+"</td>"+
		"				</tr>"+
		"  				<tr>"+
		"  					<td>Token Expiry Date</td>"+
		"					<td>"+ExpiredTokenMaster.getExpiry_date()+"</td>"+
		"				</tr>"+
		"			</table>"+
		"		</td>"+
		"	</tr>"+
		"</table>"+

		"<pre>With Regards"+
		"<pre>  ESI-PMO."+
		"<hr />"+
		"<font size='2' color='red' face='Courier New'>   Note: This is a System Generated Mail. We request you not to reply to this message.</font>";

		Mail.setMessage(EmailMessage);

		Mail.sendMail();
	}	

	public static void sendMailaboutDispatchToken(RequestBean Request ,Connection conn) throws Exception
	{
		MailBean Mail = new MailBean();
		AssociateBean Requested_Associate= AssociateDAO.getAssociateBean(Request.getRequest_Associate_ID(),conn);
		AssociateBean Admin = AssociateDAO.getAdminDetails(conn);
		AssociateBean Supervisor = AssociateDAO.getAssociateBean(Requested_Associate.getSupervisor_ID(),conn);
		Mail.setTo(Requested_Associate.getEmail_ID());
		String CC[] = {Admin.getEmail_ID(),Supervisor.getEmail_ID()};
		Mail.setCC(CC);
		Mail.setSubject("RSA Token Dispatched");

		TokenBean Token = TokenDAO.get_Token_Details(Requested_Associate.getAssociate_ID(),conn);

		String EmailMessage="<h4>Dear Associate,</h4>"+
		"    The below mentioned RSA token has been collected by you. "+				
		"<br>"+
		"<br>"+
		"<table border='1'>"+
		"  	<tr>"+
		"   	<td>Token ID</td>"+
		"		<td>"+Token.getToken_ID()+"</td>"+
		"	</tr>"+

		"  	<tr>"+
		"   	<td>Token Expiry Date</td>"+
		"		<td>"+Token.getExpiry_Date()+"</td>"+
		"	</tr>"+

		"  	<tr>"+
		"   	<td>Status</td>"+
		"		<td>Dispatched</td>"+
		"	</tr>"+
		"</table>"+
		"<br>"+
		"<pre>With Regards"+
		"<pre>  ESI-PMO."+
		"<hr />"+
		"<font size='2' color='red' face='Courier New'>   Note: This is a System Generated Mail. We request you not to reply to this message.</font>";
		Mail.setMessage(EmailMessage);

		Mail.sendMail();
	}	

	public static void sendMailaboutSurrenderToken(RequestBean Request ,Connection conn) throws Exception
	{
		MailBean Mail = new MailBean();
		AssociateBean Requested_Associate= AssociateDAO.getAssociateBean(Request.getRequest_Associate_ID(),conn);
		AssociateBean Admin = AssociateDAO.getAdminDetails(conn);
		AssociateBean Supervisor = AssociateDAO.getAssociateBean(Requested_Associate.getSupervisor_ID(),conn);

		Mail.setTo(Requested_Associate.getEmail_ID());
		String CC[] = {Admin.getEmail_ID(),Supervisor.getEmail_ID()};
		Mail.setCC(CC);
		Mail.setSubject("RSA Token Received");

		MasterBean Token = MasterDAO.getMasterDetails(Requested_Associate.getAssociate_ID(),conn);

		String EmailMessage="<h4>Dear Associate,</h4>"+
		"   The below mentioned RSA Token has been received from You."+				
		"<br>"+
		"<br>"+
		"<table border='1'>"+
		"  	<tr>"+
		"   	<td>Token ID</td>"+
		"		<td>"+Token.getToken_id()+"</td>"+
		"	</tr>"+

		"  	<tr>"+
		"   	<td>Token Expiry Date</td>"+
		"		<td>"+Token.getExpiry_date()+"</td>"+
		"	</tr>"+
		"</table>"+
		"<br>"+
		"<pre>With Regards"+
		"<pre>  ESI-PMO."+
		"<hr />"+
		"<font size='2' color='red' face='Courier New'>   Note: This is a System Generated Mail. We request you not to reply to this message.</font>";
		Mail.setMessage(EmailMessage);

		Mail.sendMail();
	}


	public static void sendMailaboutSurrenderOfExpiredToken(MasterHistoryBean Master ,Connection conn) throws Exception
	{
		MailBean Mail = new MailBean();
		AssociateBean Requested_Associate= AssociateDAO.getAssociateBean(Master.getAssociate_id(),conn);
		AssociateBean Admin = AssociateDAO.getAdminDetails(conn);
		AssociateBean Supervisor = AssociateDAO.getAssociateBean(Requested_Associate.getSupervisor_ID(),conn);

		Mail.setTo(Requested_Associate.getEmail_ID());
		String CC[] = {Admin.getEmail_ID(),Supervisor.getEmail_ID()};
		Mail.setCC(CC);
		Mail.setSubject("RSA Token Received");



		String EmailMessage="<h4>Dear Associate,</h4>"+
		"   The below mentioned RSA Token has been received from You."+				
		"<br>"+
		"<br>"+
		"<table border='1'>"+
		"  	<tr>"+
		"   	<td>Token ID</td>"+
		"		<td>"+Master.getToken_id()+"</td>"+
		"	</tr>"+

		"  	<tr>"+
		"   	<td>Token Expiry Date</td>"+
		"		<td>"+Master.getExpiry_date()+"</td>"+
		"	</tr>"+
		"</table>"+
		"<br>"+
		"<pre>With Regards"+
		"<pre>  ESI-PMO."+
		"<hr />"+
		"<font size='2' color='red' face='Courier New'>   Note: This is a System Generated Mail. We request you not to reply to this message.</font>";
		Mail.setMessage(EmailMessage);

		Mail.sendMail();

	}	
	public static int sendMailToRequestorAboutAssinedToken(AssociateBean Associate,TokenBean Token ,Connection conn)
	{
		try
		{
			MailBean Mail = new MailBean();
			Mail.setTo(Associate.getEmail_ID());
			Mail.setSubject("Assinged RSA Token Details");

			//AssociateBean Requested_Associate= AssociateDAO.getAssociateBean(Request.getRequest_Associate_ID());

			String EmailMessage="<h4>Dear "+Associate.getAssociate_Name()+",</h4>"+
			"    RSA Token has been Assigned for You, Please collect it from RSA Admin, The Token details are as follows: "+				
			"<br>"+
			"<br>"+
			"<table border='1'>"+
			"  	<tr>"+
			"   	<td>Token ID</td>"+
			"		<td>"+Token.getToken_ID()+"</td>"+
			"	</tr>"+

			"  	<tr>"+
			"   	<td>Token Expiry Date</td>"+
			"		<td>"+Token.getExpiry_Date()+"</td>"+
			"	</tr>"+

			"  	<tr>"+
			"   	<td>Dispatch Status</td>"+
			"		<td>"+Token.getToken_Dispatch_Status()+"</td>"+
			"	</tr>"+
			"</table>"+
			"<br>"+
			"<pre>With Regards"+
			"<pre>  ESI-PMO."+
			"<hr />"+
			"<font size='2' color='red' face='Courier New'>   Note: This is a System Generated Mail. We request you not to reply to this message.</font>";

			Mail.setMessage(EmailMessage);
			Mail.sendMail();
			return 1;
		}
		catch (Exception e) {
			// TODO: handle exception
			return 0;
		}
	}

	public static int sendMailToAdminAboutAssinedToken(AssociateBean Associate,TokenBean Token,AssociateBean Admin ,Connection conn)
	{
		try
		{
			MailBean Mail = new MailBean();
			Mail.setTo(Admin.getEmail_ID());
			Mail.setSubject("Assinged RSA Token Details");

			//AssociateBean Requested_Associate= AssociateDAO.getAssociateBean(Request.getRequest_Associate_ID());

			String EmailMessage="<h4>Dear "+Admin.getAssociate_Name()+",</h4>"+
			"    RSA Token has been Assigned for the folowing Associate, The details are as follows: "+				
			"<br>"+
			"<br>"+
			"<table border='1'>"+
			"  	<tr>"+
			"   	<td>Associate ID</td>"+
			"		<td>"+Associate.getAssociate_ID()+"</td>"+
			"	</tr>"+

			"  	<tr>"+
			"   	<td>Associate Name</td>"+
			"		<td>"+Associate.getAssociate_Name()+"</td>"+
			"	</tr>"+

			"  	<tr>"+
			"   	<td>Project Name</td>"+
			"		<td>"+Associate.getUniqueProject_Name(0)+"</td>"+
			"	</tr>"+

			"  	<tr>"+
			"   	<td>Project ID</td>"+
			"		<td>"+Associate.getUniqueProject_ID(0)+"</td>"+
			"	</tr>"+

			"  	<tr>"+
			"   	<td>Token ID</td>"+
			"		<td>"+Token.getToken_ID()+"</td>"+
			"	</tr>"+

			"  	<tr>"+
			"   	<td>Token Expiry Date</td>"+
			"		<td>"+Token.getExpiry_Date()+"</td>"+
			"	</tr>"+

			"  	<tr>"+
			"   	<td>Dispatch Status</td>"+
			"		<td>"+Token.getToken_Dispatch_Status()+"</td>"+
			"	</tr>"+
			"</table>"+
			"<br>"+
			"<pre>With Regards"+
			"<pre>  ESI-PMO."+
			"<hr />"+
			"<font size='2' color='red' face='Courier New'>   Note: This is a System Generated Mail. We request you not to reply to this message.</font>";

			Mail.setMessage(EmailMessage);
			Mail.sendMail();
			return 1;
		}
		catch (Exception e) {
			// TODO: handle exception
			return 0;
		}
	}
	public static int sendSurrenderRequestMailFromAssociate(AssociateBean Associate, TokenBean Token ,Connection conn)
	{
		try
		{
			MailBean Mail = new MailBean();
			Mail.setTo(Associate.getEmail_ID());
			Mail.setSubject("RSA Token Details");

			//AssociateBean Requested_Associate= AssociateDAO.getAssociateBean(Request.getRequest_Associate_ID());

			String EmailMessage="<h4>Dear "+Associate.getAssociate_Name()+",</h4>"+
			"    RSA Token has been Assigned for You, Please collect it from RSA Admin, The Token details are as follows: "+				
			"<br>"+
			"<br>"+
			"<table border='1'>"+
			"  	<tr>"+
			"   	<td>Token ID</td>"+
			"		<td>"+Token.getToken_ID()+"</td>"+
			"	</tr>"+

			"  	<tr>"+
			"   	<td>Token Expiry Date</td>"+
			"		<td>"+Token.getExpiry_Date()+"</td>"+
			"	</tr>"+

			"  	<tr>"+
			"   	<td>Dispatch Status</td>"+
			"		<td>"+Token.getToken_Dispatch_Status()+"</td>"+
			"	</tr>"+
			"</table>"+
			"<br>"+
			"<pre>With Regards"+
			"<pre>  ESI-PMO."+
			"<hr />"+
			"<font size='2' color='red' face='Courier New'>   Note: This is a System Generated Mail. We request you not to reply to this message.</font>";

			Mail.setMessage(EmailMessage);
			Mail.sendMail();
			return 1;
		}
		catch (Exception e) {
			// TODO: handle exception
			return 0;
		}
	}


}
