package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import bean.AssociateBean;
import bean.MasterBean;
import bean.RequestBean;

public class MasterDAO  
{
	
	
	public static List<MasterBean> getTokenDetailsBySUpervisorName(final int SupervisorID,final Connection conn)
	{
		List<MasterBean> TokenDetails = new ArrayList<MasterBean>();
		PreparedStatement stmt = null;
		ResultSet rs = null;		
		try {
			stmt = conn.prepareStatement(MasterQueries.GET_TOKEN_DETAILS_BY_SUPERVISOR_ID);
			stmt.setInt(1,SupervisorID);
			rs=stmt.executeQuery();
			while( rs.next())
				TokenDetails.add(getMasterDetails(rs.getInt(1),conn ) );
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return TokenDetails;
	}

	
	public static List<MasterBean> getProjectNames(final Connection conn)
	{
		List<MasterBean> TokenDetails = new ArrayList<MasterBean>();
		PreparedStatement stmt = null;
		ResultSet rs = null;		
		MasterBean Master = null;
		try {
			stmt =  conn.prepareStatement(MasterQueries.GET_ASSIGNED_PROJECT_NAME);
			rs=stmt.executeQuery();
			if(rs.next())
			{
				while( rs.next())
				{
					Master = new MasterBean();
					Master.setProject_name(rs.getString(1));
					Master.setProject_id(rs.getInt(2));
					TokenDetails.add(Master);
				}
			}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return TokenDetails;

	}


	public static List<MasterBean> getTokenDetailsByProjectToAdmin(final int ProjectID,final Connection conn)
	{
		List<MasterBean> TokenDetails = new ArrayList<MasterBean>();
		PreparedStatement stmt = null;
		ResultSet rs = null;		
		try {
			stmt = conn.prepareStatement(MasterQueries.GET_TOKEN_DETAILS_BY_PROJECT_NAME_TO_ADMIN);
			stmt.setInt(1,ProjectID);
			rs=stmt.executeQuery();
			while( rs.next())
				TokenDetails.add(getMasterDetails(rs.getInt(1),conn ) );
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return TokenDetails;
	}


	public static List<MasterBean> getTokenDetailsByProject(final int Supervisor_ID,final int ProjectID,final Connection conn)
	{
		List<MasterBean> TokenDetails = new ArrayList<MasterBean>();
		PreparedStatement stmt = null;
		ResultSet rs = null;		
		try {
			stmt = conn.prepareStatement(MasterQueries.GET_TOKEN_DETAILS_BY_PROJECT_NAME);
			stmt.setInt(1,Supervisor_ID);
			stmt.setInt(2,ProjectID);

			rs=stmt.executeQuery();
			while( rs.next())
				TokenDetails.add(getMasterDetails(rs.getInt(1),conn ) );
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return TokenDetails;
	}
	public static List<MasterBean> getAssigned_Associate(final int Supervisor_ID,final Connection conn)
	{
		final List<MasterBean> AssociateDetails = new ArrayList<MasterBean>();
		ResultSet rs = null;
		PreparedStatement stmt = null;

		try {
			stmt = conn.prepareStatement(AssociateQueries.GET_ASSIGNED_ASSOCIATE);
			stmt.setInt(1,Supervisor_ID);
			rs=stmt.executeQuery();
			while( rs.next())
				AssociateDetails.add(getMasterDetails(rs.getInt(1),conn));

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return AssociateDetails;
	}
	public static MasterBean getMasterDetails(final int Associate_ID,final Connection conn)
	{
		MasterBean Master = null;
		PreparedStatement stmt  = null;
		ResultSet  rs = null; 
		try {
			stmt  = conn.prepareStatement(MasterQueries.GET_MASTER_RECORD);
			stmt.setInt(1,Associate_ID);
			rs = stmt.executeQuery();
			if(rs.next())
			{
				Master = new MasterBean();
				Master.setProject_id(rs.getInt(2));
				Master.setProject_name(rs.getString(3));
				Master.setAssociate_id(rs.getInt(4));
				Master.setAassociate_name(rs.getString(5));
				Master.setToken_id(rs.getInt(6));
				Master.setAssigned_date(rs.getTimestamp(7));
				Master.setExpiry_date(rs.getDate(8));
				Master.setStatus(rs.getString(9));
				Master.setReason_For_Apply(rs.getString(10));
				Master.setDispatch_status(rs.getString(11));
				Master.setSupervisor_ID(rs.getInt(12));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return Master;

	}
	public static List<MasterBean> getToken_Details_By_ID(final int Token_ID,final Connection conn)
	{
		List<MasterBean> AssociateDetails = null;
		AssociateDetails = null;
		ResultSet rs = null;
		PreparedStatement stmt = null;
		try {
			stmt = conn.prepareStatement(MasterQueries.GET_TOKEN_BY_ID);
			stmt.setInt(1,Token_ID);
			rs=stmt.executeQuery();
			if( rs.next())
			{
				AssociateDetails = new ArrayList<MasterBean>();
				AssociateDetails.add( getMasterBean( rs.getInt(6),conn ) );
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return AssociateDetails;
	}
	public static int Assign_token(final int token_id,final AssociateBean Associate,final RequestBean Request,final String Status,final Connection conn)
	{

		PreparedStatement stmt = null;
		int a = 0;

		try {
			stmt = conn.prepareStatement(MasterQueries.UPDATE_MASTER);
			stmt.setInt(1,Request.getRequest_Project_ID());
			stmt.setString(2,Request.getRequest_Project_Name());
			stmt.setInt(3,Request.getRequest_Associate_ID());
			stmt.setString(4,Request.getRequest_Associate_Name());
			stmt.setTimestamp(5, getCurrentTimeStamp());
			stmt.setString(6,Status);
			stmt.setString(7,Request.getRequest_Reason_For_Apply());
			stmt.setString(8,"NO");
			stmt.setInt(9,Request.getSupervisor_ID());
			stmt.setInt(10,token_id);
			a= stmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return a;
	}
	public static int Set_Token_Status(final int AssociateID,final String Status,final Connection conn)
	{
		PreparedStatement stmt = null;
		int updated = 0;
		try {
			stmt = conn.prepareStatement(MasterQueries.SET_TOKEN_STATUS);
			stmt.setString(1,Status);
			stmt.setInt(2,AssociateID);
			updated = stmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return updated;
	}
	public static List<MasterBean>  getUnAssignedToken(final Connection conn)
	{
		List<MasterBean> TokenDetails = null;
		MasterBean Token = null;
		ResultSet rs = null;
		PreparedStatement stmt =null;
		try {
			stmt = conn.prepareStatement(MasterQueries.GET_UNASSIGNED_TOKEN);
			rs = stmt.executeQuery();
			if(rs != null)
			{
				TokenDetails = new ArrayList<MasterBean>();
				while( rs.next())
				{
					Token = new MasterBean();
					Token.setToken_id(rs.getInt(6));
					Token.setExpiry_date(rs.getDate(8));
					Token.setStatus(rs.getString(9));
					TokenDetails.add(Token);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return TokenDetails;
	}
	public static List<MasterBean>  getAssignedTokens(final Connection conn)
	{
		List<MasterBean> TokenDetails = null;
		MasterBean Token = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.prepareStatement(MasterQueries.GET_ASSIGNED_TOKEN);
			rs=stmt.executeQuery();
			if(rs != null)
			{
				TokenDetails = new ArrayList<MasterBean>();
				while( rs.next())
				{
					Token = getMasterBean(rs.getInt(1), conn);
					TokenDetails.add(Token);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return TokenDetails;
	}
	public List<MasterBean> getToken_Details_By_Status(final String Token_Status,final Connection conn)
	{
		List<MasterBean> TokenDetails = null;
		MasterBean Token = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			stmt = conn.prepareStatement(MasterQueries.GET_TOKEN_BY_STATUS);
			stmt.setString(1,Token_Status);
			rs=stmt.executeQuery();
			if(rs != null)
			{
				TokenDetails = new ArrayList<MasterBean>();
				while( rs.next())
				{
					Token = new MasterBean();

					Token.setProject_id(rs.getInt(2));
					Token.setProject_name(rs.getString(3));
					Token.setAssociate_id(rs.getInt(4));
					Token.setAassociate_name(rs.getString(5));
					Token.setToken_id(rs.getInt(6));
					Token.setAssigned_date(rs.getTimestamp(7));
					Token.setExpiry_date(rs.getDate(8));
					Token.setStatus(rs.getString(9));
					Token.setReason_For_Apply(rs.getString(10));
					Token.setDispatch_status(rs.getString(11));
					Token.setSupervisor_ID(rs.getInt(12));
					TokenDetails.add(Token);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return TokenDetails;
	}
	public static int getTokenID(final int Associate_ID,final Connection conn)
	{
		PreparedStatement stmt =  null;
		ResultSet rs = null;
		int Token_ID = 0;

		try {
			stmt =  conn.prepareStatement(MasterQueries.GET_TOKEN_ID);
			stmt.setInt(1,Associate_ID);
			stmt.setString(2,"Assigned");
			stmt.setString(3,"NO");
			rs=stmt.executeQuery();
			if( rs.next())
				Token_ID = rs.getInt(1);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return Token_ID; 
	}
	public static int deleteMaster(final int Token_ID,final Connection conn)
	{
		PreparedStatement stmt = null;
		int deleted = 0 ;

		try {
			stmt = conn.prepareStatement(MasterQueries.DELETE_MASTER);
			stmt.setInt(1,Token_ID);
			deleted = stmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return deleted; 
	}
	public static MasterBean getMasterBean(final int Token_ID, final Connection conn) 
	{

		MasterBean Token = null; 
		PreparedStatement stmt = null; 
		ResultSet rs = null;

		try 
		{
			stmt = conn.prepareStatement(MasterQueries.GET_TOKEN_BY_ID);
			stmt.setInt(1,Token_ID);
			rs=stmt.executeQuery();
			if (rs.next())
			{
				Token = new MasterBean();
				Token.setProject_id(rs.getInt(2));
				Token.setProject_name(rs.getString(3));
				Token.setAssociate_id(rs.getInt(4));
				Token.setAassociate_name(rs.getString(5));
				Token.setToken_id(rs.getInt(6));
				Token.setAssigned_date(rs.getTimestamp(7));
				Token.setExpiry_date(rs.getDate(8));
				Token.setStatus(rs.getString(9));
				Token.setReason_For_Apply(rs.getString(10));
				Token.setDispatch_status(rs.getString(11));
				Token.setSupervisor_ID(rs.getInt(12));
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return Token;
	}
	public static int deleteMasterDetails(final int Token_ID, final Connection conn)
	{
		PreparedStatement stmt = null;
		int deleted = 0 ;
		try {
			stmt = conn.prepareStatement(MasterQueries.DELETE_MASTER_RECORD_DETAILS);
			stmt.setInt(1, Token_ID);
			deleted = stmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return deleted; 
	}
	public static String dateToString()
	{
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		final Date date = new Date();
		return ( (String)dateFormat.format(date) );
	}   
	public static Timestamp getCurrentTimeStamp()
	{
		final java.sql.Timestamp  sqlDate = new java.sql.Timestamp(new java.util.Date().getTime());
		return sqlDate;

	}   

}