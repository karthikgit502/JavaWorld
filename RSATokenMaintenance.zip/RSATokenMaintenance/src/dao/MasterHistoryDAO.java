package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


import bean.MasterBean;
import bean.MasterHistoryBean;

public class MasterHistoryDAO 
{
	public static List<MasterHistoryBean> getToken_Details_By_ID(int Token_ID,Connection conn) 
	{

		List<MasterHistoryBean> TokenDetails = null;
		TokenDetails = null;
		MasterHistoryBean Token = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.prepareStatement(MasterHistoryQueries.GET_TOKEN_BY_ID);
			stmt.setInt(1,Token_ID);
			rs=stmt.executeQuery();
			if(rs != null)
			{
				TokenDetails = new ArrayList<MasterHistoryBean>();
				while( rs.next())
				{
					Token = new MasterHistoryBean();

					Token.setProject_id(rs.getInt(2));
					Token.setProject_name(rs.getString(3));
					Token.setAssociate_id(rs.getInt(4));
					Token.setAassociate_name(rs.getString(5));
					Token.setToken_id(rs.getInt(6));
					Token.setAssigned_date(rs.getTimestamp(7));
					Token.setExpiry_date(rs.getDate(8));
					Token.setProcessed_date(rs.getTimestamp(9));
					Token.setStatus(rs.getString(10));
					Token.setReason_For_Apply(rs.getString(11));
					Token.setSupervisor_ID(rs.getInt(12));
					TokenDetails.add(Token);
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return TokenDetails;
	}
	public static MasterHistoryBean getRecentlyExpiredTokenDetails(int AssociateID,Connection conn)
	{

		MasterHistoryBean Token = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			stmt = conn.prepareStatement(MasterHistoryQueries.GET_RECENTLY_EXPIRED_TOKEN);
			stmt.setInt(1,AssociateID);
			rs=stmt.executeQuery();

			if( rs.next() )
			{
				Token = new MasterHistoryBean();

				Token.setProject_id(rs.getInt(2));
				Token.setProject_name(rs.getString(3));
				Token.setAssociate_id(rs.getInt(4));
				Token.setAassociate_name(rs.getString(5));
				Token.setToken_id(rs.getInt(6));
				Token.setAssigned_date(rs.getTimestamp(7));
				Token.setExpiry_date(rs.getDate(8));
				Token.setProcessed_date(rs.getTimestamp(9));
				Token.setStatus(rs.getString(10));
				Token.setReason_For_Apply(rs.getString(11));
				Token.setSupervisor_ID(rs.getInt(12));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Token;

	}
	public static int insertRequest(MasterBean Master,Connection conn)
	{

		PreparedStatement stmt = null;
		int inserted = 0;

		try {
			stmt = conn.prepareStatement(MasterHistoryQueries.INSERT_MASTER_RECORD);
			stmt.setInt(1,Master.getProject_id());
			stmt.setString(2,Master.getProject_name());
			stmt.setInt(3,Master.getAssociate_id());
			stmt.setString(4,Master.getAassociate_name());
			stmt.setInt(5,Master.getToken_id());
			stmt.setTimestamp(6,Master.getAssigned_date());
			stmt.setDate(7,Master.getExpiry_date());
			stmt.setTimestamp(8,getCurrentTimeStamp());
			stmt.setString(9,Master.getStatus());
			stmt.setString(10,Master.getReason_For_Apply());
			stmt.setInt(11,Master.getSupervisor_ID());
			inserted = stmt.executeUpdate();

		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try {
				stmt.close();
			} catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
		return inserted;

	}
	public static List<MasterHistoryBean>  getTokenDetailsByStatus(String Token_Status,Connection conn)
	{
		List<MasterHistoryBean> TokenDetails = null;
		MasterHistoryBean Token;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.prepareStatement(MasterHistoryQueries.GET_MASTER_RECORD_BY_STATUS);
			stmt.setString(1,Token_Status);
			rs=stmt.executeQuery();
			if(rs != null)
			{
				TokenDetails = new ArrayList<MasterHistoryBean>();
				while( rs.next())
				{
					Token = new MasterHistoryBean();

					Token.setProject_id(rs.getInt(2));
					Token.setProject_name(rs.getString(3));
					Token.setAssociate_id(rs.getInt(4));
					Token.setAassociate_name(rs.getString(5));
					Token.setToken_id(rs.getInt(6));
					Token.setAssigned_date(rs.getTimestamp(7));
					Token.setExpiry_date(rs.getDate(8));
					Token.setProcessed_date(rs.getTimestamp(9));
					Token.setStatus(rs.getString(10));
					Token.setReason_For_Apply(rs.getString(11));
					Token.setSupervisor_ID(rs.getInt(12));
					TokenDetails.add(Token);
				}
			}
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try {
				rs.close();
				stmt.close();
			}
			catch (SQLException e)
			{

				e.printStackTrace();
			}
		}
		return TokenDetails;
	}
	public static String DateToString()
	{
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		Date date = new Date();
		return ( (String)dateFormat.format(date) );
	}
	public static Timestamp getCurrentTimeStamp()
	{
		java.sql.Timestamp  sqlDate = new java.sql.Timestamp(new java.util.Date().getTime());
		return sqlDate;

	}   
}
