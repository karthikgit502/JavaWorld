package dao;

public class MasterHistoryQueries 
{
	public static final String INSERT_MASTER_RECORD =
		"insert into RSA_MASTER_HISTORY (" +
		"PROJECT_ID," +
		"PROJECT_NAME," +
		"ASSOCIATE_ID," +
		"ASSOCIATE_NAME," +
		"TOKEN_ID," +
		"ASSIGNED_DATE," +
		"EXPIRY_DATE," +
		"RETURNED_DATE," +
		"STATUS," +
		"REASON_FOR_APPLY," +
		"HCM_SUPERVISOR_ID )" +
		" values (?,?,?,?,?,?,?,?,?,?,?)";	
	
	public static final String GET_MASTER_RECORD_BY_STATUS =
	    "select * from RSA_MASTER_HISTORY " +
	    " where STATUS = ? order by S_NO ASC"; 

	public static final String GET_TOKEN_BY_ID =
	    "select * from RSA_MASTER_HISTORY " +
		" where TOKEN_ID = ? order by S_NO ASC";
		
	public static final String GET_RECENTLY_EXPIRED_TOKEN =
		"select * from RSA_MASTER_HISTORY where ASSOCIATE_ID = ? and STATUS='Expired'"+
		" order by S_NO desc";
}
