package dao;

public class MasterQueries
{
	

	public static final String GET_ASSIGNED_PROJECT_NAME =
	    "select distinct(PROJECT_NAME),PROJECT_ID from RSA_TOKEN_MASTER";
	
	public static final String GET_TOKEN_BY_STATUS =
		    "select * from RSA_TOKEN_MASTER " +
		    " where STATUS = ? "; 
		
	public static final String GET_TOKEN_DETAILS_BY_PROJECT_NAME =
	    "select ASSOCIATE_ID from RSA_TOKEN_MASTER where HCM_SUPERVISOR_ID = ? and PROJECT_ID = ?";
	
	public static final String GET_TOKEN_DETAILS_BY_SUPERVISOR_ID =
	    "select ASSOCIATE_ID from RSA_TOKEN_MASTER where HCM_SUPERVISOR_ID = ? ";

	public static final String GET_TOKEN_DETAILS_BY_PROJECT_NAME_TO_ADMIN =
	    "select ASSOCIATE_ID from RSA_TOKEN_MASTER where PROJECT_ID = ?";

	public static final String GET_MASTER_RECORD=
		"select * from RSA_TOKEN_MASTER where ASSOCIATE_ID = ? ";		
		
	public static final String GET_TOKEN_BY_ID =
		    "select * from RSA_TOKEN_MASTER " +
			"where TOKEN_ID = ?";
	
	public static final String DELETE_MASTER =
	    "delete from RSA_TOKEN_MASTER " +
		"where TOKEN_ID = ?";
	
	public static final String UPDATE_MASTER =
		 "update RSA_TOKEN_MASTER set " +
		 " PROJECT_ID = ?,     " +
		 " PROJECT_NAME = ?,   "+
		 " ASSOCIATE_ID = ?,   "+
		 " ASSOCIATE_NAME = ?, "+
		 " ASSIGNED_DATE = ?,  "+
		 " STATUS = ?,         "+
		 " REASON_FOR_APPLY = ?,"+
		 " DISPATCH_STATUS = ?,"+
		 " HCM_SUPERVISOR_ID = ?"+
		 " where TOKEN_ID = ?  ";
	
	
	
	public static final String REQUEST_INSERT =
		"insert into RSA_TOKEN_MASTER (" +
		"PROJECT_NAME," +
		"ASSOCIATE_ID," +
		"ASSOCIATE_NAME,TOKEN_ID,ASSIGNED_DATE,EXPIRY_DATE,STATUS,REASON_FOR_APPLY,DISPATCH_STATUS,PROJECT_ID) values (?,?,?,?,?,?,?,?,?,?)";
	
	public static final String GET_TOKEN_ID =
	    "select TOKEN_ID from RSA_TOKEN_MASTER " +
		"where ASSOCIATE_ID = ? "+ 
		" and STATUS = ? "+
		" and DISPATCH_STATUS = ? ";
	
	public static final String GET_NOT_DISPATCHED_TOKEN_DETAILS =
	    "select PROJECT_ID,PROJECT_NAME,ASSOCIATE_ID,ASSOCIATE_NAME,TOKEN_ID,ASSIGNED_DATE,REASON_FOR_APPLY from RSA_TOKEN_MASTER " +
		"where DISPATCH_STATUS ='NO' order by ASSOCIATE_ID ASC  ";
	
	public static final String SET_TOKEN_STATUS =
		"update RSA_TOKEN_MASTER set " +
		 " STATUS = ?         "+
		  "where ASSOCIATE_ID = ?  ";
	
	public static final String GET_UNASSIGNED_TOKEN =
	    "select * from RSA_TOKEN_MASTER " +
		"where STATUS = 'Surrendered'" +
		" or STATUS = 'New Token' order by EXPIRY_DATE,TOKEN_ID ASC";
	
	public static final String GET_ASSIGNED_TOKEN =
	    "select TOKEN_ID from RSA_TOKEN_MASTER " +
		"where STATUS = 'Assigned'" +
		" or STATUS = 'Re-Assigned' order by EXPIRY_DATE,TOKEN_ID ASC";
	
	
	public static final String DELETE_MASTER_RECORD_DETAILS =
		"update RSA_TOKEN_MASTER set PROJECT_ID = null,PROJECT_NAME = null,ASSOCIATE_ID = null,ASSOCIATE_NAME = null,ASSIGNED_DATE = null,REASON_FOR_APPLY = null,DISPATCH_STATUS = null, " +
		" HCM_SUPERVISOR_ID = null where TOKEN_ID = ? ";

	public static final String GET_EXPIRED_TOKENS =
		"select TOKEN_ID,EXPIRY_DATE,STATUS from RSA_TOKEN_MASTER where ASSOCIATE_ID = null "+
		" and ( EXPIRY_DATE < ? and EXPIRY_DATE > ? ) order by RETURNED_DATE,S_NO ASC";
	
	
}


