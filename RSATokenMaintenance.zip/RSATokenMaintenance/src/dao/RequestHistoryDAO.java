package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import bean.RequestBean;
import bean.RequestHistoryBean;
public class RequestHistoryDAO 
{

	public static int insertApprovedRequest(int Request_ID,Connection conn)
	{

		int result=0;	
		PreparedStatement stmt = null;
		try {
			stmt = conn.prepareStatement(RequestHistoryQueries.INSERT_REQUEST);
			RequestBean Request = RequestDAO.getRequestBean(Request_ID,conn);
			stmt.setInt(1,Request.getRequest_ID());
			stmt.setInt(2,Request.getRequest_Associate_ID() );
			stmt.setString(3,Request.getRequest_Associate_Name());
			stmt.setInt(4,Request.getRequest_Project_ID());
			stmt.setString(5,Request.getRequest_Project_Name());
			stmt.setTimestamp(6,getCurrentTimeStamp());
			stmt.setString(7,Request.getRequest_Reason_For_Apply());
			stmt.setString(8,Request.getRequest_Status());
			stmt.setInt(9,Request.getSupervisor_ID());
			stmt.setString(10,"Request Approved");
			result = stmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}


		return result;
	}
	public static int insertNewRequestUsingID(int Request_ID,Connection conn)
	{
		int result=0;	
		PreparedStatement stmt = null;
		try {
			stmt = conn.prepareStatement(RequestHistoryQueries.INSERT_REQUEST);
			RequestBean Request = RequestDAO.getRequestBean(Request_ID,conn);
			stmt.setInt(1,Request.getRequest_ID());
			stmt.setInt(2,Request.getRequest_Associate_ID() );
			stmt.setString(3,Request.getRequest_Associate_Name());
			stmt.setInt(4,Request.getRequest_Project_ID());
			stmt.setString(5,Request.getRequest_Project_Name());
			stmt.setTimestamp(6,Request.getRequest_Date());
			stmt.setString(7,Request.getRequest_Reason_For_Apply());
			stmt.setString(8,"Request Raised");
			stmt.setInt(9,Request.getSupervisor_ID());
			stmt.setString(10,null);
			result = stmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}


		return result;
	}


	public static int insertRequest(RequestHistoryBean Request,Connection conn)
	{
		PreparedStatement stmt = null;
		int inserted = 0 ; 
		try {
			stmt = conn.prepareStatement(RequestHistoryQueries.INSERT_REQUEST);
			stmt.setInt(1,Request.getRequest_ID());
			stmt.setInt(2,Request.getRequest_Associate_ID());
			stmt.setString(3,Request.getRequest_Associate_Name());
			stmt.setInt(4,Request.getRequest_Project_ID());
			stmt.setString(5,Request.getRequest_Project_Name());
			stmt.setTimestamp(6,Request.getRequest_Date());
			stmt.setString(7,Request.getRequest_Reason_For_Apply());
			stmt.setString(8,Request.getRequest_Status());
			stmt.setInt(9,Request.getSupervisor_ID());
			stmt.setString(10,Request.getReject_Reason());
			inserted = stmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}


		return inserted;
	}

	public static Timestamp getCurrentTimeStamp()
	{
		java.sql.Timestamp  sqlDate = new java.sql.Timestamp(new java.util.Date().getTime());
		return sqlDate;

	}   


	public static List<RequestHistoryBean> getClosedRequestDetails( int RequestID,Connection conn )
	{
		List<RequestHistoryBean> RequestDetails = null;
		RequestHistoryBean Request = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.prepareStatement(RequestHistoryQueries.GET_REQUEST_DETAILS);
			stmt.setInt(1, RequestID);
			rs = stmt.executeQuery();
			if(rs != null)
			{
				RequestDetails = new ArrayList<RequestHistoryBean>();
				while (rs.next())
				{
					Request = new RequestHistoryBean();
					Request.setRequest_ID(rs.getInt(2));
					Request.setRequest_Associate_ID(rs.getInt(3));
					Request.setRequest_Associate_Name(rs.getString(4));
					Request.setRequest_Project_ID(rs.getInt(5));
					Request.setRequest_Project_Name(rs.getString(6));
					Request.setRequest_Date(rs.getTimestamp(7));
					Request.setRequest_Reason_For_Apply(rs.getString(8));
					Request.setRequest_Status(rs.getString(9));
					RequestDetails .add(Request);
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}


		return RequestDetails;
	}

	public static List<RequestHistoryBean> getClosedRequestStatus( int Associate_ID,Connection conn )
	{

		List<RequestHistoryBean> RequestDetails = null;
		RequestHistoryBean Request = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.prepareStatement(RequestHistoryQueries.GET_CLOSED_REQUEST_STATUS);
			stmt.setInt(1, Associate_ID);
			stmt.setInt(2, Associate_ID);
			rs = stmt.executeQuery();
			if(rs != null)
			{
				RequestDetails = new ArrayList<RequestHistoryBean>();
				while(rs.next())
				{
					Request = getRequestHistoryBean( rs.getInt(1), conn);
					RequestDetails.add(Request);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}


		return RequestDetails;
	}

	public static RequestHistoryBean getRequestHistoryBean( int Request_ID,Connection conn ) 
	{
		RequestHistoryBean Request = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.prepareStatement(RequestHistoryQueries.GET_REQUEST_HISTORY_DETAILS);
			stmt.setInt(1, Request_ID);
			rs = stmt.executeQuery();
			if (rs.next())
			{
				Request = new RequestHistoryBean();
				Request.setRequest_ID(rs.getInt(2));
				Request.setRequest_Associate_ID(rs.getInt(3));
				Request.setRequest_Associate_Name(rs.getString(4));
				Request.setRequest_Project_ID(rs.getInt(5));
				Request.setRequest_Project_Name(rs.getString(6));
				Request.setRequest_Date(rs.getTimestamp(7));
				Request.setRequest_Reason_For_Apply(rs.getString(8));
				Request.setRequest_Status(rs.getString(9));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}


		return Request;
	}

	public static List<RequestHistoryBean> getApprovedRequests(int SuperUserID,String Request_Status,Connection conn)
	{
		List<RequestHistoryBean> RequestDetails = new ArrayList<RequestHistoryBean>();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		RequestHistoryBean Request = null;
		try {
			stmt = conn.prepareStatement(RequestHistoryQueries.GET_APPROVED_REQUEST);
			stmt.setString(1,Request_Status);
			stmt.setInt(2,SuperUserID);
			rs = stmt.executeQuery();
			if(rs != null)
			{
				RequestDetails = new ArrayList<RequestHistoryBean>();
				while( rs.next())
				{
					Request = new RequestHistoryBean();
					Request.setRequest_ID(rs.getInt(1));
					Request.setRequest_Associate_ID(rs.getInt(2));
					Request.setRequest_Associate_Name(rs.getString(3));
					Request.setRequest_Project_ID(rs.getInt(4));
					Request.setRequest_Project_Name(rs.getString(5));
					Request.setRequest_Date(rs.getTimestamp(6));
					Request.setRequest_Reason_For_Apply(rs.getString(7));
					RequestDetails.add(Request);		
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}


		return RequestDetails;
	}



	public static List<RequestHistoryBean> getRejectedRequests(int SupervisorID,Connection conn) 
	{
		PreparedStatement stmt = null;
		ResultSet rs = null;
		RequestHistoryBean Request = null;
		List<RequestHistoryBean> RequestDetails = null;
		try {
			stmt = conn.prepareStatement(RequestHistoryQueries.GET_REJECTD_REQUEST);
			stmt.setInt(1,SupervisorID);
			rs=stmt.executeQuery();

			if(rs != null)
			{
				RequestDetails = new ArrayList<RequestHistoryBean>();
				while( rs.next())
				{
					Request = new RequestHistoryBean();
					Request.setRequest_ID(rs.getInt(2));
					Request.setRequest_Associate_ID(rs.getInt(3));
					Request.setRequest_Associate_Name(rs.getString(4));
					Request.setRequest_Project_ID(rs.getInt(5));
					Request.setRequest_Project_Name(rs.getString(6));
					Request.setRequest_Date(rs.getTimestamp(7));
					Request.setRequest_Reason_For_Apply(rs.getString(8));
					Request.setRequest_Status(rs.getString(9));
					Request.setReject_Reason(rs.getString(11));

					RequestDetails.add(Request);
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}


		return RequestDetails;
	}	
}
