package dao;

public class RequestHistoryQueries 
{
	public static final String INSERT_REQUEST =
		"insert into REQUEST_HISTORY (" +
		"REQUEST_ID," +
		"ASSOCIATE_ID," +
		"ASSOCIATE_NAME," +
		"REQUEST_PROJECT_ID," +
		"REQUEST_PROJECT_NAME," +
		"REQUEST_DATE," +
		"REASON_FOR_REQUEST," +
		"STATUS," +
		"HCM_SUPERVISOR_ID," +
		"REJECT_REASON )" +
		" values (?,?,?,?,?,?,?,?,?,?)";

	public static final String GET_ASSIGNED_REQUEST=
		"select * from REQUEST_HISTORY " +
		"where STATUS = 'Assigned' "+
		" or STATUS = 'Surrendered' "+
		" or STATUS = 'Rejected'";
	
	public static final String DELETE_ASSIGNED_REQUEST=
		"delete from RSA_TOKEN_REQUEST " +
		"where STATUS = 'Assigned' "+
		" or STATUS = 'Surrendered' "+
		" or STATUS = 'Rejected'";
	
	public static final String GET_REJECTD_REQUEST=
		"select * from REQUEST_HISTORY " +
		"where STATUS = 'Rejected' "+
		" and HCM_SUPERVISOR_ID = ? ";
		
	public static final String GET_CLOSED_REQUEST_STATUS = "select distinct REQUEST_ID from REQUEST_HISTORY where ASSOCIATE_ID = ? "+
		" and REQUEST_ID not in ( select REQUEST_ID from RSA_TOKEN_REQUEST where ASSOCIATE_ID = ? )";
	
	public static final String GET_REQUEST_DETAILS = "select * from REQUEST_HISTORY where REQUEST_ID = ?" +
	" order by S_No ASC ";
	
	public static final String GET_REQUEST_HISTORY_DETAILS = "select * from REQUEST_HISTORY where REQUEST_ID = ? " +
	" order by S_No ";
	
	public static final String GET_APPROVED_REQUEST=
		"select REQUEST_ID,ASSOCIATE_ID,ASSOCIATE_NAME,REQUEST_PROJECT_ID,REQUEST_PROJECT_NAME,REQUEST_DATE,REASON_FOR_REQUEST from REQUEST_HISTORY " +
		"where STATUS = ? and HCM_SUPERVISOR_ID = ? and" +
		" REQUEST_ID not in ( select REQUEST_ID from RSA_TOKEN_REQUEST )";
	
	
	
}

