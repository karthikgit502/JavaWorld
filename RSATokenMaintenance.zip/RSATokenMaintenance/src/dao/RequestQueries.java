package dao;

public class RequestQueries
{
	
	public static final String IS_REQUEST_RAISED =
		"select REQUEST_ID from RSA_TOKEN_REQUEST where ASSOCIATE_ID = ?" +
		" and " +
		" ( STATUS = ?" +
		" or " +
		" STATUS = ? " +
		" or STATUS = ? )";
	
	public static final String INSERT_NEW_REQUEST =
		"insert into RSA_TOKEN_REQUEST(" +
		"ASSOCIATE_ID," +
		"ASSOCIATE_NAME," +
		"REQUEST_PROJECT_ID," +
		"REQUEST_PROJECT_NAME," +
		"REQUEST_DATE," +
		"REASON_FOR_REQUEST," +
		"STATUS," +
		"HCM_SUPERVISOR_ID)" +
		"values (?,?,?,?,?,?,?,?)";
	
	
	
	 public static final String GET_REQUEST_FOR_TOKEN ="select REQUEST_ID from RSA_TOKEN_REQUEST where STATUS ='Approved'" +
	 		"  and REASON_FOR_REQUEST <> 'Surrender'";

	 public static final String GET_REQUEST ="select REQUEST_ID from RSA_TOKEN_REQUEST where STATUS = ?";
	 
	 
	 public static final String GET_PENDING_REQUEST_WITH_ADMIN ="select REQUEST_ID from RSA_TOKEN_REQUEST where STATUS = ? "+
	 " and HCM_SUPERVISOR_ID = ?";
	 
	 public static final String GET_REQUEST_BY_ID ="select * from RSA_TOKEN_REQUEST where REQUEST_ID = ? ";
	 
	 public static final String GET_REQUEST_BY_REASON ="select * from RSA_TOKEN_REQUEST where " +
	 		"REASON_FOR_REQUEST = ?  and STATUS = ?";
	 
	 public static final String GET_SURRENDER_REQUESTS ="select * from RSA_TOKEN_REQUEST where " +
		"REASON_FOR_REQUEST ='Surrender' and STATUS = 'Approved'";
	 
	 public static final String GET_OPEN_REQUEST_STATUS ="select * from RSA_TOKEN_REQUEST where ASSOCIATE_ID =  ?";
	 
	 
	 public static final String UPDATE_NEW_REQUEST =
		 "update RSA_TOKEN_REQUEST set STATUS = ? ,REQUEST_DATE = ? where REQUEST_ID = ?";
	 
	 public static final String GET_ASSIGNED_REQUEST=
			"select * from RSA_TOKEN_REQUEST " +
			" where STATUS = 'Assigned' ";
	 
	 public static final String DELETE_REQUEST=
			"delete from RSA_TOKEN_REQUEST " +
			" where REQUEST_ID = ? ";
		
}
