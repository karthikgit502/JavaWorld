package dao;
import java.sql.Connection;
import java.util.Calendar;
import java.util.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import bean.MasterBean;
import bean.TokenBean;

public class TokenDAO 
{

	public static int processExpiredToken(final Connection conn)
	{
		int updated = 0;
		int selected = 0; 
		int deleted = 0;
		MasterBean ExpiredToken = null;
		ResultSet rs= null;
		PreparedStatement stmt = null;
		try 
		{
			updated = setExpiredTokenStatus(conn);
			stmt = conn.prepareStatement(TokenQueries.SELECT_EXPIRED_TOKEN);
			rs = stmt.executeQuery();
			while(rs.next())
			{
				selected++;
				ExpiredToken = new MasterBean();
				ExpiredToken.setToken_id(rs.getInt(1));
				ExpiredToken.setExpiry_date(rs.getDate(2));
				ExpiredToken.setStatus("Expired");
				MasterHistoryDAO.insertRequest(ExpiredToken, conn);
			}
			if(updated ==  selected )
				deleted = deleteExpiredToken(conn);
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) 
				{

					e.printStackTrace();
				}
			}
		}

		return deleted; 
	}
	public static int deleteExpiredToken(final Connection conn)
	{
		PreparedStatement stmt = null;
		int deleted = 0;
		try 
		{
			stmt = conn.prepareStatement(TokenQueries.DELETE_EXPIRED_TOKEN);
			deleted = stmt.executeUpdate();
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) 
				{

					e.printStackTrace();
				}
			}
		}

		return deleted; 
	}

	public static int setExpiredTokenStatus(final Connection conn)
	{
		PreparedStatement stmt = null;
		int updated = 0;
		try 
		{
			stmt = conn.prepareStatement(TokenQueries.SET_TOKEN_STATUS_AS_EXPIRED);
			updated = stmt.executeUpdate();
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) 
				{

					e.printStackTrace();
				}
			}
		}

		return updated; 
	}

	public static int insertNew_Token(final TokenBean Token,final Connection conn)
	{
		int result=0;	
		PreparedStatement stmt = null;
		
		try {
			stmt = conn.prepareStatement(TokenQueries.INSERT_NEW_TOKEN);
			stmt.setInt(1,Token.getToken_ID());//token id
			stmt.setDate(2,Token.getExpiry_Date());// expdate
			stmt.setString(3,Token.getToken_Status());
			result = stmt.executeUpdate();	

		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		finally
 		{
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) 
				{

					e.printStackTrace();
				}
			}
		}

		return result;
	}

	public static int get_TokenID(final int AssociateID,final Connection conn)
	{
		int result=0;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			stmt = conn.prepareStatement(TokenQueries.GET_TOKEN_DETAILS);
			stmt.setInt(1,AssociateID);//token id
			rs  =  stmt.executeQuery();
			if(rs.next())
				result=rs.getInt(1);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) 
				{

					e.printStackTrace();
				}
			}
		}

		return result;
	}


	public static int getRecentlyExpiredTokenFromAssociate(final int AssociateID,final Connection conn)
	{
		int result=0;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			stmt = conn.prepareStatement(TokenQueries.GET_RECENTLY_EXPIRED_TOKEN);
			stmt.setInt(1,AssociateID);//token id
			rs  =  stmt.executeQuery();
			if(rs.next())
				result = rs.getInt(1);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) 
				{

					e.printStackTrace();
				}
			}
		}

		return result;
	}

	public static TokenBean get_Token_Details(final int AssociateID, final Connection conn)
	{
		PreparedStatement stmt = null;
		ResultSet rs = null;
		TokenBean Token = null;
		try {
			stmt = conn.prepareStatement(TokenQueries.GET_TOKEN_DETAILS);
			stmt.setInt(1,AssociateID);//token id

			rs  =  stmt.executeQuery();
			if(rs.next())
			{
				Token= new TokenBean();
				Token.setToken_ID(rs.getInt(1));
				Token.setExpiry_Date(rs.getDate(2));

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) 
				{

					e.printStackTrace();
				}
			}
		}


		return Token;
	}

	public static TokenBean get_Token_Details_Before_Dispatch(final int AssociateID, final Connection conn)
	{
		PreparedStatement stmt = null;
		ResultSet rs = null;
		TokenBean Token= null;
		try {
			stmt = conn.prepareStatement(TokenQueries.GET_TOKEN_DETAILS_BEFORE_DISPATCH);
			stmt.setInt(1,AssociateID);//token id

			rs  =  stmt.executeQuery();
			if(rs.next())
			{
				Token= new TokenBean();
				Token.setToken_ID(rs.getInt(1));
				Token.setExpiry_Date(rs.getDate(2));
				Token.setToken_Status(rs.getString(3));
				Token.setToken_Dispatch_Status(rs.getString(4));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) 
				{

					e.printStackTrace();
				}
			}
		}

		return Token;
	}

	public static int getToken_For_Assign(final String Token_Status, final Connection conn)
	{
		PreparedStatement stmt = null;
		ResultSet rs = null;
		int result=0;
		final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		final Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE,120);
		final String today = dateFormat.format(cal.getTime());
		try {
			stmt = conn.prepareStatement(TokenQueries.GET_TOKEN_ID);
			stmt.setString(1,Token_Status);
			stmt.setString(2,today);
			rs  =  stmt.executeQuery();
			if(rs.next())
				result = rs.getInt(1);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) 
				{

					e.printStackTrace();
				}
			}
		}

		return result;
	}

	public static boolean isTokenExpired(final int Associate_ID, final Connection conn)
	{
		PreparedStatement stmt = null;
		ResultSet rs = null;
		Date Exp_Date;
		boolean result= false;
		try {
			stmt = conn.prepareStatement(TokenQueries.GET_TOKEN_EXPIRY_DATE);
			stmt.setInt(1,Associate_ID);

			final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			final Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DATE,120);
			final String today = dateFormat.format(cal.getTime());

			Date Today = null;
			try {
				Today = dateFormat.parse(today);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			rs =  stmt.executeQuery();
			if(	rs.next())
			{
				Exp_Date = rs.getDate(1);
				if(Exp_Date.before(Today))
					result = true;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) 
				{

					e.printStackTrace();
				}
			}
		}

		return result;
	}

	public static boolean isTokenSurrenderd(final int Token_ID,final Connection conn)
	{
		String Status;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		boolean result= false;
		try {
			stmt = conn.prepareStatement(TokenQueries.GET_TOKEN_STATUS);
			stmt.setInt(1,Token_ID);
			rs =  stmt.executeQuery();
			if(	rs.next())
			{
				Status = rs.getString(1);
				if(Status.equals("Surrendered"))
					result = true;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) 
				{

					e.printStackTrace();
				}
			}
		}
		return result;
	}	

	public static int[] getSummaryReport(final Connection conn)
	{
		PreparedStatement stmt = null;
		PreparedStatement stmt1 = null;
		ResultSet rs = null;
		ResultSet rs1 = null;
		String Status = null;
		final int Assigned_but_Not_Dispatched = 0;
		final int Assigned_and_Dispatched = 1;
		final int UnAssigned=2;
		final int Expired=3;
		final int Lost=4;
		int Total_Dispatched = 0; 
		final int Summary_count[]= new int[5];
		int Assigned =0;
		try {
			stmt = conn.prepareStatement(TokenQueries.GET_SUMMARY_REPORT);
			rs =  stmt.executeQuery();
			stmt1 = conn.prepareStatement(TokenQueries.GET_DISPATCHED_COUNT);
			rs1 =  stmt1.executeQuery();
			if(rs1.next())
				Total_Dispatched = rs1.getInt(1);
			if(rs != null)
			{
				while(rs.next() )
				{
					Status = rs.getString(1);
					if( Status.equals("Surrendered") || Status.equals("New Token") )
						Summary_count[UnAssigned] += rs.getInt(2);
					else if(Status.equals("Assigned") || Status.equals("Re-Assigned"))
						Assigned += rs.getInt(2);
					else if(Status.equals("Expired"))
						Summary_count[Expired] = rs.getInt(2);
					else
						Summary_count[Lost] = rs.getInt(2);
				}
			}
			Summary_count[Assigned_and_Dispatched] = Total_Dispatched;
			Summary_count[Assigned_but_Not_Dispatched] = Assigned - Total_Dispatched;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			if(rs1 != null)
			{
				try {
					rs1.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}

			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) 
				{

					e.printStackTrace();
				}
			}
		}
		return Summary_count;
	}	

	public static int[] getMgrSummaryReport(final int SupervisorID,final Connection conn)
	{
		PreparedStatement stmt = null;
		PreparedStatement stmt1 = null;
		ResultSet rs = null;
		ResultSet rs1 = null;
		String Status = null;
		final int Assigned_but_Not_Dispatched = 0;
		final int Assigned_and_Dispatched = 1;
		final int UnAssigned=2;
		final int Expired=3;
		final int Lost=4;
		int Total_Dispatched = 0; 
		final int Summary_count[]= new int[5];
		int Assigned =0;

		try {
			stmt = conn.prepareStatement(TokenQueries.GET_MGR_SUMMARY_REPORT);
			stmt.setInt(1,SupervisorID);
			stmt.setInt(2,SupervisorID);
			rs =  stmt.executeQuery();
			
			stmt1 = conn.prepareStatement(TokenQueries.GET_MGR_DISPATCHED_COUNT);
			stmt1.setInt(1,SupervisorID);
			rs1 =  stmt1.executeQuery();

			if( rs1.next())
				Total_Dispatched = rs1.getInt(1);

			if(rs != null)
			{
				while(rs.next() )
				{
					Status = rs.getString(1);
					if( Status.equals("Surrendered") || Status.equals("New Token") )
						Summary_count[UnAssigned] += rs.getInt(2);
					else if(Status.equals("Assigned") || Status.equals("Re-Assigned"))
						Assigned += rs.getInt(2);
					else if(Status.equals("Expired"))
						Summary_count[Expired] = rs.getInt(2);
					else
						Summary_count[Lost] = rs.getInt(2);
				}
			}
			Summary_count[Assigned_and_Dispatched] = Total_Dispatched;
			Summary_count[Assigned_but_Not_Dispatched] = Assigned - Total_Dispatched;


		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs != null)
			{
				try {
					rs.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			if(rs1 != null)
			{
				try {
					rs1.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}

			if(stmt != null)
			{
				try {
					stmt.close();
				} catch (SQLException e) 
				{

					e.printStackTrace();
				}
			}
		}
		return Summary_count;
	}	

}
