package dao;

public class TokenQueries
{
	public static final String SET_TOKEN_STATUS_AS_EXPIRED =
		"UPDATE RSA_TOKEN_MASTER SET STATUS = 'Expired'WHERE EXPIRY_DATE <= now()";
	
	public static final String DELETE_EXPIRED_TOKEN =
		"delete from RSA_TOKEN_MASTER where STATUS = 'Expired'";
	
	public static final String SELECT_EXPIRED_TOKEN =
		"select TOKEN_ID,EXPIRY_DATE from RSA_TOKEN_MASTER where STATUS = 'Expired'";
	
	public static final String MOVE_EXPIRED_TOKEN_TO_HISTORY =
		"UPDATE RSA_TOKEN_MASTER SET STATUS = 'Expired'WHERE EXPIRY_DATE <= now()";
	
 	public static final String INSERT_NEW_TOKEN =
		"insert into RSA_TOKEN_MASTER (TOKEN_ID,EXPIRY_DATE,STATUS) values (?,?,?) ";
	
	public static final String GET_TOKEN_ID =
	"select TOKEN_ID from RSA_TOKEN_MASTER " +
	"where TOKEN_ID IN( select min(TOKEN_ID) from RSA_TOKEN_MASTER where STATUS = ? and EXPIRY_DATE > ? ) " +
	"order by EXPIRY_DATE,TOKEN_ID ASC";
	
	public static final String GET_TOKEN_STATUS =
		"select STATUS from RSA_TOKEN_MASTER where TOKEN_ID = ?";
	
	public static final String GET_TOKEN_ID_BY_ASSOCIATE =
		"select TOKEN_ID from RSA_TOKEN_MASTER where ASSOCIATE_ID = ?";
	
	
	public static final String GET_RECENTLY_EXPIRED_TOKEN =
		"select TOKEN_ID from RSA_MASTER_HISTORY where ASSOCIATE_ID = ? and STATUS='Expired' "+
		" order by S_NO desc"
		;
	
	public static final String GET_TOKEN_ID_BY_ASSOCIATE_BEFORE_DISPATCH =
		"select TOKEN_ID from RSA_TOKEN_MASTER where ASSOCIATE_ID = ? and DISPATCH_STATUS = 'YES'";
	
	
	public static final String GET_TOKEN_EXPIRY_DATE =
		"select EXPIRY_DATE from RSA_TOKEN_MASTER where TOKEN_ID = ?";
	
	public static final String GET_TOKEN_DETAILS =
		"select TOKEN_ID,EXPIRY_DATE from RSA_TOKEN_MASTER where ASSOCIATE_ID = ? and DISPATCH_STATUS = 'YES'";

	
	public static final String GET_TOKEN_DETAILS_BEFORE_DISPATCH =
		"select TOKEN_ID,EXPIRY_DATE,STATUS,DISPATCH_STATUS from RSA_TOKEN_MASTER where ASSOCIATE_ID = ? ";
	
	public static final String GET_SUMMARY_REPORT=
		"(select STATUS, count(*) from RSA_TOKEN_MASTER group by STATUS) UNION ALL "+
		" (select STATUS, count(*)  from RSA_MASTER_HISTORY where STATUS='Lost' or STATUS='Expired' group by STATUS)";
	
	public static final String GET_MGR_SUMMARY_REPORT=
		"(select STATUS, count(*) from RSA_TOKEN_MASTER  where HCM_SUPERVISOR_ID = ? group by STATUS) UNION ALL "+
		" (select STATUS, count(*)  from RSA_MASTER_HISTORY where ( STATUS='Lost' or STATUS='Expired' ) and HCM_SUPERVISOR_ID = ? group by STATUS)";	

	public static final String GET_DISPATCHED_COUNT =
		"select count(*) from RSA_TOKEN_MASTER where DISPATCH_STATUS = 'YES'";
	
	public static final String GET_MGR_DISPATCHED_COUNT =
		"select count(*) from RSA_TOKEN_MASTER where DISPATCH_STATUS = 'YES' and HCM_SUPERVISOR_ID = ? ";
}
	
